package logNot.config

enum class AlarmState {
    NONE,
    SOUND_ONLY,
    SILENT_NOTIFICATION,
    NOTIFICATION_AND_SOUND
}