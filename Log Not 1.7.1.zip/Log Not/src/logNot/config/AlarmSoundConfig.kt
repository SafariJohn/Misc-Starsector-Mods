package logNot.config

data class AlarmSoundConfig(
    val useSoundAlarm: Boolean,
    val generalAlarmId: String,
    val generalFollowupId: String,
    val supplyAlarmId: String,
    val supplyFollowupId: String,
    val fuelAlarmId: String,
    val fuelFollowupId: String,
)
