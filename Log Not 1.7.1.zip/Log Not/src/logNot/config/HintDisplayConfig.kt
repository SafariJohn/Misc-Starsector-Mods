package logNot.config

data class HintDisplayConfig(
    val lowSuppliesDays: Int,
    val alarmSuppliesDays: Int
)
