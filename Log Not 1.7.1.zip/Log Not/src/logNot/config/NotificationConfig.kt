package logNot.config

data class NotificationConfig(
    val useNotifications: Boolean,
    val alarmSuppliesDays: Int,
    val alarmFuelLY: Int,
    val notificationInterval: Int,
    val showSupplyNotifications: Boolean,
    val showFuelNotifications: Boolean,
    val lowSupplyDays: Int,
    val lowFuelDays: Int,
)
