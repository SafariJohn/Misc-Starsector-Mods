package logNot.config

import logNot.helpers.Helper
import org.json.JSONException
import java.io.IOException
import java.util.logging.Level
import java.util.logging.Logger

class ConfigData {
    val useHintsDisplay: Boolean
        get() = _useHintsDisplay
    val useNotifications: Boolean
        get() = _useNotifications
    val useAlarmNotifications: Boolean
        get() = _useAlarmNotifications
    val useSoundAlarm: Boolean
        get() = _useSoundAlarm
    val hintDisplayConfig: HintDisplayConfig
        get() = _hintDisplayConfig
    val notificationsConfig: NotificationConfig
        get() = _notificationsConfig
    val alarmConfig: AlarmConfig
        get() = _alarmConfig
    val alarmSoundConfig: AlarmSoundConfig
        get() = _alarmSoundConfig

    private var _useHintsDisplay = false
    private var _useNotifications = false
    private var _useAlarmNotifications = false
    private var _useSoundAlarm = false
    private var _hintDisplayConfig = HintDisplayConfig(30, 10)
    private var _notificationsConfig = NotificationConfig(
        _useNotifications,
        10,
        10,
        3,
        false,
        false,
        30,
        30,
    )
    private var _alarmConfig = AlarmConfig(
        _useAlarmNotifications,
        10,
        10,
        1,
        AlarmState.NONE,
        AlarmState.NONE
    )
    private var _alarmSoundConfig = AlarmSoundConfig(
        _useSoundAlarm,
        "cr_playership_critical",
        "cr_playership_critical",
        "cr_playership_critical",
        "cr_playership_critical",
        "cr_playership_critical",
        "cr_playership_critical"
    )

    init {
        try {
            val obj = Helper.settings?.loadJSON("data/config/Logistics Notifications/config.json") ?: throw IOException()
            _useHintsDisplay = obj.getBoolean("useHintsDisplay")
            _useNotifications = obj.getBoolean("useNotifications")
            _useAlarmNotifications = obj.getBoolean("useAlarmNotifications")
            _useSoundAlarm = obj.getBoolean("soundAlarm")
            val supplyAlarm = getAlarmState(obj.getString("supplyAlarm"))
            val fuelAlarm = getAlarmState(obj.getString("fuelAlarm"))
            val alarmSuppliesLevel = obj.getInt("alarmSupplies")
            val alarmFuelLevel = obj.getInt("alarmFuel")
            val lowSuppliesLevel = obj.getInt("lowSupplies")
            _hintDisplayConfig = HintDisplayConfig(lowSuppliesLevel, alarmSuppliesLevel)
            _notificationsConfig = NotificationConfig(
                _useNotifications,
                alarmSuppliesLevel,
                alarmFuelLevel,
                obj.getInt("notificationInterval"),
                obj.getBoolean("supplyNotifications"),
                obj.getBoolean("fuelNotifications"),
                lowSuppliesLevel,
                obj.getInt("lowFuel")
            )
            _alarmConfig = AlarmConfig(
                _useAlarmNotifications,
                alarmSuppliesLevel,
                alarmFuelLevel,
                obj.getInt("alarmInterval"),
                supplyAlarm,
                fuelAlarm
            )
            _alarmSoundConfig = AlarmSoundConfig(
                _useSoundAlarm,
                obj.getString("alarmSoundId"),
                obj.getString("followupSoundId"),
                obj.getString("suAlarmSoundId"),
                obj.getString("suFollowupSoundId"),
                obj.getString("fuelAlarmSoundId"),
                obj.getString("fuelFollowupSoundId")
            )
        } catch (ex: IOException) {
            Logger.getLogger(this::class.java.name).log(Level.SEVERE, null, ex)
        } catch (ex: JSONException) {
            Logger.getLogger(this::class.java.name).log(Level.SEVERE, null, ex)
        }
    }

    private fun getAlarmState(stateString: String?): AlarmState {
        return when (stateString) {
            "NONE" -> AlarmState.NONE
            "SOUND_ONLY" -> AlarmState.SOUND_ONLY
            "SILENT_NOTIFICATION" -> AlarmState.SILENT_NOTIFICATION
            "NOTIFICATION_AND_SOUND" -> AlarmState.NOTIFICATION_AND_SOUND
            else -> AlarmState.NONE
        }
    }
}