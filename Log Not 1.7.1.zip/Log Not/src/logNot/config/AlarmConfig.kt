package logNot.config

data class AlarmConfig(
    val useAlarm: Boolean,
    val alarmSuppliesDays: Int,
    val alarmFuelLY: Int,
    val alarmInterval: Int,
    val supplyAlarm: AlarmState,
    val fuelAlarm: AlarmState
) {
    val isSupplyAlarm = supplyAlarm != AlarmState.NONE
    val isFuelAlarm = fuelAlarm != AlarmState.NONE
    val isSupplyAlarmNotification = supplyAlarm == AlarmState.SILENT_NOTIFICATION || supplyAlarm == AlarmState.NOTIFICATION_AND_SOUND
    val isSupplyAlarmSound = supplyAlarm == AlarmState.NOTIFICATION_AND_SOUND || supplyAlarm == AlarmState.SOUND_ONLY
    val isFuelAlarmNotification = fuelAlarm == AlarmState.SILENT_NOTIFICATION || fuelAlarm == AlarmState.NOTIFICATION_AND_SOUND
    val isFuelAlarmSound = fuelAlarm == AlarmState.NOTIFICATION_AND_SOUND || fuelAlarm == AlarmState.SOUND_ONLY
}
