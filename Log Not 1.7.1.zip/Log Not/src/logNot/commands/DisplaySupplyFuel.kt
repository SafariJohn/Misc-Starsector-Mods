package logNot.commands

import com.fs.starfarer.api.fleet.FleetMemberAPI
import logNot.helpers.ExternalStrings
import logNot.helpers.Helper
import logNot.scripts.SupplyDataTracking
import org.lazywizard.console.BaseCommand
import org.lazywizard.console.BaseCommand.CommandContext
import org.lazywizard.console.BaseCommand.CommandResult
import org.lazywizard.console.Console

class DisplaySupplyFuel : BaseCommand {
    companion object {
        private const val SUPPLY_TOKEN = "[SUPPLY DAYS]"
        private const val FUEL_TOKEN = "[LY]"
    }

    override fun runCommand(args: String, context: CommandContext): CommandResult {
        val m = displayConsole()
        Console.showMessage(m)
        return CommandResult.SUCCESS
    }

    private fun displayConsole(): String {
        val suDisplay = Helper.roundToTenthsPlace(getSupplyDays())
        val fuelDisplay = Helper.roundToTenthsPlace(SupplyDataTracking.getFuelLY())
        val s = ExternalStrings.DISPLAY_SUPPLY_FUEL_COMMAND
            .replace(SUPPLY_TOKEN, suDisplay.toString())
            .replace(FUEL_TOKEN, fuelDisplay.toString())
        return s
    }

    /**
     * Calculates how many days of supply the player has left, accounting for repairs and recovery.
     * @return days of supply
     */
    private fun getSupplyDays(): Float {
        // Calculate days of supply remaining
        val playerFleet = Helper.sector?.playerFleet ?: return 0f
        val supplies = playerFleet.cargo?.supplies ?: return 0f
        val logistics = playerFleet.logistics ?: return 0f
        val recoveryCost = logistics.totalRepairAndRecoverySupplyCost
        val totalPerDay = logistics.totalSuppliesPerDay
        val suDays: Float
        // Running out
        if (recoveryCost >= supplies) {
            suDays = supplies / totalPerDay
        } else {

            // Total up maintenance costs per day for fleet
            var maintPerDay = 0f
            for (mem: FleetMemberAPI in playerFleet.membersWithFightersCopy ?: emptyList()) {
                val maint = (mem.stats?.suppliesPerMonth?.modifiedValue ?: 0f) / 30
                maintPerDay += maint
            }
            // Account for extra cost from over-capacity
            // Not going to try to do cargo because it's reductive as it consumes supplies
            maintPerDay += logistics.excessPersonnelCapacitySupplyCost
            maintPerDay += logistics.excessFuelCapacitySupplyCost

            // And finally: compute!
            suDays = (recoveryCost / totalPerDay) + ((supplies - recoveryCost.toInt()) / maintPerDay)
        }
        return suDays
    }
}