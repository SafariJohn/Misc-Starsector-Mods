package logNot.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.impl.campaign.tutorial.TutorialMissionIntel
import com.fs.starfarer.api.util.IntervalUtil
import com.fs.starfarer.api.util.Misc
import logNot.config.HintDisplayConfig
import logNot.helpers.ExternalStrings
import logNot.helpers.Helper
import java.awt.Color
import kotlin.math.roundToInt


class HintDisplayController(
    config: HintDisplayConfig,
    getSupplyDaysRemaining: () -> Float,
    areRunningOutOfSupplies: () -> Boolean,
) : EveryFrameScript {
    private val model = HintDisplayModel()
    private val interactor = HintDisplayInteractor(model, config, getSupplyDaysRemaining, areRunningOutOfSupplies)
    private val view = HintDisplayView(model)

    override fun advance(amount: Float) {
        if (interactor.isRefresh(amount)) {
            interactor.prepRefresh()
            view.refreshHintDisplay()
        }
    }

    override fun isDone(): Boolean = false
    override fun runWhilePaused(): Boolean = false
}

interface HintDisplayInteractorModel {
    var supplyDays: Int
    var supplyHighlightColor: Color
    var tutorialInProgress: Boolean
}
interface HintDisplayLayoutModel {
    val supplyDays: Int
    val supplyHighlightColor: Color
    val tutorialInProgress: Boolean
}

class HintDisplayModel : HintDisplayInteractorModel, HintDisplayLayoutModel {
    override var supplyDays: Int = 0
    override var supplyHighlightColor: Color = Misc.getPositiveHighlightColor()
    override var tutorialInProgress: Boolean = true
}

class HintDisplayInteractor(
    private val model: HintDisplayInteractorModel,
    private val config: HintDisplayConfig,
    private val getSupplyDaysRemaining: () -> Float,
    private val areRunningOutOfSupplies: () -> Boolean
) {
    private val interval = IntervalUtil(0.1f, 0.1f)

    fun isRefresh(amount: Float): Boolean {
        interval.advance(Misc.getDays(amount))
        return interval.intervalElapsed()
    }

    fun prepRefresh() {
        val supplyDaysRemaining = getSupplyDaysRemaining()
        model.supplyDays = supplyDaysRemaining.roundToInt()
        model.supplyHighlightColor = if (areRunningOutOfSupplies()) {
            Misc.getNegativeHighlightColor()
        } else {
            if (supplyDaysRemaining <= config.alarmSuppliesDays) {
                Misc.getNegativeHighlightColor()
            } else if (supplyDaysRemaining <= config.lowSuppliesDays) {
                Misc.getHighlightColor()
            } else {
                Misc.getPositiveHighlightColor()
            }
        }
        model.tutorialInProgress = TutorialMissionIntel.isTutorialInProgress()
    }
}

class HintDisplayView(private val model: HintDisplayLayoutModel) {
    companion object {
        private val TUTORIAL_HINT_INDEX = 3 // TODO config?
        private val DISPLAY_CACHE = ExternalStrings.HINT_DISPLAY
        private val DISPLAY_HL_CACHE = ExternalStrings.HINT_DISPLAY_HL
        private val SUPPLY_TOKEN = "[SUPPLY DAYS]"
    }

    fun refreshHintDisplay() {
        val hints = Helper.sector?.campaignUI?.hintPanel ?: return
        var index = 0
        if (model.tutorialInProgress) {
            hints.fadeOutHint(index)
            index = TUTORIAL_HINT_INDEX
        } else if (hints.hasHint(TUTORIAL_HINT_INDEX)) {
            hints.fadeOutHint(TUTORIAL_HINT_INDEX)
        }
        val format = DISPLAY_CACHE.replace(SUPPLY_TOKEN, model.supplyDays.toString())
        val hl = DISPLAY_HL_CACHE.replace(SUPPLY_TOKEN, model.supplyDays.toString())
        hints.setHint(index, format, false, model.supplyHighlightColor, hl)
    }
}