package logNot.scripts

import com.fs.starfarer.api.EveryFrameScript
import logNot.config.NotificationConfig
import logNot.helpers.Helper

class NotificationsController(
    notificationConfig: NotificationConfig,
    getSupplyDaysRemaining: () -> Float,
    areRunningOutOfSupplies: () -> Boolean,
    getFuelLY: () -> Float,
    getAlarmCooldown: () -> Float
) : EveryFrameScript {
    private val model = NotificationsModel()
    private val interactor = NotificationsInteractor(
        model,
        notificationConfig,
        getSupplyDaysRemaining,
        areRunningOutOfSupplies,
        getFuelLY,
        getAlarmCooldown
    )
    private val view = NotificationsView(model)

    override fun advance(amount: Float) {
        interactor.advance(amount)
        view.advance()
    }

    override fun isDone(): Boolean = false
    override fun runWhilePaused(): Boolean = true
}

interface NotificationsInteractorModel {
    var showSupplyNotification: Boolean
    var showFuelNotification: Boolean
    var areRunningOutOfSupplies: Boolean
    var supplyDaysRemaining: Float
    var alarmSupplyDays: Float
    var lowSupplyDays: Float
    var fuelLY: Float
    var alarmFuelLY: Float
    var lowFuelLY: Float
}
interface NotificationsLayoutModel {
    val showSupplyNotification: Boolean
    val showFuelNotification: Boolean
    val areRunningOutOfSupplies: Boolean
    val supplyDaysRemaining: Float
    val alarmSupplyDays: Float
    val lowSupplyDays: Float
    val fuelLY: Float
    val alarmFuelLY: Float
    val lowFuelLY: Float
}

class NotificationsModel : NotificationsInteractorModel, NotificationsLayoutModel {
    override var showSupplyNotification: Boolean = false
    override var showFuelNotification: Boolean = false
    override var areRunningOutOfSupplies: Boolean = false
    override var supplyDaysRemaining: Float = -1f
    override var alarmSupplyDays: Float = -1f
    override var lowSupplyDays: Float = -1f
    override var fuelLY: Float = -1f
    override var alarmFuelLY: Float = -1f
    override var lowFuelLY: Float = -1f
}

class NotificationsInteractor(
    private val model: NotificationsInteractorModel,
    private val config: NotificationConfig,
    private val getSupplyDaysRemaining: () -> Float,
    private val areRunningOutOfSupplies: () -> Boolean,
    private val getFuelLY: () -> Float,
    private val getAlarmCooldown: () -> Float
) {

    private var firstUpdateAfterLoad = true
    private var firstUpdateDelay = 1f

    private var lastDay = -1

    private var notificationDayCounter = 0

    init {
        model.alarmSupplyDays = config.alarmSuppliesDays.toFloat()
        model.alarmFuelLY = config.alarmFuelLY.toFloat()
        model.lowSupplyDays = config.lowSupplyDays.toFloat()
        model.lowFuelLY = config.lowFuelDays.toFloat()
    }

    fun advance(amount: Float) {
        if (firstUpdateAfterLoad && config.useNotifications) {
            firstNotification(amount)
            return
        }

        if (Helper.isSectorPaused) return

        if (getAlarmCooldown() > 0f) return

        if (isNewDay()) {
            notificationDayCounter++
            if (notificationDayCounter > config.notificationInterval) {
                notificationDayCounter = 0
                setNotification()
            }
        } else {
            unset()
        }
    }

    private fun firstNotification(amount: Float) {
        if (getAlarmCooldown() > 0f) {
            firstUpdateDelay = -1f
            firstUpdateAfterLoad = false
            return
        }

        if (firstUpdateDelay <= 0) {
            setNotification()
            firstUpdateAfterLoad = false
        } else {
            firstUpdateDelay -= amount
            unset()
        }
    }

    private fun setNotification() {
        model.supplyDaysRemaining = getSupplyDaysRemaining()
        model.fuelLY = getFuelLY()
        model.areRunningOutOfSupplies = areRunningOutOfSupplies()
        model.showSupplyNotification = config.showSupplyNotifications
        model.showFuelNotification = config.showFuelNotifications
    }

    private fun unset() {
        model.supplyDaysRemaining = -1f
        model.fuelLY = -1f
        model.showSupplyNotification = false
        model.showFuelNotification = false
    }

    private fun isNewDay(): Boolean {
        val day = Helper.sector?.clock?.day ?: -1
        if (lastDay == day) return false
        lastDay = day
        return true
    }
}

class NotificationsView(private val model: NotificationsLayoutModel) {
    fun advance() {
        if (model.showSupplyNotification) {
            Helper.showSupplyNotification(model.supplyDaysRemaining, model.areRunningOutOfSupplies, model.alarmSupplyDays, model.lowSupplyDays)
        }
        if (model.showFuelNotification) {
            Helper.showFuelLYNotification(model.fuelLY, model.alarmFuelLY, model.lowFuelLY)
        }
    }
}