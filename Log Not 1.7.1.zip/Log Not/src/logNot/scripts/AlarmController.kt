package logNot.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.util.IntervalUtil
import com.fs.starfarer.api.util.Misc
import logNot.config.AlarmConfig
import logNot.config.AlarmSoundConfig
import logNot.helpers.Helper

class AlarmController(
    config: AlarmConfig,
    soundConfig: AlarmSoundConfig,
    getSupplyDaysRemaining: () -> Float,
    areRunningOutOfSupplies: () -> Boolean,
    getFuelLY: () -> Float
) : EveryFrameScript {
    private val model = AlarmModel()
    private val interactor = AlarmInteractor(model, config, getSupplyDaysRemaining, areRunningOutOfSupplies, getFuelLY)
    private val view = AlarmViewBuilder(model, soundConfig)

    override fun advance(amount: Float) {
        if (interactor.isRefresh(amount)) {
            interactor.prepDisplay()
            view.displayAndPlay()
        }
    }

    fun getAlarmCooldown(): Float = interactor.alarmCooldown

    override fun isDone(): Boolean = false

    override fun runWhilePaused(): Boolean = true
}

interface AlarmInteractorModel {
    var isSupplyAlarmSound: Boolean
    var isFuelAlarmSound: Boolean
    var isInitialAlarm: Boolean
    var showSupplyNotification: Boolean
    var showFuelNotification: Boolean
    var areRunningOutOfSupplies: Boolean
    var supplyDaysRemaining: Float
    var alarmSupplyDays: Float
    var lowSupplyDays: Float
    var fuelLY: Float
    var alarmFuelLY: Float
    var lowFuelLY: Float

}
interface AlarmLayoutModel {
    val isSupplyAlarmSound: Boolean
    val isFuelAlarmSound: Boolean
    val isInitialAlarm: Boolean
    val showSupplyNotification: Boolean
    val showFuelNotification: Boolean
    val areRunningOutOfSupplies: Boolean
    val supplyDaysRemaining: Float
    val alarmSupplyDays: Float
    val lowSupplyDays: Float
    val fuelLY: Float
    val alarmFuelLY: Float
    val lowFuelLY: Float

}

class AlarmModel : AlarmInteractorModel, AlarmLayoutModel {
    override var isSupplyAlarmSound: Boolean = false
    override var isFuelAlarmSound: Boolean = false
    override var isInitialAlarm: Boolean = false
    override var showSupplyNotification: Boolean = false
    override var showFuelNotification: Boolean = false
    override var areRunningOutOfSupplies: Boolean = false
    override var supplyDaysRemaining: Float = -1f
    override var alarmSupplyDays: Float = -1f
    override var lowSupplyDays: Float = -1f
    override var fuelLY: Float = -1f
    override var alarmFuelLY: Float = -1f
    override var lowFuelLY: Float = -1f
}

class AlarmInteractor(
    private val model: AlarmInteractorModel,
    private val config: AlarmConfig,
    private val getSupplyDaysRemaining: () -> Float,
    private val areRunningOutOfSupplies: () -> Boolean,
    private val getFuelLY: () -> Float
) {
    companion object {
        private const val NOTIFICATION_COOLDOWN = 1f
    }

    private var firstUpdateAfterLoad = true
    private var firstUpdateDelay = 0.9f

    val alarmCooldown: Float
        get() = _alarmCooldown
    private var _alarmCooldown = 0f

    private var isAlarmed = false

    private var lastDay = -1
    private var notificationDayCounter = 0

    private val refreshInterval = IntervalUtil(0.1f, 0.1f)

    fun isRefresh(amount: Float): Boolean {
        if (firstUpdateAfterLoad) {
            return firstNotification(amount)
        }

        val days = Misc.getDays(amount)
        if (alarmCooldown > 0) _alarmCooldown -= days

        refreshInterval.advance(days)
        return refreshInterval.intervalElapsed()
    }

    fun prepDisplay() {
        if (Helper.isSectorPaused) {
            unset()
            return
        }

        if (!isAlarmed) {
            setAlarm()
            notificationDayCounter = 0
            isNewDay()
            return
        }

        if (isNewDay() && config.alarmInterval > 0) {
            notificationDayCounter++
            if (notificationDayCounter >= config.alarmInterval) {
                notificationDayCounter = 0
                setAlarm()
            }
        } else {
            unset()
        }
    }

    private fun firstNotification(amount: Float): Boolean {
        if (firstUpdateDelay <= 0) {
            setAlarm()
            firstUpdateAfterLoad = false
        } else {
            firstUpdateDelay -= amount
        }
        return !firstUpdateAfterLoad
    }

    private fun setAlarm() {
        val isSupplyAlarm = config.isSupplyAlarm && Helper.isSupplyAlarm(areRunningOutOfSupplies(), getSupplyDaysRemaining(), config.alarmSuppliesDays)
        val isFuelAlarm = config.isFuelAlarm && Helper.isFuelAlarm(getFuelLY(), config.alarmFuelLY)

        val wasAlarmed = isAlarmed
        isAlarmed = isSupplyAlarm || isFuelAlarm
        model.isInitialAlarm = isAlarmed && !wasAlarmed

        if (isAlarmed) {
            _alarmCooldown = NOTIFICATION_COOLDOWN
            model.showSupplyNotification = config.isSupplyAlarmNotification && isSupplyAlarm
            model.showFuelNotification = config.isFuelAlarmNotification && isFuelAlarm
            model.isSupplyAlarmSound = config.isSupplyAlarmSound && isSupplyAlarm
            model.isFuelAlarmSound = config.isFuelAlarmSound && isFuelAlarm
            model.supplyDaysRemaining = getSupplyDaysRemaining()
            model.fuelLY = getFuelLY()
        }
    }

    private fun unset() {
        model.isInitialAlarm = false
        model.showSupplyNotification = false
        model.showFuelNotification = false
        model.isSupplyAlarmSound = false
        model.isFuelAlarmSound = false
        model.supplyDaysRemaining = -1f
        model.fuelLY = -1f
    }

    private fun isNewDay(): Boolean {
        val day = Helper.sector?.clock?.day ?: -1
        if (lastDay == day) return false
        lastDay = day
        return true
    }
}

class AlarmViewBuilder(private val model: AlarmLayoutModel, private val soundConfig: AlarmSoundConfig) {
    fun displayAndPlay() {
        if (model.isSupplyAlarmSound || model.isFuelAlarmSound) {
            Helper.playAlarmSound(soundConfig, model.isSupplyAlarmSound, model.isFuelAlarmSound, model.isInitialAlarm)
        }

        if (model.showSupplyNotification) {
            Helper.showSupplyNotification(model.supplyDaysRemaining, model.areRunningOutOfSupplies, model.alarmSupplyDays, model.lowSupplyDays)
        }
        if (model.showFuelNotification) {
            Helper.showFuelLYNotification(model.fuelLY, model.alarmFuelLY, model.lowFuelLY)
        }
    }
}