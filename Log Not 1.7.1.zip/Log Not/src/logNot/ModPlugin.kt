package logNot

import com.fs.starfarer.api.BaseModPlugin
import com.fs.starfarer.api.impl.campaign.tutorial.TutorialMissionIntel
import logNot.config.ConfigData
import logNot.helpers.ExternalStrings
import logNot.helpers.Helper
import logNot.helpers.Ids
import logNot.scripts.*

class ModPlugin : BaseModPlugin() {
    override fun onApplicationLoad() {
        if (!Helper.isModEnabled(Ids.LAZY_LIB)) throw RuntimeException(ExternalStrings.LAZY_LIB_REQ)
    }

    override fun onGameLoad(newGame: Boolean) {
        val config = ConfigData()

        if (!config.useHintsDisplay && !config.useNotifications && !config.useSoundAlarm) return

        val supplyTracking = SupplyDataTracking()
        Helper.sector?.addTransientScript(supplyTracking)
        if (config.useHintsDisplay) {
            Helper.sector?.addTransientScript(
                HintDisplayController(
                    config.hintDisplayConfig,
                    supplyTracking::daysOfSupplyRemaining,
                    supplyTracking::isRunningOutOfSupplies
                )
            )
        }

        val alarmScript = getAndAddAlarmScript(config, supplyTracking)

        if (config.useNotifications) {
            Helper.sector?.addTransientScript(
                NotificationsController(
                    config.notificationsConfig,
                    supplyTracking::daysOfSupplyRemaining,
                    supplyTracking::isRunningOutOfSupplies,
                    supplyTracking::fuelLYRemaining,
                    { getAlarmCooldown(alarmScript) }
                )
            )
        }
    }

    private fun getAlarmCooldown(alarmScript: AlarmController?): Float = alarmScript?.getAlarmCooldown() ?: -1f

    private fun getAndAddAlarmScript(config: ConfigData, supplyTracking: SupplyDataTracking): AlarmController? {
        if (!(config.useAlarmNotifications || config.useSoundAlarm)) return null
        val result = AlarmController(
            config.alarmConfig,
            config.alarmSoundConfig,
            supplyTracking::daysOfSupplyRemaining,
            supplyTracking::isRunningOutOfSupplies,
            supplyTracking::fuelLYRemaining
        )
        Helper.sector?.addTransientScript(result)
        return result
    }

    override fun beforeGameSave() {
        val hints = Helper.sector?.campaignUI?.hintPanel ?: return
        if (TutorialMissionIntel.isTutorialInProgress() && hints.hasHint(3)) {
            hints.fadeOutHint(3) // TODO extern config?
        } else if (hints.hasHint(0)) {
            hints.fadeOutHint(0)
        }
    }

}