package logNot.helpers

import com.fs.starfarer.api.Global
import com.fs.starfarer.api.SettingsAPI
import com.fs.starfarer.api.SoundPlayerAPI
import com.fs.starfarer.api.campaign.*
import com.fs.starfarer.api.util.Misc
import logNot.config.AlarmSoundConfig
import java.awt.Color
import java.util.*

object Helper {
    val modId: String
        get() {
            return if (isModEnabled(Ids.DEV_MOD_ID)) Ids.DEV_MOD_ID
            else if (isModEnabled(Ids.MOD_ID)) Ids.MOD_ID
            else {
                settings?.modManager?.enabledModsCopy?.firstOrNull { it.id.startsWith(Ids.MOD_ID) }?.id
                    ?: Ids.MOD_ID
            }
    }

    fun isModEnabled(id: String): Boolean {
        return settings?.modManager?.isModEnabled(id) == true
    }

    val random
        get() = Misc.random ?: Random()

    val isSectorPaused: Boolean
        get() = sector?.isPaused ?: true

    val sector: SectorAPI?
        get() = Global.getSector()

    val settings: SettingsAPI?
        get() = Global.getSettings()

    val soundPlayer: SoundPlayerAPI?
        get() = Global.getSoundPlayer()

    fun anyNull(vararg objects: Any?): Boolean {
        for (o in objects) {
            if (o == null) return true
        }

        return false
    }

    private val SUPPLY_TOKEN = "[SUPPLY DAYS]"
    private val FUEL_TOKEN = "[LY]"

    fun showSupplyNotification(supplyDaysRemaining: Float, areRunningOutOfSupplies: Boolean, alarmSuppliesDays: Float, lowSuppliesDays: Float) {
        val supplyHighlightColor = if (areRunningOutOfSupplies) {
            Misc.getNegativeHighlightColor()
        } else {
            if (supplyDaysRemaining <= alarmSuppliesDays) Misc.getNegativeHighlightColor()
            else if (supplyDaysRemaining <= lowSuppliesDays) Misc.getHighlightColor()
            else Misc.getPositiveHighlightColor()
        }

        val suDisplay = roundToTenthsPlace(supplyDaysRemaining)
        sector?.campaignUI?.addMessage(
            ExternalStrings.NOTIFICATION_SUPPLY_DISPLAY.replace(SUPPLY_TOKEN, suDisplay.toString()),
            Misc.getTextColor(),
            ExternalStrings.NOTIFICATION_SUPPLY_DISPLAY_HL.replace(SUPPLY_TOKEN, suDisplay.toString()),
            "",
            supplyHighlightColor,
            Misc.getTextColor()
        )
    }

    fun showFuelLYNotification(fuelLY: Float, lowFuelLY: Float, alarmFuelLY: Float) {
        val fuelHighlightColor = if (fuelLY <= alarmFuelLY) Color.RED
            else if (fuelLY <= lowFuelLY) Color.ORANGE
            else Color.GREEN

        val lyDisplay = roundToTenthsPlace(fuelLY)
        sector?.campaignUI?.addMessage(
            ExternalStrings.NOTIFICATION_FUEL_DISPLAY.replace(FUEL_TOKEN, lyDisplay.toString()),
            Misc.getTextColor(),
            ExternalStrings.NOTIFICATION_FUEL_DISPLAY_HL.replace(FUEL_TOKEN, lyDisplay.toString()),
            "",
            fuelHighlightColor,
            Misc.getTextColor()
        )
    }

    fun playAlarmSound(config: AlarmSoundConfig, supplyAlarm: Boolean, fuelAlarm: Boolean, initialAlarm: Boolean) {
        if (!config.useSoundAlarm) return
        if (!supplyAlarm && !fuelAlarm) return
        val soundId: String?
        val volume: Float
        if (initialAlarm) {
            volume = 1f
            soundId = if (supplyAlarm && fuelAlarm) config.generalAlarmId
            else if (supplyAlarm) config.supplyAlarmId
            else config.fuelAlarmId
        } else {
            volume = 0.2f
            soundId = if (supplyAlarm && fuelAlarm) config.generalFollowupId
            else if (supplyAlarm) config.supplyFollowupId
            else config.fuelFollowupId
        }
        try {
            soundPlayer?.playUISound(soundId, 1f, volume)
        } catch (_: Exception) {}
    }

    fun roundToTenthsPlace(number: Float): Float = (number * 10f).toInt() / 10f

    fun isSupplyAlarm(areRunningOutOfSupplies: Boolean, supplyDays: Float, alarmSupplyDays: Int): Boolean {
        return areRunningOutOfSupplies || supplyDays <= alarmSupplyDays
    }

    fun isFuelAlarm(fuelLy: Float, alarmFuelLY: Int): Boolean {
        return fuelLy <= alarmFuelLY
    }
}
