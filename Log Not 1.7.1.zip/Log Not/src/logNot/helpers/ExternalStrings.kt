package logNot.helpers

import java.lang.Exception

object ExternalStrings {
    const val DEBUG_NULL = "NULL"

    private const val STRINGS = "data/strings/strings.json"

    private const val ID = "logNot"
    private fun get(id: String): String {
        return Helper.settings?.getString(ID, id) ?: "N/A $id"
    }

    private fun getList(id: String): List<String> {
        val result = mutableSetOf<String>()
        try {
            val json = Helper.settings?.loadJSON(STRINGS, Helper.modId)
            val array = json?.getJSONObject(ID)?.getJSONArray(id) ?: throw NullPointerException()
            for (i in array.length() - 1 downTo 0 ) result += array.get(i).toString()
        } catch (ex: Exception) {
            return listOf(DEBUG_NULL)
        }
        return result.toList()
    }

    val LAZY_LIB_REQ = get("lazyLibReq")
    val HINT_DISPLAY = get("hintDisplay")
    val HINT_DISPLAY_HL = get("hintDisplayHL")
    val NOTIFICATION_SUPPLY_DISPLAY = get("notificationSupplyDisplay")
    val NOTIFICATION_SUPPLY_DISPLAY_HL = get("notificationSupplyDisplayHL")
    val NOTIFICATION_FUEL_DISPLAY = get("notificationFuelDisplay")
    val NOTIFICATION_FUEL_DISPLAY_HL = get("notificationFuelDisplayHL")
    val DISPLAY_SUPPLY_FUEL_COMMAND = get("displaySupplyFuelCommand")
}