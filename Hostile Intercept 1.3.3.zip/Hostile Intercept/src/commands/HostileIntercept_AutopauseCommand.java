package commands;

import com.fs.starfarer.api.Global;
import static ids.HostileIntercept_Settings.*;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;

/**
 * Author: SafariJohn
 *
 * Syntax:
 * hi_autopause status|on|off|noAlarm|alarmOnly|ifIntercept|ifInterceptNoAlarm
 */
public class HostileIntercept_AutopauseCommand implements BaseCommand {

    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }

        args = args.toLowerCase().trim();

        if (args.isEmpty()) {
            return CommandResult.BAD_SYNTAX;
        }

        String[] tmp = args.split(" ");

        if (tmp.length != 1) {
            return CommandResult.BAD_SYNTAX;
        }

        switch (tmp[0]) {
            case "status":
                isAutopause();
                isInterceptOnly();
                isAlarm();
                break;
            case "on":
                setAutopause(true);
                setInterceptOnly(false);
                setAlarm(true);
                break;
            case "off":
                setAutopause(false);
                setInterceptOnly(false);
                setAlarm(false);
                break;
            case "noAlarm":
                setAutopause(true);
                setInterceptOnly(false);
                setAlarm(false);
                break;
            case "alarmOnly":
                setAutopause(false);
                setInterceptOnly(false);
                setAlarm(true);
                break;
            case "ifIntercept":
                setAutopause(true);
                setInterceptOnly(true);
                setAlarm(true);
                break;
            case "ifInterceptNoAlarm":
                setAutopause(true);
                setInterceptOnly(true);
                setAlarm(false);
                break;
            default: return CommandResult.BAD_SYNTAX;
        }

        return CommandResult.SUCCESS;
    }

    private void setAutopause(boolean enabled) {
        Global.getSector().getMemoryWithoutUpdate().set("$" + AUTOPAUSE_KEY, enabled);
        isAutopause();
    }

    private void setInterceptOnly(boolean enabled) {
        Global.getSector().getMemoryWithoutUpdate().set("$" + AUTOPAUSE_INTERCEPT_KEY, enabled);
        isInterceptOnly();
    }

    private void setAlarm(boolean enabled) {
        Global.getSector().getMemoryWithoutUpdate().set("$" + ALARM_KEY, enabled);
        isAlarm();
    }

    private boolean isAutopause() {
        boolean enabled = Global.getSector().getMemoryWithoutUpdate().getBoolean("$" + AUTOPAUSE_KEY);
        if (enabled) Console.showMessage("Autopause enabled");
        else Console.showMessage("Autopause disabled");
        return enabled;
    }

    private boolean isInterceptOnly() {
        boolean enabled = Global.getSector().getMemoryWithoutUpdate().getBoolean("$" + AUTOPAUSE_KEY);
        if (enabled) Console.showMessage("- only if interceptor detected");
        return enabled;
    }

    private boolean isAlarm() {
        boolean enabled = Global.getSector().getMemoryWithoutUpdate().getBoolean("$" + ALARM_KEY);
        if (enabled) Console.showMessage("- alarm enabled");
        else Console.showMessage("- alarm disabled");
        return enabled;
    }

}
