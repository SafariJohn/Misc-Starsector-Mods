package commands;

import com.fs.starfarer.api.Global;
import org.lazywizard.console.BaseCommand;
import org.lazywizard.console.CommonStrings;
import org.lazywizard.console.Console;
import static ids.HostileIntercept_Settings.*;

/**
 * Author: SafariJohn
 *
 * hi_jumppause status|on|off|noAlarm|ifThreatened|ifThreatenedNoAlarm
 */
public class HostileIntercept_JumpPauseCommand implements BaseCommand {

    @Override
    public CommandResult runCommand(String args, CommandContext context) {
        if (!context.isInCampaign()) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY);
            return CommandResult.WRONG_CONTEXT;
        }

        args = args.toLowerCase().trim();

        if (args.isEmpty()) {
            return CommandResult.BAD_SYNTAX;
        }

        String[] tmp = args.split(" ");

        if (tmp.length != 1) {
            return CommandResult.BAD_SYNTAX;
        }

        switch (tmp[0]) {
            case "status":
                isJumpPause();
                isThreatened();
                isAlarm();
                break;
            case "on":
                setJumpPause(true);
                setThreatened(false);
                setAlarm(true);
                break;
            case "off":
                setJumpPause(false);
                setThreatened(false);
                setAlarm(false);
                break;
            case "noAlarm":
                setJumpPause(true);
                setThreatened(false);
                setAlarm(false);
                break;
            case "ifThreatened":
                setJumpPause(true);
                setThreatened(true);
                setAlarm(true);
                break;
            case "ifThreatenedNoAlarm":
                setJumpPause(true);
                setThreatened(true);
                setAlarm(false);
                break;
            default: return CommandResult.BAD_SYNTAX;
        }

        return CommandResult.SUCCESS;
    }

    private void setJumpPause(boolean enabled) {
        Global.getSector().getMemoryWithoutUpdate().set("$" + JUMP_PAUSE_KEY, enabled);
        isJumpPause();
    }

    private void setAlarm(boolean enabled) {
        Global.getSector().getMemoryWithoutUpdate().set("$" + JUMP_PAUSE_ALARM_KEY, enabled);
        isAlarm();
    }

    private void setThreatened(boolean enabled) {
        Global.getSector().getMemoryWithoutUpdate().set("$" + JUMP_PAUSE_THREATS_KEY, enabled);
        isThreatened();
    }

    private boolean isJumpPause() {
        boolean enabled = Global.getSector().getMemoryWithoutUpdate().getBoolean("$" + JUMP_PAUSE_KEY);
        if (enabled) Console.showMessage("Jump pause enabled");
        else Console.showMessage("Jump pause disabled");
        return enabled;
    }

    private boolean isAlarm() {
        boolean enabled = Global.getSector().getMemoryWithoutUpdate().getBoolean("$" + JUMP_PAUSE_ALARM_KEY);
        if (enabled) Console.showMessage("- alarm enabled");
        else Console.showMessage("- alarm disabled");
        return enabled;
    }

    private boolean isThreatened() {
        boolean enabled = Global.getSector().getMemoryWithoutUpdate().getBoolean("$" + JUMP_PAUSE_THREATS_KEY);
        if (enabled) Console.showMessage("- only if threat");
//        else Console.showMessage("Autopause disabled");
        return enabled;
    }
}