package hostileIntercept.commands

import hostileIntercept.helpers.ExternalStrings
import hostileIntercept.helpers.Helper
import hostileIntercept.helpers.Settings
import hostileIntercept.helpers.Settings.toKey
import org.lazywizard.console.BaseCommand
import org.lazywizard.console.BaseCommand.CommandContext
import org.lazywizard.console.BaseCommand.CommandResult
import org.lazywizard.console.CommonStrings
import org.lazywizard.console.Console
import java.util.*

/**
 * Author: SafariJohn
 *
 * hi_interceptalarm
 */
class InterceptAlarmCommand : BaseCommand {
    override fun runCommand(args: String, context: CommandContext): CommandResult {
        if (!context.isInCampaign) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY)
            return CommandResult.WRONG_CONTEXT
        }
        val argsEmpty = args.lowercase(Locale.getDefault()).trim { it <= ' ' }.isEmpty()
        if (!argsEmpty) return CommandResult.BAD_SYNTAX
        setAlarm(!Settings.isFeatureEnabled(Settings.INTERCEPT_ALARM_KEY))
        return CommandResult.SUCCESS
    }

    private fun setAlarm(enabled: Boolean) {
        Helper.sector?.memoryWithoutUpdate?.set(Settings.INTERCEPT_ALARM_KEY.toKey(), enabled)
        if (enabled) Console.showMessage(ExternalStrings.INTERCEPT_ALARM_ENABLED)
        else Console.showMessage(ExternalStrings.INTERCEPT_ALARM_DISABLED)
    }
}