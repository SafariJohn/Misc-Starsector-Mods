package hostileIntercept.commands

import hostileIntercept.helpers.ExternalStrings
import hostileIntercept.helpers.Helper
import hostileIntercept.helpers.Memory
import hostileIntercept.helpers.Settings
import hostileIntercept.helpers.Settings.toKey
import org.lazywizard.console.BaseCommand
import org.lazywizard.console.BaseCommand.CommandContext
import org.lazywizard.console.BaseCommand.CommandResult
import org.lazywizard.console.CommonStrings
import org.lazywizard.console.Console
import java.util.*

/**
 * Author: SafariJohn
 *
 * Syntax:
 * hi_autopause status|on|off|noAlarm|alarmOnly|ifIntercept|ifInterceptNoAlarm
 */
class AutopauseCommand : BaseCommand {
    companion object {
        const val STATUS = "status"
        const val ON = "on"
        const val OFF = "off"
        const val NO_ALARM = "noAlarm"
        const val ALARM_ONLY = "alarmOnly"
        const val INTERCEPT = "ifIntercept"
        const val INTERCEPT_NO_ALARM = "ifInterceptNoAlarm"
    }
    
    
    override fun runCommand(args: String, context: CommandContext): CommandResult {
        val cleanArgs = args.lowercase(Locale.getDefault()).trim { it <= ' ' }
        if (!context.isInCampaign) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY)
            return CommandResult.WRONG_CONTEXT
        }
        if (cleanArgs.isEmpty()) {
            return CommandResult.BAD_SYNTAX
        }
        val tmp = cleanArgs.split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        if (tmp.size != 1) {
            return CommandResult.BAD_SYNTAX
        }
        when (tmp[0]) {
            STATUS -> {}
            ON -> {
                setAutopause(true)
                setIntercept(false)
                setAlarm(true)
            }
            OFF -> {
                setAutopause(false)
                setAlarm(false)
            }
            NO_ALARM -> {
                setAutopause(true)
                setIntercept(false)
                setAlarm(false)
            }
            ALARM_ONLY -> {
                setAutopause(false)
                setAlarm(true)
            }
            INTERCEPT -> {
                setIntercept(true)
                setAlarm(true)
            }
            INTERCEPT_NO_ALARM -> {
                setIntercept(true)
                setAlarm(false)
            }
            else -> return CommandResult.BAD_SYNTAX
        }
        status()
        return CommandResult.SUCCESS
    }

    private fun status() {
        autopauseStatus()
        interceptStatus()
        alarmStatus()
    }

    private fun setAutopause(enabled: Boolean) {
        Helper.sector?.memoryWithoutUpdate?.set(Settings.AUTOPAUSE_KEY.toKey(), enabled)
        if (!enabled) setIntercept(false)
    }

    private fun setIntercept(enabled: Boolean) {
        if (enabled) setAutopause(true)
        Helper.sector?.memoryWithoutUpdate?.set(Settings.AUTOPAUSE_INTERCEPT_KEY.toKey(), enabled)
    }

    private fun setAlarm(enabled: Boolean) {
        Helper.sector?.memoryWithoutUpdate?.set(Settings.ALARM_KEY.toKey(), enabled)
    }

    private fun autopauseStatus() {
        val enabled = Memory.isFlag(Settings.AUTOPAUSE_KEY.toKey())
        if (enabled) Console.showMessage(ExternalStrings.AUTOPAUSE_ENABLED)
        else Console.showMessage(ExternalStrings.AUTOPAUSE_DISABLED)
    }

    private fun interceptStatus() {
        val enabled = Memory.isFlag(Settings.AUTOPAUSE_INTERCEPT_KEY.toKey())
        if (enabled) Console.showMessage(ExternalStrings.INTERCEPT_ENABLED)
    }

    private fun alarmStatus() {
        val enabled = Memory.isFlag(Settings.ALARM_KEY.toKey())
        if (enabled) Console.showMessage(ExternalStrings.AUTOPAUSE_ALARM_ENABLED)
        else Console.showMessage(ExternalStrings.AUTOPAUSE_ALARM_DISABLED)
    }
}