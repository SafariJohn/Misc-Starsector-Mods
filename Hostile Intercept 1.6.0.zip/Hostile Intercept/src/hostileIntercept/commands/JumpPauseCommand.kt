package hostileIntercept.commands

import hostileIntercept.helpers.ExternalStrings
import hostileIntercept.helpers.Helper
import hostileIntercept.helpers.Memory
import hostileIntercept.helpers.Settings
import hostileIntercept.helpers.Settings.toKey
import org.lazywizard.console.BaseCommand
import org.lazywizard.console.BaseCommand.CommandContext
import org.lazywizard.console.BaseCommand.CommandResult
import org.lazywizard.console.CommonStrings
import org.lazywizard.console.Console
import java.util.*

/**
 * Author: SafariJohn
 *
 * hi_jumppause status|on|off|noAlarm|ifThreatened|ifThreatenedNoAlarm
 */
class JumpPauseCommand : BaseCommand {
    companion object {
        const val STATUS = "status"
        const val ON = "on"
        const val OFF = "off"
        const val NO_ALARM = "noAlarm"
        const val THREATENED = "ifThreatened"
        const val THREATENED_NO_ALARM = "ifThreatenedNoAlarm"
    }

    override fun runCommand(args: String, context: CommandContext): CommandResult {
        val cleanArgs = args.lowercase(Locale.getDefault()).trim { it <= ' ' }
        if (!context.isInCampaign) {
            Console.showMessage(CommonStrings.ERROR_CAMPAIGN_ONLY)
            return CommandResult.WRONG_CONTEXT
        }
        if (cleanArgs.isEmpty()) {
            return CommandResult.BAD_SYNTAX
        }
        val tmp = cleanArgs.split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        if (tmp.size != 1) {
            return CommandResult.BAD_SYNTAX
        }
        when (tmp[0]) {
            STATUS -> {}
            ON -> {
                setJumpPause(true)
                setThreatened(false)
                setAlarm(true)
                status()
            }
            OFF -> {
                setJumpPause(false)
            }
            NO_ALARM -> {
                setJumpPause(true)
                setThreatened(false)
                setAlarm(false)
            }
            THREATENED -> {
                setJumpPause(true)
                setThreatened(true)
                setAlarm(true)
            }
            THREATENED_NO_ALARM -> {
                setJumpPause(true)
                setThreatened(true)
                setAlarm(false)
            }
            else -> return CommandResult.BAD_SYNTAX
        }
        status()
        return CommandResult.SUCCESS
    }

    private fun status() {
        jumpPauseStatus()
        threatenedStatus()
        alarmStatus()
    }

    private fun setJumpPause(enabled: Boolean) {
        Memory.set(Settings.JUMP_PAUSE_KEY.toKey(), enabled)
        Helper.sector?.memoryWithoutUpdate?.set(Settings.JUMP_PAUSE_KEY.toKey(), enabled)
        setThreatened(false)
        setAlarm(false)
    }

    private fun setAlarm(enabled: Boolean) {
        if (enabled) setJumpPause(true)
        Helper.sector?.memoryWithoutUpdate?.set(Settings.JUMP_PAUSE_ALARM_KEY.toKey(), enabled)
    }

    private fun setThreatened(enabled: Boolean) {
        if (enabled) setJumpPause(true)
        Helper.sector?.memoryWithoutUpdate?.set(Settings.JUMP_PAUSE_THREATS_KEY.toKey(), enabled)
    }

    private fun jumpPauseStatus() {
        val enabled = Memory.isFlag(Settings.JUMP_PAUSE_KEY.toKey())
        if (enabled) Console.showMessage(ExternalStrings.JUMP_PAUSE_ENABLED)
        else Console.showMessage(ExternalStrings.JUMP_PAUSE_DISABLED)
    }

    private fun alarmStatus() {
        val enabled = Memory.isFlag(Settings.JUMP_PAUSE_ALARM_KEY.toKey())
        if (enabled) Console.showMessage(ExternalStrings.JUMP_PAUSE_ALARM_ENABLED)
        else Console.showMessage(ExternalStrings.JUMP_PAUSE_ALARM_DISABLED)
    }

    private fun threatenedStatus() {
        val enabled = Memory.isFlag(Settings.JUMP_PAUSE_THREATS_KEY.toKey())
        if (enabled) Console.showMessage(ExternalStrings.THREATENED_ENABLED)
    }
}