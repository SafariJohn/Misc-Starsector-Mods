package hostileIntercept.commands

import org.lazywizard.console.BaseCommand
import org.lazywizard.console.Console

class HostileInterceptCommand : BaseCommand {
    // What is needed
    /**
     * Help command
     * - default
     *
     * Hostile rings boolean
     * Intercept rings boolean
     * intercept alarm boolean
     * intercept cheat boolean
     *
     *
     */

    companion object {
        const val TRUE_FALSE = "[true/false]"

        private val HOSTILITY_RINGS = OptionData(
            "rh", "Hostility Rings", TRUE_FALSE,
            "Show rings around hostile fleets."
        )
        private val INTERCEPT_RINGS = OptionData(
            "ri", "Intercept Rings", TRUE_FALSE,
            "Show rings around fleets trying to intercept you."
        )
        private val INTERCEPT_ALARM = OptionData(
            "ria", "Intercept Alarm", TRUE_FALSE,
            "Sound an alarm when your fleet detects a fleet intercepting yours."
        )
        private val RING_CHEAT = OptionData(
            "rc","Show On Contacts (Cheat)", TRUE_FALSE,
            "Show hostile/intercept rings on sensor contacts."
        )

        private val AP_OPTIONS = listOf("Disabled", "AllContacts", "InterceptOrHostile", "InterceptOnly")
        private val AUTOPAUSE = OptionData(
            "a","Autopause", "[$AP_OPTIONS]",
            "While on autopilot, pause when a sensor contact is detected or when a fleet begins intercepting your fleet."
        )
        private val AUTOPAUSE_ALARM = OptionData(
            "aa","Autopause Alarm", TRUE_FALSE,
            "Sound an alarm when autopause activates, or would activate if disabled."
        )
        private val AUTOPAUSE_SNOOZE = OptionData(
            "as","Snooze Time", "[0-100]",
            "Real-time seconds after unpausing before autopause can activate."
        )
        private val AUTOPAUSE_CHEAT = OptionData(
            "ac","Autopause On Contacts (Cheat)", TRUE_FALSE,
            "Check if sensor contacts are hostile or intercepting."
        )

        private val JP_OPTIONS = listOf("Disabled", "Always", "AllContacts", "InterceptOrHostile")
        private val JUMP_PAUSE = OptionData(
            "jp","Jump Pause", "[$JP_OPTIONS]",
            "Pause when jumping while on autopilot."
        )
        private val JUMP_THREAT_ALARM = OptionData(
            "jpa","Jump Threat Alarm", TRUE_FALSE,
            "Sound an alarm when jump pause activates."
        )
        private val JUMP_PAUSE_CHEAT = OptionData(
            "jpc","Jump Pause On Contacts (Cheat)", TRUE_FALSE,
            "Check if sensor contacts are hostile or intercepting."
        )
    }

    private data class OptionData(val id: String, val name: String, val options: String, val desc: String) {
        override fun toString(): String {
            return "$id - $name $options\n$desc"
        }
    }

    override fun runCommand(args: String, context: BaseCommand.CommandContext): BaseCommand.CommandResult {
        if (context.isInCombat) return BaseCommand.CommandResult.WRONG_CONTEXT
//        when (args.split(" ").first()) {
//            HOSTILITY_RINGS.id ->
//        }
        if (args.isEmpty()) {
            showHelp()
        }

        return BaseCommand.CommandResult.SUCCESS
    }

    private fun showHelp() {
        val result = "HI_Settings help:\n" +
                "$HOSTILITY_RINGS\n" +
                "$INTERCEPT_RINGS\n" +
                "$INTERCEPT_ALARM\n" +
                "$RING_CHEAT\n" +
                "\n"
                "$AUTOPAUSE\n" +
                "$AUTOPAUSE_ALARM\n" +
                "$AUTOPAUSE_SNOOZE\n" +
                "$AUTOPAUSE_CHEAT\n" +
                "\n" +
                "$JUMP_PAUSE\n" +
                "$JUMP_THREAT_ALARM\n" +
                "$JUMP_PAUSE_CHEAT\n"
        Console.showMessage(result)
    }
}