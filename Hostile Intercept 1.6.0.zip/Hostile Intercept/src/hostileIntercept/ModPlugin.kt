package hostileIntercept

import com.fs.starfarer.api.BaseModPlugin
import com.fs.starfarer.api.util.Misc
import hostileIntercept.helpers.Helper
import hostileIntercept.helpers.Ids
import hostileIntercept.helpers.Settings
import hostileIntercept.helpers.Settings.toKey
import hostileIntercept.scripts.*
import hostileIntercept.helpers.ExternalStrings

class ModPlugin : BaseModPlugin() {
    companion object {
        const val BOOLEAN_CHECK_INTERVAL = 10f // Seconds
        private const val SYNC_KEY = "\$hostileIntercept_syncKey"

        @Transient
        var hasLunaLib = false
    }

    /**
     * Adding LunaLib support to Hostile Intercept
     *
     *
     * What settings are there?
     * Key to toggle autopause? - keycode - need to implement
     *
     *
     *
     * Need to touch up console commands for those without LunaLib
     * And need to adjust settings.json to match LunaLib
     *
     *
     */


    private var syncId: String? = null

    @Throws(Exception::class)
    override fun onApplicationLoad() {
        if (!Helper.isModEnabled(Ids.LAZY_LIB)) throw RuntimeException(ExternalStrings.LAZY_LIB_REQ)
        syncId = Misc.genUID()
        hasLunaLib = Helper.isModEnabled(Ids.LUNA_LIB)
    }

    override fun onGameLoad(newGame: Boolean) {
//        syncWithSettings()
        if (Helper.sector?.hasScript(HostilityRings::class.java) == false) {
            Helper.sector?.addTransientScript(HostilityRings())
        }
        if (Helper.sector?.hasScript(InterceptRings::class.java) == false) {
            Helper.sector?.addTransientScript(InterceptRings())
        }
        if (Helper.sector?.hasScript(JumpPointPause::class.java) == false) {
            Helper.sector?.addTransientScript(JumpPointPause())
        }
        if (Helper.sector?.hasScript(Autopause::class.java) == false) {
            Helper.sector?.addTransientScript(Autopause())
        }
    }

    private fun syncWithSettings() {
        val memory = Helper.sector?.memoryWithoutUpdate ?: return

        if (memory.contains(SYNC_KEY) && syncId == memory.getString(SYNC_KEY)) return

        memory[SYNC_KEY] = syncId

        memory[Settings.ALARM_KEY.toKey()] = Helper.settings?.getBoolean(Settings.ALARM_KEY)
        memory[Settings.AUTOPAUSE_KEY.toKey()] = Helper.settings?.getBoolean(Settings.AUTOPAUSE_KEY)
        memory[Settings.INTERCEPT_ALARM_KEY.toKey()] = Helper.settings?.getBoolean(Settings.INTERCEPT_ALARM_KEY)

        val jumpPause = Helper.settings?.getBoolean(Settings.JUMP_PAUSE_KEY) == true
        var ifThreatened = Helper.settings?.getBoolean(Settings.JUMP_PAUSE_THREATS_KEY) == true
        var jumpAlarm = Helper.settings?.getBoolean(Settings.JUMP_PAUSE_ALARM_KEY) == true
        if (!jumpPause) {
            ifThreatened = false
            jumpAlarm = false
        }

        memory[Settings.JUMP_PAUSE_KEY.toKey()] = jumpPause
        memory[Settings.JUMP_PAUSE_THREATS_KEY.toKey()] = ifThreatened
        memory[Settings.JUMP_PAUSE_ALARM_KEY.toKey()] = jumpAlarm
    }
}