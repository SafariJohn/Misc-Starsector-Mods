package hostileIntercept.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.campaign.CampaignFleetAPI
import com.fs.starfarer.api.campaign.JumpPointAPI
import com.fs.starfarer.api.campaign.PlanetAPI
import com.fs.starfarer.api.campaign.SectorEntityToken
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel
import com.fs.starfarer.api.campaign.ai.FleetAIFlags
import com.fs.starfarer.api.loading.CampaignPingSpec
import com.fs.starfarer.api.util.Misc
import hostileIntercept.helpers.Helper
import hostileIntercept.ModPlugin
import hostileIntercept.helpers.ExternalStrings
import hostileIntercept.helpers.Memory
import hostileIntercept.helpers.Settings

class Autopause : EveryFrameScript {

    val IGNORE_KEY = "\$hostileIntercept_autopauseTimeout"
    val EXPIRATION = 30f // seconds


    val INTERVAL = 0.1f
    val PAUSE_DELAY = 0.3f

    enum class Mode {
        DISABLED,
        ALL_CONTACTS,
        HOSTILE_OR_INTERCEPT,
        INTERCEPT_ONLY
    }

    private var mode = Settings.loadAutopauseMode()

    private var withSound = Settings.isFeatureEnabled(Settings.ALARM_KEY)

    private var interval = 0f
    private var booleansInterval = 0f
    private var pausing = false

    private var snoozed = false
    private var snoozeDelay = Settings.SNOOZE_TIME
    private var snoozeInterval = 0f

    override fun advance(amount: Float) {
        if (Helper.isSectorPaused) {
            pausing = false
            return
        }
        interval += amount
        booleansInterval += amount
        if (booleansInterval >= ModPlugin.BOOLEAN_CHECK_INTERVAL) {
            booleansInterval -= ModPlugin.BOOLEAN_CHECK_INTERVAL
            mode = Settings.loadAutopauseMode()
            withSound = Settings.isFeatureEnabled(Settings.ALARM_KEY)
            snoozeDelay = Settings.SNOOZE_TIME
        }
        if (pausing) {
            if (interval > PAUSE_DELAY) {
                interval -= PAUSE_DELAY
                Helper.sector?.isPaused = true
                pausing = false
            }
            return
        }
        if (interval < INTERVAL) return
        snoozeInterval += interval
        interval -= INTERVAL
        if (snoozed && snoozeInterval > snoozeDelay) {
            snoozeInterval = 0f
            snoozed = false
        }

        // Autopause only works while following a course
        if (!onCourse()) return

        // Check all entities
        val entities = Helper.sector?.playerFleet?.containingLocation?.allEntities ?: emptyList()
        for (entity in entities) {
            // Ignore planets and stuff
            if (entity is PlanetAPI) continue

            // Ignore it if has ignore key
            if (entity.memoryWithoutUpdate.contains(IGNORE_KEY)) {
                if (entity.memoryWithoutUpdate.getExpire(IGNORE_KEY) <= EXPIRATION) {
                    entity.memoryWithoutUpdate[IGNORE_KEY, true] = EXPIRATION
                }
                continue
            }

            // Must be visible
            val vis = entity.visibilityLevelToPlayerFleet
            if (vis == VisibilityLevel.NONE) continue

            // Ignore transient objects (cargo pods and battlefield debris)
            if (entity.faction.isNeutralFaction && !entity.isDiscoverable) continue

            // Pause for sensor contacts and unknown fleets
            if (mode == Mode.ALL_CONTACTS && (vis == VisibilityLevel.COMPOSITION_DETAILS
                || vis == VisibilityLevel.SENSOR_CONTACT)
            ) {
                pause(entity)
                return
            }

            // Pause for intercepting fleets
            // Must be a fleet
            if (entity !is CampaignFleetAPI) continue
            // Must be visible
            if ((vis == VisibilityLevel.SENSOR_CONTACT && !Settings.isFeatureEnabled(Settings.CHEAT_AUTOPAUSE))) continue

            if (Helper.entityIsHostile(entity) || Helper.entityIsTargetingPlayer(entity)) {
                pause(entity)
                return
            }
        }
    }

    private fun onCourse(): Boolean {
        val courseTarget = Helper.sector?.uiData?.courseTarget
        val interactionTarget = Helper.sector?.playerFleet?.interactionTarget
        val onCourse = courseTarget != null && courseTarget === interactionTarget
        return onCourse or (courseTarget != null && interactionTarget is JumpPointAPI)
    }

    private fun pause(cause: SectorEntityToken) {
        if (mode == Mode.INTERCEPT_ONLY && !isEntityIntercepting(cause)) return
        Helper.sector?.campaignUI?.messageDisplay?.addMessage(ExternalStrings.POTENTIAL_THREAT)
        cause.memoryWithoutUpdate[IGNORE_KEY, true] = EXPIRATION
        if (snoozed) return
        if (mode != Mode.DISABLED) pausing = true
        snoozed = true
        snoozeInterval = 0f
        pingAndSound(cause)
    }

    private fun isEntityIntercepting(entity: SectorEntityToken): Boolean {
        return if (entity is CampaignFleetAPI) {
            // Fleet intent is visible
            val vis = entity.visibilityLevelToPlayerFleet
            val visible = (vis == VisibilityLevel.COMPOSITION_DETAILS
                    || vis == VisibilityLevel.COMPOSITION_AND_FACTION_DETAILS)

            // Fleet is targeting the player's fleet
            val target = Memory.getNullable(
                FleetAIFlags.PURSUIT_TARGET,
                entity,
                { it is SectorEntityToken },
                { null }
            ) as? SectorEntityToken
            visible and (target === Helper.sector?.playerFleet)
        } else {
            false
        }
    }

    private fun pingAndSound(entity: SectorEntityToken) {
        if (withSound) {
            val soundId = Helper.settings?.getString(Settings.ALARM_SOUND_KEY)
            try { // Play nothing if the soundId is invalid
                Helper.soundPlayer?.playUISound(soundId, 1f, 1f)
            } catch (_: RuntimeException) {}
        }
        val color = Misc.getHighlightColor()
        val range = entity.radius
        val custom = CampaignPingSpec().apply {
            this.color = color
            this.isUseFactionColor = false
            this.width = Math.max(range / 5, 10f)
            this.minRange = range / 2
            this.range = range * 10
            this.duration = PAUSE_DELAY * 3
            this.alphaMult = 1f
            this.inFraction = 0.5f
            this.num = 2
            this.isInvert = true
        }
        Helper.sector?.addPing(entity, custom)
    }

    override fun isDone(): Boolean = false
    override fun runWhilePaused(): Boolean = false
}