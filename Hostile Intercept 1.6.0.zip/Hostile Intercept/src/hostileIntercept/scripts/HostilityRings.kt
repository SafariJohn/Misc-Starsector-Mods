package hostileIntercept.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.campaign.CampaignFleetAPI
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.loading.CampaignPingSpec
import hostileIntercept.helpers.Helper
import hostileIntercept.helpers.Ids
import hostileIntercept.helpers.Memory
import hostileIntercept.helpers.Settings
import java.awt.Color

class HostilityRings : EveryFrameScript {
    companion object {
        val HOSTILE_COLOR = Color(255, 0, 0, 255)
        const val INTERVAL = .2f
    }
    
    private var interval = 0f

    override fun advance(amount: Float) {
        if (Helper.isSectorPaused) return
        interval += amount
        if (interval < INTERVAL) return
        interval -= INTERVAL
        val fleets = Helper.sector?.playerFleet?.containingLocation?.fleets ?: return
        for (fleet in fleets) {
            if (fleet.isDespawning) continue
            if (!fleet.isAlive) continue
            if (fleet.isPlayerFleet) continue
            if (fleet.isEmpty) continue
            if (isUndiscoveredStation(fleet)) continue
            val vis = fleet.visibilityLevelToPlayerFleet
            if ((vis == VisibilityLevel.SENSOR_CONTACT && !Settings.isFeatureEnabled(Settings.CHEAT_RINGS))
                || vis != VisibilityLevel.COMPOSITION_AND_FACTION_DETAILS) continue
            if (!Helper.entityIsHostile(fleet)) continue
            val color = HOSTILE_COLOR
            val range = fleet.radius
            val custom = CampaignPingSpec().apply {
                this.color = color
                this.isUseFactionColor = false
                this.width = (range / 5).coerceAtLeast(10f)
                this.minRange = range / 2
                this.range = range
                this.duration = .6f
                this.alphaMult = 1f
                this.inFraction = 0.5f
                this.num = 1
            }
            Helper.sector?.addPing(fleet, custom)
        }
    }

    private fun isUndiscoveredStation(fleet: CampaignFleetAPI): Boolean {
        if (!fleet.isStationMode) return false
        if (fleet.isDiscoverable) return true
        val market = Memory.getNullable(Ids.STATION_MARKET_KEY, fleet, { it is MarketAPI }, { null }) as? MarketAPI
        return market?.primaryEntity?.isDiscoverable == true
    }

    override fun isDone(): Boolean = false

    override fun runWhilePaused(): Boolean = false
}