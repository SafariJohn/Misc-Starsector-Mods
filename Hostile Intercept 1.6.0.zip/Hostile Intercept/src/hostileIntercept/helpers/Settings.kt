package hostileIntercept.helpers

import hostileIntercept.ModPlugin
import hostileIntercept.scripts.Autopause
import hostileIntercept.scripts.JumpPointPause
import lunalib.lunaSettings.LunaSettings

object Settings {
    const val INTERCEPT_ALARM_KEY = "hostileIntercept_interceptAlarm"
    const val INTERCEPT_SOUND_KEY = "hostileIntercept_interceptSoundId"

    const val AUTOPAUSE_KEY = "hostileIntercept_autopause"
    const val AUTOPAUSE_HOSTILE_INTERCEPT_KEY = "hostileIntercept_InterceptAndHostile"
    const val AUTOPAUSE_INTERCEPT_KEY = "hostileIntercept_InterceptOnly"
    const val SNOOZED_TIME_KEY = "hostileIntercept_autopauseSnoozedTime"
    const val ALARM_KEY = "hostileIntercept_autopauseAlarm"
    const val ALARM_SOUND_KEY = "hostileIntercept_alarmSoundId"

    const val JUMP_PAUSE_KEY = "hostileIntercept_jumpPointPause"
    const val JUMP_PAUSE_ALARM_KEY = "hostileIntercept_jumpPointAlarm"
    const val JUMP_PAUSE_THREATS_KEY = "hostileIntercept_jumpPointPauseOnlyIfThreats"

    const val AUTOPAUSE_DISABLED = "Disabled"
    const val AUTOPAUSE_ALL = "All Contacts"
    const val AUTOPAUSE_HOSTILE_INTERCEPT = "Intercept Or Hostile"
    const val AUTOPAUSE_INTERCEPT = "Intercept Only"

    const val JUMP_PAUSE_DISABLED = "Disabled"
    const val JUMP_PAUSE_ALWAYS = "Always"
    const val JUMP_PAUSE_ALL_CONTACTS = "All Contacts"
    const val JUMP_PAUSE_THREATS = "Intercept Or Hostile"

    const val CHEAT_RINGS = "hostileIntercept_ringCheat"
    const val CHEAT_AUTOPAUSE = "hostileIntercept_autopauseCheat"
    const val CHEAT_JUMP_PAUSE = "hostileIntercept_jumpPauseCheat"

    val SNOOZE_TIME: Float
        get() {
            val key = SNOOZED_TIME_KEY
            val lunaSetting = if (ModPlugin.hasLunaLib) {
                LunaSettings.getFloat(Helper.modId, key)
            } else null
            return if (Memory.contains(key.toKey())) Memory.get(key.toKey(), { it is Float }, { 10f }) as Float
            else lunaSetting ?: Helper.settings?.getFloat(key) ?: 10f
        }

    fun loadAutopauseMode(): Autopause.Mode {
        val string = LunaSettings.getString(Helper.modId, AUTOPAUSE_KEY)
            ?: Helper.settings?.getString(AUTOPAUSE_KEY.toKey())
            ?: AUTOPAUSE_DISABLED
        return when (string) {
            AUTOPAUSE_ALL -> Autopause.Mode.ALL_CONTACTS
            AUTOPAUSE_HOSTILE_INTERCEPT -> Autopause.Mode.HOSTILE_OR_INTERCEPT
            AUTOPAUSE_INTERCEPT -> Autopause.Mode.INTERCEPT_ONLY
            else -> Autopause.Mode.DISABLED
        }
    }

    fun loadJumpPauseMode(): JumpPointPause.Mode {
        val string = LunaSettings.getString(Helper.modId, JUMP_PAUSE_KEY)
            ?: Helper.settings?.getString(JUMP_PAUSE_KEY.toKey())
            ?: JUMP_PAUSE_DISABLED
        return when (string) {
            JUMP_PAUSE_ALWAYS -> JumpPointPause.Mode.ALWAYS
            JUMP_PAUSE_ALL_CONTACTS -> JumpPointPause.Mode.ALL_CONTACTS
            JUMP_PAUSE_THREATS -> JumpPointPause.Mode.INTERCEPT_OR_HOSTILE
            else -> JumpPointPause.Mode.DISABLED
        }
    }

    fun isFeatureEnabled(key: String): Boolean {
        if (ModPlugin.hasLunaLib) {
            return when (key) {
                AUTOPAUSE_KEY -> LunaSettings.getString(Helper.modId, AUTOPAUSE_KEY) != AUTOPAUSE_DISABLED
                AUTOPAUSE_INTERCEPT_KEY -> LunaSettings.getString(Helper.modId, AUTOPAUSE_KEY) == AUTOPAUSE_INTERCEPT
                AUTOPAUSE_HOSTILE_INTERCEPT_KEY -> LunaSettings.getString(Helper.modId, AUTOPAUSE_KEY) == AUTOPAUSE_HOSTILE_INTERCEPT
                else -> LunaSettings.getBoolean(Helper.modId, key) ?: false
            }
        }
        return if (Memory.contains(key.toKey())) Memory.get(key.toKey(), { it is Boolean }, { false }) as Boolean
        else Helper.settings?.getBoolean(key) == true
    }

    fun String.toKey(): String = if (this.startsWith("$")) this else "$$this"
}