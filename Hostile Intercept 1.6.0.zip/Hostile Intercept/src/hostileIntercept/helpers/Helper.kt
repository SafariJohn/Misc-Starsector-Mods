package hostileIntercept.helpers

import com.fs.starfarer.api.Global
import com.fs.starfarer.api.SettingsAPI
import com.fs.starfarer.api.SoundPlayerAPI
import com.fs.starfarer.api.campaign.*
import com.fs.starfarer.api.campaign.ai.FleetAIFlags
import com.fs.starfarer.api.impl.campaign.ids.Factions
import com.fs.starfarer.api.impl.campaign.ids.MemFlags
import com.fs.starfarer.api.util.Misc
import java.util.*

object Helper {
    val modId: String
        get() {
            return if (isModEnabled(Ids.DEV_MOD_ID)) Ids.DEV_MOD_ID
            else if (isModEnabled(Ids.MOD_ID)) Ids.MOD_ID
            else {
                settings?.modManager?.enabledModsCopy?.firstOrNull { it.id.startsWith(Ids.MOD_ID) }?.id
                    ?: Ids.MOD_ID
            }
    }

    fun isModEnabled(id: String): Boolean {
        return settings?.modManager?.isModEnabled(id) == true
    }

    val random
        get() = Misc.random ?: Random()

    val isSectorPaused: Boolean
        get() = sector?.isPaused ?: true

    val sector: SectorAPI?
        get() = Global.getSector()

    val settings: SettingsAPI?
        get() = Global.getSettings()

    val soundPlayer: SoundPlayerAPI?
        get() = Global.getSoundPlayer()

    fun anyNull(vararg objects: Any?): Boolean {
        for (o in objects) {
            if (o == null) return true
        }

        return false
    }

    fun entityIsHostile(entity: SectorEntityToken): Boolean = entity.memoryWithoutUpdate.contains(MemFlags.MEMORY_KEY_MAKE_HOSTILE)
            || entity.faction.isHostileTo(Factions.PLAYER)

    fun entityIsTargetingPlayer(entity: SectorEntityToken): Boolean {
        return Memory.getNullable(
            FleetAIFlags.PURSUIT_TARGET,
            entity,
            { it is SectorEntityToken },
            { null }
        ) as? SectorEntityToken === sector?.playerFleet
    }
}
