package limitingConditions

import com.fs.starfarer.api.BaseModPlugin
import com.fs.starfarer.api.impl.campaign.procgen.PlanetConditionGenerator
import limitingConditions.campaign.cleanup.RadioChatterCleanup
import limitingConditions.campaign.procgen.GravityConditionGenerator
import limitingConditions.campaign.procgen.MagneticFieldScript
import limitingConditions.campaign.procgen.NativePopConditionScript
import limitingConditions.helpers.SectorGen

class ModPlugin : BaseModPlugin() {
    override fun onApplicationLoad() {
        PlanetConditionGenerator.generators["gravity"] = GravityConditionGenerator()
    }

    override fun onNewGameAfterEconomyLoad() {
        SectorGen.adjustCoreWorlds()
        MagneticFieldScript.run()
        NativePopConditionScript.run()
    }

    override fun onGameLoad(newGame: Boolean) {
        SectorGen.addMissingMicrogravityToStations()
        RadioChatterCleanup.run()
    }
}