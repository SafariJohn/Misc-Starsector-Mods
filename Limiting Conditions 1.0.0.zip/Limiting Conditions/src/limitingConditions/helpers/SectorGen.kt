package limitingConditions.helpers

import com.fs.starfarer.api.campaign.PlanetAPI
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel
import com.fs.starfarer.api.impl.campaign.ids.Conditions
import com.fs.starfarer.api.impl.campaign.ids.Industries
import com.fs.starfarer.api.impl.campaign.ids.Tags
import limitingConditions.campaign.ids.CoreWorlds
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.campaign.ids.PCIndustries
import limitingConditions.campaign.ids.StarSystems
import limitingConditions.campaign.procgen.GravityConditionGenerator


object SectorGen {
    @JvmField
    val CONDITIONS_WHITELIST_HORN = mutableListOf<String>()
    @JvmField
    val CONDITIONS_TO_ADD_HORN = mutableSetOf(
        Conditions.VERY_HOT,
        Conditions.NO_ATMOSPHERE,
        Conditions.TECTONIC_ACTIVITY,
        PCConditions.EXTREME_GRAVITY,
        Conditions.ORE_RICH,
        Conditions.RARE_ORE_RICH
    )

    @JvmField
    val CONDITIONS_WHITELIST_NIFLHEIM = mutableListOf<String>()
    @JvmField
    val CONDITIONS_TO_ADD_NIFLHEIM = mutableSetOf(
        Conditions.COLD,
        Conditions.EXTREME_WEATHER,
        Conditions.VOLATILES_PLENTIFUL,
        PCConditions.EXTREME_GRAVITY
    )

    @JvmField
    val CONDITIONS_WHITELIST_KUMARI_ARU = mutableListOf<String>()
    @JvmField
    val CONDITIONS_TO_ADD_KUMARI_ARU = mutableSetOf(
        Conditions.HOT,
        Conditions.INIMICAL_BIOSPHERE,
        PCConditions.CLOUD_SEA
    )

    @JvmField
    val CONDITIONS_WHITELIST_GAD = mutableListOf<String>()
    @JvmField
    val CONDITIONS_TO_ADD_GAD = mutableSetOf(
        Conditions.VOLATILES_DIFFUSE,
        Conditions.EXTREME_WEATHER,
        PCConditions.EXTREME_GRAVITY
    )
    

    @JvmField
    val FUEL_PLANT_CONDITION_BLACKLIST = mutableListOf<String>()
    @JvmField
    val MICROGRAVITY_BLACKLIST = mutableListOf<String>()

    fun addMissingMicrogravityToStations() {
        Helper.sector?.economy?.marketsCopy
            ?.filter { it.planetEntity == null }
            ?.filterNot { MICROGRAVITY_BLACKLIST.contains(it.primaryEntity?.id) }
            ?.filterNot { it.hasCondition(PCConditions.MICROGRAVITY) }
            ?.filter { it.primaryEntity?.hasTag(Tags.STATION) == true }
            ?.forEach {
                it.removeCondition(Conditions.LOW_GRAVITY)
                it.addCondition(PCConditions.MICROGRAVITY)
                if (it.surveyLevel == SurveyLevel.FULL) it.getCondition(PCConditions.MICROGRAVITY)?.isSurveyed = true
                it.reapplyConditions()
            }
    }


    fun adjustCoreWorlds() {
        purgeCoreWorldRandomSpecials()
        applyCoreWorldMicrogravity()
        addFuelPlantConditionToFuelProducers()
        setConditionMarkets()
        adjustCoreMarkets()

        /**
         * TODO
         * Hard Vacuum condition for stations? 50% hazard, growth penalty?
         *
         *
         * - Industrial States
         *   - comms request in low orbit and have leaders squabble? Before surveying.
         */
    }

    private fun setConditionMarkets() {
        setPlanetConditionMarket(CoreWorlds.HORN, CONDITIONS_WHITELIST_HORN, CONDITIONS_TO_ADD_HORN)
        setPlanetConditionMarket(CoreWorlds.NIFLHEIM, CONDITIONS_WHITELIST_NIFLHEIM, CONDITIONS_TO_ADD_NIFLHEIM)
        setPlanetConditionMarket(CoreWorlds.KUMARI_ARU, CONDITIONS_WHITELIST_KUMARI_ARU, CONDITIONS_TO_ADD_KUMARI_ARU)
        setPlanetConditionMarket(CoreWorlds.GAD, CONDITIONS_WHITELIST_GAD, CONDITIONS_TO_ADD_GAD)
    }

    private fun adjustCoreMarkets() {
        adjustCorePlanetMarket(CoreWorlds.NOMIOS, conditionsToAdd = setOf(PCConditions.CRYOVAULT))
        adjustCorePlanetMarket(
            CoreWorlds.AGREUS,
            conditionsToRemove = setOf(Conditions.RUINS_EXTENSIVE),
            industriesToRemove = setOf(Industries.TECHMINING),
            conditionsToAdd = setOf(PCConditions.GRAVEYARD),
            industriesToAdd = setOf(PCIndustries.SHIPBREAKERS)
        )
        adjustCorePlanetMarket(CoreWorlds.CHICO, conditionsToAdd = setOf(PCConditions.HIVE_CITIES))
        adjustCorePlanetMarket(CoreWorlds.COATL, conditionsToAdd = setOf(PCConditions.FORTRESS_WORLD))
        adjustCorePlanetMarket(CoreWorlds.CULANN, conditionsToAdd = setOf(PCConditions.FORTRESS_WORLD))
        adjustCorePlanetMarket(CoreWorlds.EOCHU_BRES, conditionsToAdd = setOf(Conditions.COLD, Conditions.EXTREME_WEATHER))
        adjustCorePlanetMarket(
            CoreWorlds.HESPERUS,
            industriesToRemove = setOf(Industries.LIGHTINDUSTRY),
            conditionsToAdd = setOf(PCConditions.FORTRESS_WORLD),
            industriesToAdd = setOf(Industries.FUELPROD)
        )
        adjustCorePlanetMarket(CoreWorlds.SKATHI, industriesToAdd = setOf(Industries.FUELPROD))
        adjustCoreEntityMarket(
            CoreWorlds.RAGNAR.entity,
            conditionsToAdd = setOf(PCConditions.BONEYARD),
            industriesToAdd = setOf(PCIndustries.BONEYARD)
        )
        adjustCorePlanetMarket(CoreWorlds.SINDRIA, conditionsToAdd = setOf(PCConditions.HIVE_CITIES))
        adjustCorePlanetMarket(
            CoreWorlds.NACHIKETA,
            conditionsToAdd = setOf(PCConditions.FORTRESS_WORLD, Conditions.HOT, Conditions.LOW_GRAVITY)
        )
        adjustCorePlanetMarket(CoreWorlds.YAMA, conditionsToAdd = setOf(Conditions.HOT))
        adjustCorePlanetMarket(CoreWorlds.SPHINX, conditionsToAdd = setOf(PCConditions.FORTRESS_WORLD))
        adjustCorePlanetMarket(CoreWorlds.YESOD, conditionsToAdd = setOf(PCConditions.FORTRESS_WORLD))
        adjustCorePlanetMarket(
            CoreWorlds.ELDFELL,
            conditionsToRemove = setOf(Conditions.NO_ATMOSPHERE),
            conditionsToAdd = setOf(Conditions.THIN_ATMOSPHERE)
        )
        adjustCoreEntityMarket(CoreWorlds.THULE_RAIDER_BASE.entity, conditionsToRemove = setOf(Conditions.COLD))
        adjustCorePlanetMarket(CoreWorlds.MADEIRA, conditionsToAdd = setOf(Conditions.COLD))
        adjustCorePlanetMarket(
            CoreWorlds.CIBOLA,
            industriesToRemove = setOf(Industries.LIGHTINDUSTRY),
            conditionsToAdd = setOf(Conditions.VERY_HOT, PCConditions.PRIMITIVES),
            industriesToAdd = setOf(Industries.FARMING)
        )
        adjustCorePlanetMarket(CoreWorlds.QARAS, conditionsToAdd = setOf(Conditions.COLD))
        adjustCorePlanetMarket(CoreWorlds.TIBICENA, conditionsToRemove = setOf(Conditions.HIGH_GRAVITY))
        adjustCorePlanetMarket(CoreWorlds.BAETIS, industriesToAdd = setOf(Industries.MINING))
        adjustCorePlanetMarket(CoreWorlds.ASHER, conditionsToAdd = setOf(Conditions.COLD))
    }

    private fun getPlanetMarket(systemId: String, planetId: String): MarketAPI? {
        val planet = Helper.sector?.getStarSystem(systemId)?.getEntityById(planetId) as? PlanetAPI ?: return null
        return Helper.createPlanetConditionMarket(planet)
    }

    private fun applyCoreWorldMicrogravity() {
        Helper.sector?.economy?.marketsCopy
            ?.filterNot { MICROGRAVITY_BLACKLIST.contains(it.planetEntity?.id) || MICROGRAVITY_BLACKLIST.contains(it.primaryEntity?.id) }
            ?.filter { it.primaryEntity?.hasTag(Tags.STATION) == true || isMicroPlanet(it) }
            ?.forEach {
                it.removeCondition(Conditions.LOW_GRAVITY)
                it.addCondition(PCConditions.MICROGRAVITY)
                if (it.surveyLevel == SurveyLevel.FULL) it.getCondition(PCConditions.MICROGRAVITY)?.isSurveyed = true
                it.reapplyConditions()
            }
    }

    private fun isMicroPlanet(market: MarketAPI): Boolean {
        return market.hasCondition(Conditions.LOW_GRAVITY)
                && (market.planetEntity?.radius ?: Float.MAX_VALUE) < GravityConditionGenerator.MICROGRAVITY_RADIUS_LIMIT
    }

    private fun setPlanetConditionMarket(world: CoreWorlds.CoreWorld, keepConditions: List<String>, conditionsToAdd: Set<String>) {
        getPlanetMarket(world.starSystem, world.entity)?.apply {
            conditions.removeIf { !keepConditions.contains(it.id) }
            conditionsToAdd.forEach {
                addCondition(it)
            }
            conditions.forEach { it.isSurveyed = true }
            reapplyConditions()
        }
    }

    private fun adjustCorePlanetMarket(
        world: CoreWorlds.CoreWorld,
        conditionsToRemove: Set<String> = emptySet(),
        industriesToRemove: Set<String> = emptySet(),
        conditionsToAdd: Set<String> = emptySet(),
        industriesToAdd: Set<String> = emptySet()
    ) {
        adjustCoreMarket(getPlanetMarket(world.starSystem, world.entity), conditionsToRemove, industriesToRemove, conditionsToAdd, industriesToAdd)
    }

    private fun adjustCoreEntityMarket(
        entity: String,
        conditionsToRemove: Set<String> = emptySet(),
        industriesToRemove: Set<String> = emptySet(),
        conditionsToAdd: Set<String> = emptySet(),
        industriesToAdd: Set<String> = emptySet()
    ) {
        val market = Helper.sector?.economy?.marketsCopy?.firstOrNull { it.primaryEntity?.id == entity }
        adjustCoreMarket(market, conditionsToRemove, industriesToRemove, conditionsToAdd, industriesToAdd)
    }

    private fun adjustCoreMarket(
        market: MarketAPI?,
        conditionsToRemove: Set<String> = emptySet(),
        industriesToRemove: Set<String> = emptySet(),
        conditionsToAdd: Set<String> = emptySet(),
        industriesToAdd: Set<String> = emptySet()
    ) {
        market?.apply {
            conditionsToRemove.forEach { removeCondition(it) }
            industriesToRemove.forEach { removeIndustry(it, MarketAPI.MarketInteractionMode.LOCAL, false) }
            conditionsToAdd.forEach {
                val token = addCondition(it)
                getSpecificCondition(token)?.isSurveyed = true
            }
            industriesToAdd.forEach { addIndustry(it) }
            reapplyConditions()
            reapplyIndustries()
        }
    }

    private fun addFuelPlantConditionToFuelProducers() {
        Helper.sector?.economy?.marketsCopy
            ?.filter { it.hasIndustry(Industries.FUELPROD) }
            ?.filterNot { it.hasCondition(PCConditions.FUEL_PLANT) }
            ?.filterNot { FUEL_PLANT_CONDITION_BLACKLIST.contains(it.primaryEntity?.id) }
            ?.forEach {
                it.addCondition(PCConditions.FUEL_PLANT)
                it.getCondition(PCConditions.FUEL_PLANT)?.isSurveyed = true
                it.reapplyConditions()
            }
    }

    private fun purgeCoreWorldRandomSpecials() {
        val emptySystems = listOfNotNull(
            Helper.sector?.getStarSystem(StarSystems.DUZAHK),
            Helper.sector?.getStarSystem(StarSystems.PENELOPE),
            Helper.sector?.getStarSystem(StarSystems.TIA)
        )
        Helper.sector?.economy?.marketsCopy
            ?.filter { it.econGroup == null }
            ?.map { it.starSystem }
            ?.plus(emptySystems)
            ?.distinct()
            ?.flatMap { it.planets }
            ?.filterNot { it.isStar || it.isSystemCenter }
            ?.mapNotNull { Helper.createPlanetConditionMarket(it) }
            ?.filter { it.isPlanetConditionMarketOnly }
            ?.forEach {
                if (it.hasCondition(PCConditions.CLOUD_SEA)) {
                    it.removeCondition(PCConditions.CLOUD_SEA)
                    it.addCondition(PCConditions.EXTREME_GRAVITY)
                    if (it.surveyLevel == SurveyLevel.FULL) it.getCondition(PCConditions.EXTREME_GRAVITY)?.isSurveyed = true
                }
                it.removeCondition(PCConditions.CRYOVAULT)
                it.removeCondition(PCConditions.BONEYARD)
                it.removeCondition(PCConditions.GRAVEYARD)
                it.removeCondition(PCConditions.HIVE_CITIES)
                it.removeCondition(PCConditions.FORTRESS_WORLD)
                it.removeCondition(PCConditions.FUEL_PLANT)
                it.removeCondition(PCConditions.PRIMITIVES)
                it.removeCondition(PCConditions.INDUSTRIALS)
                it.removeCondition(PCConditions.XENOPHOBES)
                it.removeCondition(PCConditions.ONE_WORLD_ORDER)
                Helper.removeNativePopCondition(it, Helper.getNativePopulationSize(it))
                it.reapplyConditions()
            }
    }
}