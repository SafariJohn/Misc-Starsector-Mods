package limitingConditions.helpers

import com.fs.starfarer.api.FactoryAPI
import com.fs.starfarer.api.Global
import com.fs.starfarer.api.SettingsAPI
import com.fs.starfarer.api.SoundPlayerAPI
import com.fs.starfarer.api.campaign.*
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.combat.CombatEngineAPI
import com.fs.starfarer.api.impl.campaign.ids.Factions
import com.fs.starfarer.api.impl.campaign.ids.Tags
import com.fs.starfarer.api.impl.campaign.procgen.PlanetConditionGenerator
import com.fs.starfarer.api.impl.campaign.procgen.StarAge
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator
import com.fs.starfarer.api.util.Misc
import org.apache.log4j.Logger
import org.lwjgl.util.vector.Vector2f
import limitingConditions.campaign.ids.PCConditions
import java.awt.Color
import java.util.*
import kotlin.math.roundToInt


object Helper {
    const val PAD = 10f
    const val SMALL_PAD = 10f
    const val DIALOG_COLUMNS = 7
    const val DIALOG_ICON_SIZE = 58f
    const val STRING_TOKEN = "%s"

    const val CONDITION_MARKET_PREFIX = "limitingConditions_market_"

    const val REP_LEVEL_ORDINAL_OFFSET = 5

    fun isModEnabled(id: String): Boolean {
        return settings?.modManager?.isModEnabled(id) == true
    }

    val random
        get() = Misc.random ?: Random()
    val isSectorPaused: Boolean
        get() = sector?.isPaused ?: true

    val sector: SectorAPI?
        get() = Global.getSector()

    val factory: FactoryAPI?
        get() = Global.getFactory()

    val combatEngine: CombatEngineAPI?
        get() = Global.getCombatEngine()

    val settings: SettingsAPI?
        get() = Global.getSettings()

    val soundPlayer: SoundPlayerAPI?
        get() = Global.getSoundPlayer()

    fun getLogger(c: Any? = null): Logger {
        if (c == null) return Global.getLogger(Helper::class.java)
        if (c is Class<*>) return Global.getLogger(c)
        return Global.getLogger(c::class.java)
    }

    fun anyNull(vararg objects: Any?): Boolean = objects.any { it == null }

    fun buildHighlightsLists(text: String, vararg tokens: StringToken): Pair<List<String>, List<Color>> {
        // Need to handle unplanned duplicate replaces
        for (hl in tokens) {
            hl.index = text.indexOf(hl.token)
        }

        val highlights = tokens.filter { it.index >= 0 }.sortedBy { it.index }.map { it.text }
        val colors = tokens.filter { it.index >= 0 }.sortedBy { it.index }.map { it.color }

        return Pair(highlights, colors)
    }


    fun getNativePopulationSize(market: MarketAPI): Int {
        if (market.hasCondition(PCConditions.POPULATION_0)) return 0
        if (market.hasCondition(PCConditions.POPULATION_1)) return 1
        if (market.hasCondition(PCConditions.POPULATION_2)) return 2
        if (market.hasCondition(PCConditions.POPULATION_3)) return 3
        if (market.hasCondition(PCConditions.POPULATION_4)) return 4
        if (market.hasCondition(PCConditions.POPULATION_5)) return 5
        if (market.hasCondition(PCConditions.POPULATION_6)) return 6
        if (market.hasCondition(PCConditions.POPULATION_7)) return 7
        if (market.hasCondition(PCConditions.POPULATION_8)) return 8
        if (market.hasCondition(PCConditions.POPULATION_9)) return 9
        if (market.hasCondition(PCConditions.POPULATION_10)) return 10

        return -1
    }

    fun removeNativePopCondition(market: MarketAPI, size: Int) {
        when (size) {
            0 -> market.removeCondition(PCConditions.POPULATION_0)
            1 -> market.removeCondition(PCConditions.POPULATION_1)
            2 -> market.removeCondition(PCConditions.POPULATION_2)
            3 -> market.removeCondition(PCConditions.POPULATION_3)
            4 -> market.removeCondition(PCConditions.POPULATION_4)
            5 -> market.removeCondition(PCConditions.POPULATION_5)
            6 -> market.removeCondition(PCConditions.POPULATION_6)
            7 -> market.removeCondition(PCConditions.POPULATION_7)
            8 -> market.removeCondition(PCConditions.POPULATION_8)
            9 -> market.removeCondition(PCConditions.POPULATION_9)
            10 -> market.removeCondition(PCConditions.POPULATION_10)
        }
    }

    fun createPlanetConditionMarket(planet: PlanetAPI): MarketAPI? {
        if (planet.market == null) {
            val market = factory?.createMarket(CONDITION_MARKET_PREFIX + planet.id, planet.name, 3) ?: return null
            market.isPlanetConditionMarketOnly = true
            market.primaryEntity = planet
            market.factionId = Factions.NEUTRAL
            planet.market = market
            PlanetConditionGenerator.generateConditionsForPlanet(planet, planet.starSystem?.age ?: StarAge.AVERAGE)
        }
        return planet.market
    }

//    fun multToPercentString(mult: Float): String {
//        return ExternalStrings.NUMBER_PERCENT.replaceNumberToken((mult * 100f).roundToInt())
//    }
//
//    fun floatToPercentString(float: Float): String {
//        return ExternalStrings.NUMBER_PERCENT.replaceNumberToken(float.roundToInt())
//    }

    fun percentReductionAsMult(reduction: Float): Float {
        return 1f - reduction * 0.01f
    }

    fun percentIncreaseAsMult(reduction: Float): Float {
        return 1f + reduction * 0.01f
    }

    fun setEntityLocation(entity: SectorEntityToken?, loc: Vector2f?) {
        if (anyNull(entity, loc)) return
        entity!!.setLocation(loc!!.x, loc.y)
    }

    fun getNumberAround(mean: Float, percentVariance: Float): Float {
        val variance = mean * percentVariance
        return (mean - variance) + (random.nextFloat() * variance * 2f)
    }

    fun getTokenAtRandomSpot(it: StarSystemAPI): SectorEntityToken {
        var farthest = Vector2f()
        for (entity in it.allEntities) {
            val dist = Misc.getDistance(entity, it.center)
            if (dist > farthest.length()) farthest = entity.location
        }
        return it.createToken(random.nextFloat() * farthest.x, random.nextFloat() * farthest.y)
    }

    fun isSpecialSystem(system: StarSystemAPI): Boolean {
        if (system.hyperspaceAnchor?.locationInHyperspace == null) return true
        if (system.star == null && system.center == null) return true
        if (system.type != StarSystemGenerator.StarSystemType.NEBULA && system.star == null) return true
        if (system.hasPulsar()) return true
        if (system.hasTag(Tags.THEME_HIDDEN)) return true
        if (system.jumpPoints.isEmpty()) return true
        if (system.hasTag(Tags.SYSTEM_CUT_OFF_FROM_HYPER)) return true

        return false
    }

    fun getRandomInt(min: Int, max: Int, random: Random = Helper.random): Int {
        return random.nextInt(max - min) + min
    }

    fun getRandomFloat(min: Float, max: Float, random: Random = Helper.random): Float {
        return random.nextFloat() * (max - min) + min
    }

    fun getBoolean(chance: Float, random: Random = Helper.random): Boolean {
        return random.nextFloat() < chance
    }

    fun roundToThousands(value: Double): Double {
        return ((value / 1000).roundToInt() * 1000).toDouble()
    }

    fun roundToHundreds(value: Double): Double {
        return ((value / 100).roundToInt() * 100).toDouble()
    }

    fun multHalfToFull(base: Float, random: Random = this.random): Float {
        return base * (0.5f + random.nextFloat() * 0.5f)
    }

    fun getAndJoinedCommodities(commodityIds: Collection<String>): String {
        val result = commodityIds.mapNotNull { settings?.getCommoditySpec(it)?.name }
        return Misc.getAndJoined(result).lowercase()
    }

    fun getOrbitRadius(orbit: OrbitAPI?): Float {
        if (orbit == null) return 0f
        return Misc.getDistance(orbit.focus.location, orbit.computeCurrentLocation())
    }
}
