package limitingConditions.helpers

import com.fs.starfarer.api.impl.campaign.ids.Strings

object ExternalStrings {
    const val DEBUG_NULL = "NULL"

    private const val STRINGS = "data/strings/strings.json"

    private const val ID = "limitingConditions"
    private fun get(id: String): String {
        return Helper.settings?.getString(ID, id) ?: "N/A $id"
    }

    const val TOKEN_MULT_X = "[MULT X]"
    const val TOKEN_VALUE = "[VALUE]"

    fun String.replaceValueToken(value: String) = replace(TOKEN_VALUE, value)

    val PLUS_FLAT = get("plusFlat")
    val MINUS_FLAT = get("minusFlat")
    val PERCENT = get("percent")
    val PLUS_PERCENT = get("plusPercent")
    val MINUS_PERCENT = get("minusPercent")
    val MULT_X_MULT = get("multXMult").replace(TOKEN_MULT_X, Strings.X)

    val SHIP = get("ship")
    val FLEET = get("fleet")
    val SHIP_UC = get("ship_uc")
    val FLEET_UC = get("fleet_uc")

    val CONDITION_ACCESS_BONUS = get("condition_accessBonus")
    val CONDITIONS_STABILITY_BONUS = get("condition_stabilityBonus")
    val CONDITIONS_GOWTH_BONUS_COLONY_SIZE = get("condition_growthBonusColonySize")

    val PRIMITIVES_CONDITION = get("primitives_condition")
    val PRIMITIVES_NATIVES_CONDITION = get("primitives_nativesCondition")
    val PRIMITIVES_MODIFIER_NAME = get("primitives_modifierName")

    val INDUSTRIALS_CONDITION = get("industrials_condition")
    val INDUSTRIALS_NATIVES_CONDITION = get("industrials_nativesCondition")
    val INDUSTRIALS_MODIFIER_NAME = get("industrials_modifierName")

    val XENOPHOBICS_CONDITION = get("xenophobics_condition")
    val XENOPHOBICS_NATIVES_CONDITION = get("xenophobics_nativesCondition")
    val XENOPHOBICS_MODIFIER_NAME = get("xenophobics_modifierName")

    val MICROGRAVITY_MODIFIER_NAME = get("microgravity_modifierName")
    val EXTREME_GRAVITY_MODIFIER_NAME = get("extremeGravity_modifierName")

    val STRONG_MAGNETIC_FIELD_MODIFIER_NAME = get("magneticField_modifierName")

    val HIVE_CITIES_MODIFIER_NAME = get("hiveCities_modifierName")
    val FORTRESS_WORLD_MODIFIER_NAME = get("fortressWorld_modifierName")

    val WORLD_ORDER_SURVEY_INTRO_1 = get("worldOrder_surveyBlockedIntro1")
    val WORLD_ORDER_SURVEY_INTRO_2 = get("worldOrder_surveyBlockedIntro2")
    val WORLD_ORDER_SURVEY_INTRO_3 = get("worldOrder_surveyBlockedIntro3")
    val WORLD_ORDER_SURVEY_RETURN = get("worldOrder_surveyBlockedReturn")
    val WORLD_ORDER_PRELIM_SURVEY_COMPLETE = get("worldOrder_surveyBlockedPrelimComplete")
    val WORLD_ORDER_BOMBARD_TEXT = get("worldOrder_bombardText")
    val WORLD_ORDER_BOMBARD_FUEL_REQ = get("worldOrder_bombardFuelReq")
    val WORLD_ORDER_CONFIRM_DIALOG_TEXT = get("worldOrder_confirmDialogText")
    val WORLD_ORDER_CONFIRM_DIALOG_YES = get("worldOrder_confirmDialogYes")
    val WORLD_ORDER_CONFIRM_DIALOG_NO = get("worldOrder_confirmDialogNo")
    val WORLD_ORDER_REMOVED = get("worldOrder_removed")
    val WORLD_ORDER_REMOVED_HIGHLIGHT = get("worldOrder_removedHighlight")
    val WORLD_ORDER_NATIVE_CONDITION_ADDED = get("worldOrder_nativesConditionAdded")
    val WORLD_ORDER_NATIVE_CONDITIONS_ADDED = get("worldOrder_nativesConditionsAdded")

    val INDUSTRY_ADMINISTRATOR = get("industry_administrator")
    val INDUSTRY_ALPHA_CORE_MODIFIER_NAME = get("industry_alphaCoreModifierName")
    val INDUSTRY_ALPHA_CORE_ASSIGNED = get("industry_alphaCoreAssignedPrefix")
    val INDUSTRY_ALPHA_CORE_PREVIEW = get("industry_alphaCorePreviewPrefix")
    val INDUSTRY_LOW_STABILITY_MODIFIER_DESC = get("industry_lowStabilityModifierDesc")

    val FUEL_PRODUCTION_BASE_VALUE_NO_DOMAIN_TECH = get("fuel_baseValue_noDomainTech")
    val FUEL_PRODUCTION_DOMAIN_TECH = get("fuel_domainTech")
    val FUEL_PRODUCTION_DOMAIN_TECH_MASSIVE = get("fuel_domainTech_massive")
    val FUEL_PRODUCTION_MASSIVE = get("fuel_massive")

    val CRYOVAULT_ALREADY_BUILT = get("cryovaultAlreadyBuilt")

    val CRYOREVIVAL_GROWTH_ACTIVE = get("cryorevival_popGrowthActive")
    val CRYOREVIVAL_GROWTH_PREVIEW = get("cryorevival_popGrowthPreview")
    val CRYOREVIVAL_ALPHA_EFFECTS_ACTIVE = get("cryorevival_alphaCoreEffectActive")
    val CRYOREVIVAL_ALPHA_EFFECTS_PREVIEW = get("cryorevival_alphaCoreEffectPreview")
    val CRYOREVIVAL_ALPHA_GROWTH_MODIFIER_NAME = get("cryorevival_alphaGrowthModifierName")
    val CRYOREVIVAL_IMPROVED_GROWTH_MODIFIER_NAME = get("cryorevival_improvedGrowthModifierName")
    val CRYOREVIVAL_UNMET_DEMAND_PENALTY_PREVIEW = get("cryorevival_unmetDemandPenaltyPreview")
    val CRYOREVIVAL_UNMET_DEMAND_PENALTY_ACTIVE = get("cryorevival_unmetDemandPenaltyActive")
    val CRYOREVIVAL_GROWTH_POST_DEMAND = get("cryorevival_growthPostDemand")
}