package limitingConditions.campaign.ids

object MemoryKeys {
    const val OWO_XENOPHOBES = "limitingConditions_owoXenos" // Boolean
    const val OWO_REMOVE_LIGHTS = "limitingConditions_owoRemoveLights" // Boolean
    const val NATIVE_POP_RADIO_CHATTER_ID = "limitingConditions_nativePopRadioChatterId" // String
}