package limitingConditions.campaign.ids

object StarSystems {
    const val ARCADIA = "Arcadia"
    const val ASKONIA = "Askonia"
    const val AZTLAN = "Aztlan"
    const val CANAAN = "Canaan"
    const val DUZAHK = "Duzahk"
    const val EOS_EXODUS = "Eos Exodus"
    const val HYBRASIL = "Hybrasil"
    const val KUMARI_KANDAM = "Kumari Kandam"
    const val MAGEC = "Magec"
    const val NARAKA = "Naraka"
    const val PENELOPE = "Penelope"
    const val SAMARRA = "Samarra"
    const val THULE = "Thule"
    const val TYLE = "Tyle"
    const val TIA = "Tia"
    const val WESTERNESSE = "Westernesse"
    const val VALHALLA = "Valhalla"
    const val YMA = "Yma"
    const val ZAGAN = "Zagan"
}