package limitingConditions.campaign.ids

object CoreWorlds {
    data class CoreWorld(val starSystem: String, val entity: String) {
        constructor(pair: Pair<String, String>) : this(pair.first, pair.second)
    }

    val RAGNAR = CoreWorld(StarSystems.VALHALLA to "ragnar_complex")
    val SKATHI = CoreWorld(StarSystems.VALHALLA to "skathi")
    val NIFLHEIM = CoreWorld(StarSystems.VALHALLA to "niflheim")
    val HORN = CoreWorld(StarSystems.WESTERNESSE to "horn")
    val NOMIOS = CoreWorld(StarSystems.ARCADIA to "nomios")
    val AGREUS = CoreWorld(StarSystems.ARCADIA to "agreus")
    val KUMARI_ARU = CoreWorld(StarSystems.KUMARI_KANDAM to "kumari_aru")
    val CHICO = CoreWorld(StarSystems.AZTLAN to "chicomoztoc")
    val COATL = CoreWorld(StarSystems.AZTLAN to "coatl")
    val HESPERUS = CoreWorld(StarSystems.EOS_EXODUS to "hesperus")
    val GAD = CoreWorld(StarSystems.CANAAN to "gad")
    val SINDRIA = CoreWorld(StarSystems.ASKONIA to "sindria")
    val SPHINX = CoreWorld(StarSystems.SAMARRA to "sphinx")
    val CULANN = CoreWorld(StarSystems.HYBRASIL to "culann")
    val YAMA = CoreWorld(StarSystems.NARAKA to "yama")
    val NACHIKETA = CoreWorld(StarSystems.NARAKA to "nachiketa")
    val YESOD = CoreWorld(StarSystems.ZAGAN to "yesod")
    val ELDFELL = CoreWorld(StarSystems.THULE to "eldfell")
    val CIBOLA = CoreWorld(StarSystems.TYLE to "cibola")
    val MADEIRA = CoreWorld(StarSystems.TYLE to "madeira")
    val EOCHU_BRES = CoreWorld(StarSystems.HYBRASIL to "eochu_bres")
    val QARAS = CoreWorld(StarSystems.YMA to "qaras")
    val TIBICENA = CoreWorld(StarSystems.MAGEC to "tibicena")
    val BAETIS = CoreWorld(StarSystems.EOS_EXODUS to "baetis")
    val ASHER = CoreWorld(StarSystems.CANAAN to "asher")
    val THULE_RAIDER_BASE = CoreWorld(StarSystems.THULE, "thule_pirate_station")
}