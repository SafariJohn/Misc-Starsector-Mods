package limitingConditions.campaign.ids

object PCIndustries {
    const val CRYOVAULT_REVIVAL = "limitingConditions_cryorevival"
    const val CRYOVAULT_SANCTUM = "limitingConditions_cryosanctum"
    const val BONEYARD = "limitingConditions_boneyard"
    const val SHIPBREAKERS = "limitingConditions_shipbreakers"
}