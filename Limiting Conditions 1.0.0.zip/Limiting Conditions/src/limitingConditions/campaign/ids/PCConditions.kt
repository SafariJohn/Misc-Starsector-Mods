package limitingConditions.campaign.ids

object PCConditions {
    const val CLOUD_SEA = "limitingConditions_cloudSea"
    const val MAGNETIC_FIELD = "limitingConditions_magneticField"

    const val MICROGRAVITY = "limitingConditions_micrograv"
    const val EXTREME_GRAVITY = "limitingConditions_extremeGrav"
    
    const val GRAVEYARD = "limitingConditions_graveyard"
    const val BONEYARD = "limitingConditions_boneyard"

    const val CRYOVAULT = "limitingConditions_cryosanctum"
    const val HIVE_CITIES = "limitingConditions_hiveCities"
    const val FORTRESS_WORLD = "limitingConditions_fortressWorld"
    const val FUEL_PLANT = "limitingConditions_fuelFactory"

    const val PRIMITIVES = "limitingConditions_primitives"
    const val INDUSTRIALS = "limitingConditions_industrials"
    const val XENOPHOBES = "limitingConditions_xenophobes"
    const val ONE_WORLD_ORDER = "limitingConditions_worldOrder"

    const val POPULATION_0: String = "limitingConditions_population_0"
    const val POPULATION_1: String = "limitingConditions_population_1"
    const val POPULATION_2: String = "limitingConditions_population_2"
    const val POPULATION_3: String = "limitingConditions_population_3"
    const val POPULATION_4: String = "limitingConditions_population_4"
    const val POPULATION_5: String = "limitingConditions_population_5"
    const val POPULATION_6: String = "limitingConditions_population_6"
    const val POPULATION_7: String = "limitingConditions_population_7"
    const val POPULATION_8: String = "limitingConditions_population_8"
    const val POPULATION_9: String = "limitingConditions_population_9"
    const val POPULATION_10: String = "limitingConditions_population_10"
}