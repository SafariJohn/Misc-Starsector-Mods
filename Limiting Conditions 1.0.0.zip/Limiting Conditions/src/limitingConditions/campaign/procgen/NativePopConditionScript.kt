package limitingConditions.campaign.procgen

import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.campaign.econ.MarketAPI.SurveyLevel
import com.fs.starfarer.api.impl.campaign.ids.Conditions
import com.fs.starfarer.api.impl.campaign.ids.Tags
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator
import com.fs.starfarer.api.util.WeightedRandomPicker
import limitingConditions.campaign.econ.BaseNativesHazardCondition
import limitingConditions.campaign.ids.MemoryKeys
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.helpers.Helper
import limitingConditions.helpers.Memory

object NativePopConditionScript {
    const val PRIMITIVES_MIN_POP_SIZE = 3
    const val PRIMITIVES_MAX_HAZARD = 1.6

    const val INDUSTRIALS_MIN_POP_SIZE = 3
    const val INDUSTRIALS_MAX_HAZARD = 2.1

    const val PRIMITIVES_WEIGHT = 10f
    const val INDUSTRIALS_WEIGHT = 5f
    const val WORLD_ORDER_WEIGHT = 2f
    const val XENOPHOBES_WEIGHT = 1f

    const val CHANCE_DECIV_OWO = 0.1f

    val GLOW_AND_RADIO_POP = listOf(
        PCConditions.INDUSTRIALS,
        PCConditions.XENOPHOBES,
        PCConditions.ONE_WORLD_ORDER
    )

    fun run() {
        Helper.sector?.starSystems?.asSequence()
            ?.flatMap { it.planets }
            ?.filterNot { it.isStar || it.isSystemCenter }
            ?.filterNot { it.market?.isPlanetConditionMarketOnly == false }
            ?.mapNotNull { Helper.createPlanetConditionMarket(it) }
            // Get native pop size and then clean up the condition during the sequence.
            ?.map {
                Pair(it, Helper.getNativePopulationSize(it))
            }
            ?.map {
                cleanUpNativePopSizeCondition(it.first, it.second)
                it
            }
            ?.filter { it.second > 0 }
            ?.filterNot { isUninhabitable(it.first) }
            ?.filterNot { alreadyHasNativePop(it.first) }
            ?.forEach {
                val market = it.first
                val nativePopSize = it.second
                val habitable = market.hasCondition(Conditions.HABITABLE)
                val hazard = market.hazardValue

                val picker = WeightedRandomPicker<String>()
                if (habitable && nativePopSize > PRIMITIVES_MIN_POP_SIZE && hazard < PRIMITIVES_MAX_HAZARD) picker.add(PCConditions.PRIMITIVES, PRIMITIVES_WEIGHT)
                if (nativePopSize > INDUSTRIALS_MIN_POP_SIZE && hazard < INDUSTRIALS_MAX_HAZARD) picker.add(PCConditions.INDUSTRIALS, INDUSTRIALS_WEIGHT)
                picker.add(PCConditions.ONE_WORLD_ORDER, WORLD_ORDER_WEIGHT)
                picker.add(PCConditions.XENOPHOBES, XENOPHOBES_WEIGHT)

                val condId = picker.pick()
                if (condId == PCConditions.ONE_WORLD_ORDER && Helper.random.nextFloat() > CHANCE_DECIV_OWO) {
                    Memory.set(MemoryKeys.OWO_XENOPHOBES, true, market)
                }
                val token: String = market.addCondition(condId)
                if (market.surveyLevel == SurveyLevel.FULL) market.getSpecificCondition(token)?.isSurveyed = true

                setOrbitalJunk(condId, nativePopSize, market)
                addRadioChatter(condId, nativePopSize, market)
                setPlanetGlow(condId, market)

                market.reapplyConditions()
            }
    }

    private fun addRadioChatter(condId: String, nativePopSize: Int, market: MarketAPI) {
        if (!isGlowAndRadioNativePop(condId)) return
        val radius = 300f + nativePopSize * 200f
        val radioChatter = market.primaryEntity?.containingLocation?.addRadioChatter(market.primaryEntity, radius)
        if (radioChatter != null) {
            Memory.set(MemoryKeys.NATIVE_POP_RADIO_CHATTER_ID, radioChatter.id, market)
        }
    }

    private fun setPlanetGlow(condId: String, market: MarketAPI) {
        if (!isGlowAndRadioNativePop(condId)) return
        if (market.planetEntity?.spec?.glowTexture != null) return
        val glowPicker = WeightedRandomPicker<String>(StarSystemGenerator.random)
        glowPicker.add("barren", 1f)
        glowPicker.add("volturn", 10f)
        glowPicker.add("asharu", 10f)
        glowPicker.add("sindria", 10f)
        val glow = glowPicker.pick()
        val glowSprite = Helper.settings?.getSpriteName("hab_glows", glow) ?: return
        market.planetEntity?.spec?.glowTexture = glowSprite
        market.planetEntity?.applySpecChanges()
        if (market.hasCondition(PCConditions.ONE_WORLD_ORDER) && !Memory.isFlag(MemoryKeys.OWO_XENOPHOBES, market)) {
            Memory.set(MemoryKeys.OWO_REMOVE_LIGHTS, true, market)
        }
    }

    private fun isGlowAndRadioNativePop(condId: String): Boolean {
        return GLOW_AND_RADIO_POP.contains(condId)
    }

    private fun cleanUpNativePopSizeCondition(market: MarketAPI, popSize: Int) {
        Helper.removeNativePopCondition(market, popSize)
        market.reapplyConditions()
    }

    private fun isUninhabitable(market: MarketAPI): Boolean {
        return market.hasCondition(PCConditions.EXTREME_GRAVITY)
    }

    private fun alreadyHasNativePop(market: MarketAPI): Boolean {
        return market.conditions.any { c ->
            c.plugin is BaseNativesHazardCondition
                    || c.id == Conditions.DECIVILIZED
                    || c.id == Conditions.DECIVILIZED_SUBPOP
                    || c.id == PCConditions.ONE_WORLD_ORDER
        }
    }


    private fun getRuins(market: MarketAPI): Int {
        var maxRuins = 0
        if (market.hasCondition(Conditions.RUINS_SCATTERED)) maxRuins = 1
        if (market.hasCondition(Conditions.RUINS_WIDESPREAD)) maxRuins = 2
        if (market.hasCondition(Conditions.RUINS_EXTENSIVE)) maxRuins = 3
        if (market.hasCondition(Conditions.RUINS_VAST)) maxRuins = 4

        return maxRuins
    }

    private fun setOrbitalJunk(condId: String, nativePopSize: Int, market: MarketAPI) {
        if (condId != PCConditions.PRIMITIVES && nativePopSize / 3 > getRuins(market)) {
            for (junk in market.containingLocation.getEntitiesWithTag(Tags.ORBITAL_JUNK)) {
                if (junk.orbitFocus == market.primaryEntity) {
                    market.containingLocation.removeEntity(junk)
                }
            }

            addJunk(market, nativePopSize / 3)
        }
    }


    private fun addJunk(market: MarketAPI, ruinSize: Int) {
        val numJunk = when (ruinSize) {
            4 -> 45
            3 -> 20
            2 -> 10
            else -> 5
        }

        val radius = market.primaryEntity.radius + 100f
        val minOrbitDays = radius / 20
        val maxOrbitDays = minOrbitDays + 10f

        market.containingLocation.addOrbitalJunk(
            market.primaryEntity,
            "orbital_junk",  // from custom_entities.json
            numJunk,  // num of junk
            12f, 20f,  // min/max sprite size (assumes square)
            radius,  // orbit radius
            //70, // orbit width
            110f,  // orbit width
            minOrbitDays,  // min orbit days
            maxOrbitDays,  // max orbit days
            60f,  // min spin (degress/day)
            360f
        ) // max spin (degrees/day)
    }
}