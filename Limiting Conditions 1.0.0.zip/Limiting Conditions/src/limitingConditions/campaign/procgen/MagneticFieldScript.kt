package limitingConditions.campaign.procgen

import com.fs.starfarer.api.campaign.CampaignTerrainAPI
import com.fs.starfarer.api.campaign.PlanetAPI
import com.fs.starfarer.api.impl.campaign.ids.Conditions
import com.fs.starfarer.api.impl.campaign.ids.Planets
import com.fs.starfarer.api.impl.campaign.terrain.MagneticFieldTerrainPlugin
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.helpers.Helper

/**
 * Author: SafariJohn
 */
object MagneticFieldScript {
    fun run() {
        Helper.sector?.starSystems?.flatMap { it.allEntities }
            ?.filter { it is CampaignTerrainAPI && it.plugin is MagneticFieldTerrainPlugin }
            ?.filter { it.orbitFocus is PlanetAPI }
            ?.filterNot { it.orbitFocus.isStar || it.orbitFocus.isSystemCenter }
            ?.forEach {
                val focus = it.orbitFocus as PlanetAPI
                val market = Helper.createPlanetConditionMarket(focus)
                if (market != null) {
                    if (focus.typeId != Planets.IRRADIATED && market.hasCondition(Conditions.IRRADIATED)) {
                        market.removeCondition(Conditions.IRRADIATED)
                    }

                    val mc = market.getSpecificCondition(market.addCondition(PCConditions.MAGNETIC_FIELD))
                    mc.isSurveyed = true

                    market.reapplyConditions()
                }
            }
    }
}
