package limitingConditions.campaign.procgen

import com.fs.starfarer.api.campaign.PlanetAPI
import com.fs.starfarer.api.impl.campaign.ids.Conditions
import com.fs.starfarer.api.impl.campaign.procgen.PlanetConditionGenerator
import com.fs.starfarer.api.impl.campaign.procgen.PlanetConditionGenerator.ConditionGenerator
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator
import limitingConditions.campaign.ids.PCConditions

class GravityConditionGenerator : ConditionGenerator {
    companion object {
        const val MICROGRAVITY_RADIUS_LIMIT = 40f
        const val MICROGRAVITY_RADIUS_MAX = StarSystemGenerator.MIN_MOON_RADIUS
        const val LOW_GRAVITY_RADIUS_MAX = 100
        const val HIGH_GRAVITY_RADIUS_MIN = 140
        const val EXTREME_GRAVITY_RADIUS_MIN = 200f
        const val EXTREME_GRAVITY_RADIUS_LIMIT = 220f
        const val HABITABLE_RADIUS_MULT = 0.8f
    }

    override fun addConditions(
        conditionsSoFar: MutableSet<String>,
        context: StarSystemGenerator.GenContext,
        planet: PlanetAPI
    ) {
        if (conditionsSoFar.contains(Conditions.LOW_GRAVITY)) return
        if (conditionsSoFar.contains(Conditions.HIGH_GRAVITY)) return

        var radius = planet.radius

        val min = MICROGRAVITY_RADIUS_LIMIT
        val max = EXTREME_GRAVITY_RADIUS_LIMIT

        if (conditionsSoFar.contains(Conditions.HABITABLE) && radius > LOW_GRAVITY_RADIUS_MAX) {
            radius = (radius * HABITABLE_RADIUS_MULT).coerceAtLeast(LOW_GRAVITY_RADIUS_MAX.toFloat())
        }

        if (radius < min) radius = min
        if (radius > max) radius = max

        if (planet.radius < min && PlanetConditionGenerator.preconditionsMet(PCConditions.MICROGRAVITY, conditionsSoFar)) {
            conditionsSoFar.add(PCConditions.MICROGRAVITY)
            return
        }

        if (radius < MICROGRAVITY_RADIUS_MAX && PlanetConditionGenerator.preconditionsMet(PCConditions.MICROGRAVITY, conditionsSoFar)) {
            val range = MICROGRAVITY_RADIUS_MAX - min
            val chance = 0.2f + 0.8f * ((MICROGRAVITY_RADIUS_MAX - radius) / range)
            if (StarSystemGenerator.random.nextFloat() < chance) {
                conditionsSoFar.add(PCConditions.MICROGRAVITY)
            } else if (PlanetConditionGenerator.preconditionsMet(Conditions.LOW_GRAVITY, conditionsSoFar)) {
                conditionsSoFar.add(Conditions.LOW_GRAVITY)
            }
            return
        }

        if (radius < LOW_GRAVITY_RADIUS_MAX && PlanetConditionGenerator.preconditionsMet(Conditions.LOW_GRAVITY, conditionsSoFar)) {
            val range = LOW_GRAVITY_RADIUS_MAX - MICROGRAVITY_RADIUS_MAX
            val chance = 0.2f + 0.8f * ((LOW_GRAVITY_RADIUS_MAX - radius) / range)
            if (StarSystemGenerator.random.nextFloat() < chance) {
                conditionsSoFar.add(Conditions.LOW_GRAVITY)
            }
            return
        }

        if (planet.radius > max && PlanetConditionGenerator.preconditionsMet(PCConditions.EXTREME_GRAVITY, conditionsSoFar)) {
            conditionsSoFar.add(PCConditions.EXTREME_GRAVITY)
            return
        }

        if (radius > EXTREME_GRAVITY_RADIUS_MIN && PlanetConditionGenerator.preconditionsMet(PCConditions.EXTREME_GRAVITY, conditionsSoFar)) {
            val range = max - EXTREME_GRAVITY_RADIUS_MIN
            val chance = 0.1f + 0.9f * (1f - ((max - radius) / range))
            if (StarSystemGenerator.random.nextFloat() < chance) {
                conditionsSoFar.add(Conditions.HIGH_GRAVITY)
            } else if (PlanetConditionGenerator.preconditionsMet(Conditions.HIGH_GRAVITY, conditionsSoFar)) {
                conditionsSoFar.add(Conditions.HIGH_GRAVITY)
            }
            return
        }

        if (radius > HIGH_GRAVITY_RADIUS_MIN && PlanetConditionGenerator.preconditionsMet(Conditions.HIGH_GRAVITY, conditionsSoFar)) {
            val range = EXTREME_GRAVITY_RADIUS_MIN - HIGH_GRAVITY_RADIUS_MIN
            val chance = 0.1f + 0.9f * (1f - ((EXTREME_GRAVITY_RADIUS_MIN - radius) / range))
            if (StarSystemGenerator.random.nextFloat() < chance) {
                conditionsSoFar.add(Conditions.HIGH_GRAVITY)
            }
            return
        }
    }
}