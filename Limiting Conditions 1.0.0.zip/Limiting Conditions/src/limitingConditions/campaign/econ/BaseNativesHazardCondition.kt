package limitingConditions.campaign.econ

import com.fs.starfarer.api.Global
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier
import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition
import com.fs.starfarer.api.impl.campaign.ids.Factions
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition
import com.fs.starfarer.api.ui.TooltipMakerAPI
import com.fs.starfarer.api.util.Misc
import limitingConditions.helpers.ExternalStrings
import limitingConditions.helpers.ExternalStrings.replaceValueToken
import limitingConditions.helpers.Helper

abstract class BaseNativesHazardCondition : BaseHazardCondition(), MarketImmigrationModifier {
    companion object {
        const val STABILITY_PENALTY = 1f
        const val STABILITY_PENALTY_STRING = "1"
        const val TOKEN_STRINGS_JSON = "[SEE STRINGS.JSON]"
        const val TOKEN_MARKET_CAPITALIZED = "[CAPITALIZED MARKET NAME]"
        const val TOKEN_MARKET = "[MARKET NAME]"
        const val S_TOKEN_MARKET = "\$market"
        const val S_TOKEN_MARKET_CAPITALIZED = "\$Market"
    }

    open fun getStabilityPenalty(): Float = STABILITY_PENALTY
    open fun getStabilityPenaltyString(): String = STABILITY_PENALTY_STRING

    abstract fun getNeutralDescription(): String
    abstract fun getOwnedDescription(): String

    protected abstract fun getModifierDesc(): String

    override fun apply(id: String) {
        super.apply(id)

        market.stability.modifyFlat(id, -getStabilityPenalty(), getModifierDesc())

        market.addTransientImmigrationModifier(this)
    }

    override fun unapply(id: String) {
        super.unapply(id)
        market.stability.unmodify(id)

        market.removeTransientImmigrationModifier(this)
    }

    override fun modifyIncoming(market: MarketAPI, incoming: PopulationComposition) {
        incoming.add(Factions.POOR, 10f)
        incoming.weight.modifyFlat(modId, getImmigrationBonus(), getModifierDesc())
    }

    protected open fun getImmigrationBonus(): Float = market.size.toFloat()
    protected open fun getImmigrationBonusDesc(): String = getImmigrationBonus().toInt().toString()


    override fun createTooltip(tooltip: TooltipMakerAPI?, expanded: Boolean) {
        if (tooltip == null) return
        if (!Global.CODEX_TOOLTIP_MODE) {
            val color = market.textColorForFactionOrPlanet
            tooltip.addTitle(condition.name, color)
        }

        var text = if (market.isPlanetConditionMarketOnly) {
            condition.spec.desc.replace(TOKEN_STRINGS_JSON, getNeutralDescription())
                .replace(TOKEN_MARKET, S_TOKEN_MARKET)
                .replace(TOKEN_MARKET_CAPITALIZED, S_TOKEN_MARKET_CAPITALIZED)
        } else {
            condition.spec.desc.replace(TOKEN_STRINGS_JSON, getOwnedDescription())
                .replace(TOKEN_MARKET, S_TOKEN_MARKET)
                .replace(TOKEN_MARKET_CAPITALIZED, S_TOKEN_MARKET_CAPITALIZED)
        }
        val tokens = tokenReplacements
        for (token in tokens.keys) {
            val value = tokens[token]
            text = text.replace(("(?s)\\$token").toRegex(), value!!)
        }

        if (text.isNotEmpty()) {
            val body = tooltip.addPara(text, Helper.PAD)
            if (highlights != null) {
                if (highlightColors != null) {
                    body.setHighlightColors(*highlightColors)
                } else {
                    body.setHighlightColor(Misc.getHighlightColor())
                }
                body.setHighlight(*highlights)
            }
        }

        createTooltipAfterDescription(tooltip, expanded)
    }

    override fun createTooltipAfterDescription(tooltip: TooltipMakerAPI, expanded: Boolean) {
        super.createTooltipAfterDescription(tooltip, expanded)

        tooltip.addPara(
            ExternalStrings.CONDITIONS_STABILITY_BONUS.replaceValueToken(Helper.STRING_TOKEN),
            10f, Misc.getHighlightColor(),
            ExternalStrings.MINUS_FLAT.replaceValueToken(getStabilityPenaltyString())
        )
        tooltip.addPara(
            ExternalStrings.CONDITIONS_GOWTH_BONUS_COLONY_SIZE.replaceValueToken(Helper.STRING_TOKEN),
            10f, Misc.getHighlightColor(),
            ExternalStrings.PLUS_FLAT.replaceValueToken(getImmigrationBonusDesc())
        )
    }
}