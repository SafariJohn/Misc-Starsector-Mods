package limitingConditions.campaign.econ

import limitingConditions.helpers.ExternalStrings

class XenophobicNatives : BaseNativesHazardCondition() {
    companion object {
        const val STABILITY_PENALTY = 2f
        const val STABILITY_PENALTY_STRING = "2"
    }

    override fun getStabilityPenalty(): Float = STABILITY_PENALTY
    override fun getStabilityPenaltyString(): String = STABILITY_PENALTY_STRING

    override fun getNeutralDescription(): String = ExternalStrings.XENOPHOBICS_CONDITION
    override fun getOwnedDescription(): String = ExternalStrings.XENOPHOBICS_NATIVES_CONDITION

    override fun getModifierDesc(): String = ExternalStrings.XENOPHOBICS_MODIFIER_NAME
}


