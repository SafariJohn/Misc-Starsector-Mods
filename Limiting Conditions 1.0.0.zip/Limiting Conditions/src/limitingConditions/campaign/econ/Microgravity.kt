package limitingConditions.campaign.econ

import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition
import com.fs.starfarer.api.ui.TooltipMakerAPI
import com.fs.starfarer.api.util.Misc
import limitingConditions.helpers.ExternalStrings
import limitingConditions.helpers.ExternalStrings.replaceValueToken
import limitingConditions.helpers.Helper

/**
 * Author: SafariJohn
 */
class Microgravity : BaseHazardCondition() {
    companion object {
        const val ACCESS_BONUS = 0.2f
        const val ACCESS_BONUS_STRING = "20"
    }

    override fun apply(id: String) {
        super.apply(id)
        market.accessibilityMod.modifyFlat(id, ACCESS_BONUS, ExternalStrings.MICROGRAVITY_MODIFIER_NAME)
    }

    override fun unapply(id: String) {
        super.unapply(id)
        market.accessibilityMod.unmodifyFlat(id)
    }

    override fun createTooltipAfterDescription(tooltip: TooltipMakerAPI, expanded: Boolean) {
        super.createTooltipAfterDescription(tooltip, expanded)
        tooltip.addPara(
            ExternalStrings.CONDITION_ACCESS_BONUS.replaceValueToken(Helper.STRING_TOKEN),
            Helper.PAD, Misc.getHighlightColor(),
            ExternalStrings.PLUS_PERCENT.replaceValueToken(ACCESS_BONUS_STRING)
        )
    }
}
