package limitingConditions.campaign.econ

import com.fs.starfarer.api.impl.campaign.econ.BaseHazardCondition
import com.fs.starfarer.api.impl.campaign.ids.Stats
import com.fs.starfarer.api.impl.campaign.ids.Strings
import com.fs.starfarer.api.util.Misc
import limitingConditions.helpers.ExternalStrings
import limitingConditions.helpers.ExternalStrings.replaceValueToken
import java.awt.Color

/**
 * Author: SafariJohn
 */
class FortressWorld : BaseHazardCondition() {
    companion object {
        const val TOKEN_DEFENSE = "[DEFENSE]"
        const val DEFENSE_MOD = 3f
        const val DEFENSE_MOD_STRING = "3"
    }

    override fun apply(id: String) {
        super.apply(id)
        market.stats?.dynamic?.getMod(Stats.GROUND_DEFENSES_MOD)
            ?.modifyMult(modId, DEFENSE_MOD, ExternalStrings.FORTRESS_WORLD_MODIFIER_NAME)
    }

    override fun unapply(id: String) {
        super.unapply(id)
        market.stats?.dynamic?.getMod(Stats.GROUND_DEFENSES_MOD)?.unmodifyMult(modId)
    }

    override fun getTokenReplacements(): Map<String, String> = super.getTokenReplacements() +
            Pair(TOKEN_DEFENSE, ExternalStrings.MULT_X_MULT.replaceValueToken(DEFENSE_MOD_STRING))

    override fun getHighlightColors(): Array<Color> = arrayOf(Misc.getHighlightColor())

    override fun getHighlights(): Array<String> = arrayOf(
        ExternalStrings.MULT_X_MULT.replaceValueToken(DEFENSE_MOD_STRING)
    )
}
