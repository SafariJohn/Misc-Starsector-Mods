package limitingConditions.campaign.econ

import limitingConditions.helpers.ExternalStrings

class IndustrialNatives : BaseNativesHazardCondition() {
    companion object {
        const val IMMIGRATION_MULT = 2f
    }

    override fun getNeutralDescription(): String = ExternalStrings.INDUSTRIALS_CONDITION
    override fun getOwnedDescription(): String = ExternalStrings.INDUSTRIALS_NATIVES_CONDITION

    override fun getModifierDesc(): String = ExternalStrings.INDUSTRIALS_MODIFIER_NAME

    override fun getImmigrationBonus(): Float {
        return super.getImmigrationBonus() * IMMIGRATION_MULT
    }
}


