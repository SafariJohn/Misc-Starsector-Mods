package limitingConditions.campaign.econ

import limitingConditions.helpers.ExternalStrings

class PrimitiveNatives : BaseNativesHazardCondition() {
    override fun getNeutralDescription(): String = ExternalStrings.PRIMITIVES_CONDITION
    override fun getOwnedDescription(): String = ExternalStrings.PRIMITIVES_NATIVES_CONDITION

    override fun getModifierDesc(): String {
        return ExternalStrings.PRIMITIVES_MODIFIER_NAME
    }
}


