package limitingConditions.campaign.cleanup

import limitingConditions.campaign.ids.MemoryKeys
import limitingConditions.helpers.Helper
import limitingConditions.helpers.Memory

object RadioChatterCleanup {
    fun run() {
        Helper.sector?.economy?.marketsCopy
            ?.filter { Memory.contains(MemoryKeys.NATIVE_POP_RADIO_CHATTER_ID, it) }
            ?.forEach {
                val id = Memory.get(MemoryKeys.NATIVE_POP_RADIO_CHATTER_ID, it, { v -> v is String }, { "" }) as String
                Memory.unset(MemoryKeys.NATIVE_POP_RADIO_CHATTER_ID, it)
                it.primaryEntity?.containingLocation?.removeEntity(it.primaryEntity?.containingLocation?.getEntityById(id))
                it.planetEntity?.containingLocation?.removeEntity(it.planetEntity?.containingLocation?.getEntityById(id))
            }
    }
}