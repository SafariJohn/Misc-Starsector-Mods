package limitingConditions.campaign.ruleCommands

import com.fs.starfarer.api.campaign.InteractionDialogAPI
import com.fs.starfarer.api.campaign.TextPanelAPI
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.campaign.rules.MemoryAPI
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin
import com.fs.starfarer.api.util.Misc
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.helpers.ExternalStrings
import limitingConditions.helpers.Helper

class LimitingConditions_DisplayWorldOrderBlock : BaseCommandPlugin() {
    companion object {
        val ICON = Helper.settings?.getSpriteName("conditions", "limitingConditions_worldOrder")
        const val ICON_SIZE = 40f
        const val S_TOKEN_MARKET = "\$market"
        const val TOKEN_SHIP_OR_FLEET = "[SHIP OR FLEET]"
        const val TOKEN_SHIP_OR_FLEET_UC = "[SHIP OR FLEET UC FIRST]"

        const val PARAM_INTRO = "intro"
    }

    override fun execute(
        ruleId: String?,
        dialog: InteractionDialogAPI?,
        params: MutableList<Misc.Token>?,
        memoryMap: MutableMap<String, MemoryAPI>?
    ): Boolean {
        if (dialog?.textPanel == null) return false
        val isIntro = (params?.firstOrNull()?.string ?: return false) == PARAM_INTRO
        val market = dialog.interactionTarget?.market ?: return false
        val marketName = market.name ?: ExternalStrings.DEBUG_NULL
        if (isIntro) {
            val doSurvey = market.surveyLevel.ordinal < MarketAPI.SurveyLevel.PRELIMINARY.ordinal
            displayIntro(dialog.textPanel, marketName, doSurvey)
            if (doSurvey) market.surveyLevel = MarketAPI.SurveyLevel.PRELIMINARY
        } else {
            displayReturn(dialog.textPanel, marketName)
        }
        return true
    }

    private fun displayIntro(textPanel: TextPanelAPI, marketName: String, doSurvey: Boolean) {
        if (ExternalStrings.WORLD_ORDER_SURVEY_INTRO_1.isNotEmpty()) {
            textPanel.addPara(ExternalStrings.WORLD_ORDER_SURVEY_INTRO_1.replaceShipOrFleet())
        }
        if (ExternalStrings.WORLD_ORDER_SURVEY_INTRO_2.isNotEmpty()) {
            textPanel.addPara(ExternalStrings.WORLD_ORDER_SURVEY_INTRO_2.replaceShipOrFleet())
        }
        if (ExternalStrings.WORLD_ORDER_SURVEY_INTRO_3.isNotEmpty()) {
            textPanel.addPara(ExternalStrings.WORLD_ORDER_SURVEY_INTRO_3.replaceShipOrFleet())
        }
        showOWOIconAndDesc(textPanel, marketName)
        if (doSurvey) textPanel.addPara(ExternalStrings.WORLD_ORDER_PRELIM_SURVEY_COMPLETE)
    }

    private fun displayReturn(textPanel: TextPanelAPI, marketName: String) {
        textPanel.addPara(ExternalStrings.WORLD_ORDER_SURVEY_RETURN.replaceShipOrFleet())
        showOWOIconAndDesc(textPanel, marketName)
    }

    private fun showOWOIconAndDesc(textPanel: TextPanelAPI, marketName: String) {
        val spec = Helper.settings?.getMarketConditionSpec(PCConditions.ONE_WORLD_ORDER)
        val name = spec?.name ?: ExternalStrings.DEBUG_NULL
        val text = spec?.desc ?: ExternalStrings.DEBUG_NULL
        val icon = spec?.icon ?: return

        val tooltip = textPanel.beginTooltip()
        val image = tooltip.beginImageWithText(icon, ICON_SIZE)
        image.setTitleOrbitronLarge()
        image.addTitle(name, Misc.getNegativeHighlightColor())
        image.addPara(text.replace(S_TOKEN_MARKET, marketName), 0f)
        tooltip.addImageWithText(0f)
        textPanel.addTooltip()
    }

    private fun String.replaceShipOrFleet(): String {
        val isSingleShip = Helper.sector?.playerFleet?.fleetSizeCount == 1
        val shipOrFleet = if (isSingleShip) ExternalStrings.SHIP else ExternalStrings.FLEET
        val shipOrFleetUC = if (isSingleShip) ExternalStrings.SHIP_UC else ExternalStrings.FLEET_UC
        return replace(TOKEN_SHIP_OR_FLEET, shipOrFleet).replace(TOKEN_SHIP_OR_FLEET_UC, shipOrFleetUC)
    }
}