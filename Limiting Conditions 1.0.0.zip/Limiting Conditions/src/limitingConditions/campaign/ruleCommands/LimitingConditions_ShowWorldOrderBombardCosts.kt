package limitingConditions.campaign.ruleCommands

import com.fs.starfarer.api.campaign.InteractionDialogAPI
import com.fs.starfarer.api.campaign.TextPanelAPI
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.campaign.rules.MemoryAPI
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin
import com.fs.starfarer.api.util.Misc
import limitingConditions.helpers.ExternalStrings
import limitingConditions.helpers.Helper

class LimitingConditions_ShowWorldOrderBombardCosts : BaseCommandPlugin() {
    companion object {
        const val TOKEN_BOMBARD_FUEL_REQ = "[REQUIRED FUEL]"
        const val TOKEN_BOMBARD_FUEL_AVAIL = "[AVAILABLE FUEL]"
        const val STRING_TOKEN = "%s"
    }

    override fun execute(
        ruleId: String?,
        dialog: InteractionDialogAPI?,
        params: MutableList<Misc.Token>?,
        memoryMap: MutableMap<String, MemoryAPI>?
    ): Boolean {
        if (dialog?.textPanel == null) return false
        val market = dialog.interactionTarget?.market ?: return false
        dialog.visualPanel?.showImagePortion(
            "illustrations",
            "bombard_prepare",
            640f,
            400f,
            0f,
            0f,
            480f,
            300f
        )
        showFuelCosts(dialog.textPanel, market)
        return true
    }

    /**
     * Consider destroying the defense network
     *
     *
     *
     *
     * Starship fuel can be easily destabilized, unlocking the destructive potential of the antimatter it contains. The defense network is designed to defend against such a bombardment, though in practice it only means that more fuel is required to achieve the same result.
     *
     * Starship fuel yada-yada
     *
     * Bombardment requires X fuel
     *
     * Go Back
     *
     * It seems X will remain on high alert until you leave.
     *
     * ICON with name and desc
     *
     *
     *
     */

    private fun showFuelCosts(textPanel: TextPanelAPI, market: MarketAPI) {
        val hasEnoughFuel = LimitingConditions_WorldOrderHasEnoughFuel.hasEnoughFuel(market)
        val requiredFuel = LimitingConditions_WorldOrderHasEnoughFuel.getFuelRequired(market).toInt().toString()
        val playerFuel = (Helper.sector?.playerFleet?.cargo?.fuel ?: 0f).toInt().toString()
        textPanel.addPara(ExternalStrings.WORLD_ORDER_BOMBARD_TEXT)

        val text = ExternalStrings.WORLD_ORDER_BOMBARD_FUEL_REQ
        val reqIndex = text.indexOf(TOKEN_BOMBARD_FUEL_REQ, 0, false)
        val availIndex = text.indexOf(TOKEN_BOMBARD_FUEL_AVAIL, 0, false)
        val isReqTokenBeforeAvailToken = reqIndex < availIndex
        if (isReqTokenBeforeAvailToken) {
            val label = textPanel.addPara(
                text.replace(TOKEN_BOMBARD_FUEL_REQ, STRING_TOKEN).replace(TOKEN_BOMBARD_FUEL_AVAIL, STRING_TOKEN),
                Misc.getHighlightColor(),
                requiredFuel,
                playerFuel
            )
            label?.setHighlight(requiredFuel, playerFuel)
            val requiredHL = if (hasEnoughFuel) Misc.getHighlightColor() else Misc.getNegativeHighlightColor()
            label?.setHighlightColors(requiredHL, Misc.getHighlightColor())
        } else {
            val label = textPanel.addPara(
                text.replace(TOKEN_BOMBARD_FUEL_REQ, STRING_TOKEN).replace(TOKEN_BOMBARD_FUEL_AVAIL, STRING_TOKEN),
                Misc.getHighlightColor(),
                playerFuel,
                requiredFuel
            )
            label?.setHighlight(requiredFuel, playerFuel)
            val requiredHL = if (hasEnoughFuel) Misc.getHighlightColor() else Misc.getNegativeHighlightColor()
            label?.setHighlightColors(Misc.getHighlightColor(), requiredHL)
        }
    }
}