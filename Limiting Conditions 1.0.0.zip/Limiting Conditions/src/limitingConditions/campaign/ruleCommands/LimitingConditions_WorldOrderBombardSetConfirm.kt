package limitingConditions.campaign.ruleCommands

import com.fs.starfarer.api.campaign.InteractionDialogAPI
import com.fs.starfarer.api.campaign.rules.MemoryAPI
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin
import com.fs.starfarer.api.util.Misc
import limitingConditions.helpers.ExternalStrings

class LimitingConditions_WorldOrderBombardSetConfirm : BaseCommandPlugin() {
    companion object {
        const val BOMBARD_OPTION_ID = "limitingConditions_worldOrderBombard"
    }
    override fun execute(
        ruleId: String?,
        dialog: InteractionDialogAPI?,
        params: MutableList<Misc.Token>?,
        memoryMap: MutableMap<String, MemoryAPI>?
    ): Boolean {
        dialog?.optionPanel?.addOptionConfirmation(
            BOMBARD_OPTION_ID,
            ExternalStrings.WORLD_ORDER_CONFIRM_DIALOG_TEXT,
            ExternalStrings.WORLD_ORDER_CONFIRM_DIALOG_YES,
            ExternalStrings.WORLD_ORDER_CONFIRM_DIALOG_NO
        )
        return true
    }
}