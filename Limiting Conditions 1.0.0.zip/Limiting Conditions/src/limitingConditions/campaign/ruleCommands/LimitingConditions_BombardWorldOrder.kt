package limitingConditions.campaign.ruleCommands

import com.fs.starfarer.api.campaign.InteractionDialogAPI
import com.fs.starfarer.api.campaign.TextPanelAPI
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.campaign.rules.MemoryAPI
import com.fs.starfarer.api.impl.campaign.ids.Conditions
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD.BombardmentAnimation
import com.fs.starfarer.api.util.Misc
import limitingConditions.campaign.econ.BaseNativesHazardCondition
import limitingConditions.campaign.ids.MemoryKeys
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.helpers.ExternalStrings
import limitingConditions.helpers.Helper
import limitingConditions.helpers.Memory

class LimitingConditions_BombardWorldOrder : BaseCommandPlugin() {
    companion object {
        const val ICON_SIZE = 40f
        const val S_TOKEN_MARKET = "\$market"
        const val S_TOKEN_MARKET_UC = "\$Market"
        const val TOKEN_MARKET_CAPITALIZED = "[CAPITALIZED MARKET NAME]"
        const val TOKEN_MARKET = "[MARKET NAME]"
    }
    override fun execute(
        ruleId: String?,
        dialog: InteractionDialogAPI?,
        params: MutableList<Misc.Token>?,
        memoryMap: MutableMap<String, MemoryAPI>?
    ): Boolean {
        val market = dialog?.interactionTarget?.market ?: return false
        doBombardment(market)
        showText(dialog)
        Memory.unset(MemoryKeys.OWO_XENOPHOBES, market)
        Memory.unset(MemoryKeys.OWO_REMOVE_LIGHTS, market)
        return true
    }

    private fun doBombardment(market: MarketAPI) {
        market.removeCondition(PCConditions.ONE_WORLD_ORDER)

        if (market.hasCondition(Conditions.HABITABLE) && !market.hasCondition(Conditions.POLLUTION)) {
            market.addCondition(Conditions.POLLUTION)
        }

        if (Memory.isFlag(MemoryKeys.OWO_XENOPHOBES, market)) market.addCondition(PCConditions.XENOPHOBES)
        else {
            market.addCondition(Conditions.DECIVILIZED)
            if (Memory.isFlag(MemoryKeys.OWO_REMOVE_LIGHTS, market)) {
                market.planetEntity?.spec?.glowTexture = null
                market.planetEntity?.applySpecChanges()
            }
            Misc.removeRadioChatter(market)
        }

        val target = market.primaryEntity
        var num: Int = (target.radius * target.radius / 300f).toInt()
        num *= 2
        num = num.coerceIn(10 .. 150)
        target.addScript(BombardmentAnimation(num, target))

    }

    private fun showText(dialog: InteractionDialogAPI?) {
        dialog?.visualPanel?.showImagePortion(
            "illustrations",
            "bombard_saturation_result",
            640f,
            400f,
            0f,
            0f,
            480f,
            300f
        );
        val textPanel = dialog?.textPanel ?: return

        textPanel.addPara(ExternalStrings.WORLD_ORDER_REMOVED)
        val highlight = ExternalStrings.WORLD_ORDER_REMOVED_HIGHLIGHT
        if (highlight.isNotEmpty()) textPanel.highlightInLastPara(Misc.getNegativeHighlightColor(), highlight)

        val market = dialog.interactionTarget?.market ?: return

        val conditions = mutableListOf<String>()

        conditions += if (Memory.isFlag(MemoryKeys.OWO_XENOPHOBES)) {
            PCConditions.XENOPHOBES
        } else {
            Conditions.DECIVILIZED
        }

        if (market.hasCondition(Conditions.HABITABLE) && !market.hasCondition(Conditions.POLLUTION)) {
            conditions += Conditions.POLLUTION
        }

        if (conditions.size == 1) {
            textPanel.addPara(ExternalStrings.WORLD_ORDER_NATIVE_CONDITION_ADDED)
        } else {
            textPanel.addPara(ExternalStrings.WORLD_ORDER_NATIVE_CONDITIONS_ADDED)
        }

        conditions.forEach {
            showIconAndDesc(textPanel, market, it)
        }
    }

    private fun showIconAndDesc(textPanel: TextPanelAPI, market: MarketAPI, conditionId: String) {
        val spec = Helper.settings?.getMarketConditionSpec(conditionId)
        val name = spec?.name ?: ExternalStrings.DEBUG_NULL
        var text = spec?.desc ?: ExternalStrings.DEBUG_NULL
        val icon = spec?.icon ?: return

        val plugin = market.getCondition(conditionId)?.plugin ?: return
        if (plugin is BaseNativesHazardCondition) {
            text = text.replace(BaseNativesHazardCondition.TOKEN_STRINGS_JSON, plugin.getNeutralDescription())
        }
        text = text.replace(TOKEN_MARKET_CAPITALIZED, S_TOKEN_MARKET_UC)
            .replace(TOKEN_MARKET, S_TOKEN_MARKET)
            .replace(S_TOKEN_MARKET_UC, Misc.ucFirst(market.name))
            .replace(S_TOKEN_MARKET, market.name)

        val tooltip = textPanel.beginTooltip()
        val image = tooltip.beginImageWithText(icon, ICON_SIZE)
        image.setTitleOrbitronLarge()
        image.addTitle(name)
        image.addPara(text, 0f)
        tooltip.addImageWithText(0f)
        textPanel.addTooltip()
    }
}