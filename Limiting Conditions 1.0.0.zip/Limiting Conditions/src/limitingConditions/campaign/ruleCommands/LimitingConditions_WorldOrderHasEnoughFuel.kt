package limitingConditions.campaign.ruleCommands

import com.fs.starfarer.api.campaign.InteractionDialogAPI
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.campaign.rules.MemoryAPI
import com.fs.starfarer.api.impl.campaign.ids.Stats
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin
import com.fs.starfarer.api.util.Misc
import limitingConditions.helpers.Helper

class LimitingConditions_WorldOrderHasEnoughFuel : BaseCommandPlugin() {
    companion object {
        const val BASE_FUEL = 2000f

        fun getFuelRequired(market: MarketAPI): Float {
            val playerFleet = Helper.sector?.playerFleet ?: return BASE_FUEL
            val bombardBonus = Misc.getFleetwideTotalMod(playerFleet, Stats.FLEET_BOMBARD_COST_REDUCTION, 0f)
            return (BASE_FUEL - bombardBonus) / (market.hazardValue + 1)
        }

        fun hasEnoughFuel(market: MarketAPI): Boolean {
            return (Helper.sector?.playerFleet?.cargo?.fuel ?: 0f ) >= getFuelRequired(market)
        }
    }

    override fun execute(
        ruleId: String?,
        dialog: InteractionDialogAPI?,
        params: MutableList<Misc.Token>?,
        memoryMap: MutableMap<String, MemoryAPI>?
    ): Boolean {
        if (dialog?.interactionTarget?.market == null) return false
        return hasEnoughFuel(dialog.interactionTarget.market)
    }
}