package limitingConditions.campaign.industries

import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry
import com.fs.starfarer.api.impl.campaign.ids.Commodities
import com.fs.starfarer.api.util.Pair
import limitingConditions.campaign.ids.PCConditions

/**
 * Author: SafariJohn
 */
class Shipbreaking : BaseIndustry() {
    override fun apply() {
        super.apply(true)

        val size = market.size

        demand(Commodities.HEAVY_MACHINERY, size - 2)
        demand(Commodities.SHIPS, size)

        supply(Commodities.SUPPLIES, size)
        supply(Commodities.METALS, size)
        supply(Commodities.RARE_METALS, size - 2)

        val deficit: Pair<String, Int> = getMaxDeficit(Commodities.HEAVY_MACHINERY, Commodities.SHIPS)
        applyDeficitToProduction(
            1, deficit,
            Commodities.SUPPLIES,
            Commodities.METALS,
            Commodities.RARE_METALS
        )

        if (!isFunctional()) {
            supply.clear()
        }
    }

    override fun isAvailableToBuild(): Boolean {
        return market.hasCondition(PCConditions.BONEYARD)
                || market.hasCondition(PCConditions.GRAVEYARD)
    }

    override fun showWhenUnavailable(): Boolean {
        return false
    }

    override fun getPatherInterest(): Float {
        return 1f + super.getPatherInterest()
    }
}
