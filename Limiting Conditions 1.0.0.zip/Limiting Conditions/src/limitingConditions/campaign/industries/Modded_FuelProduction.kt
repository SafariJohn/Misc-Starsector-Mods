package limitingConditions.campaign.industries

import com.fs.starfarer.api.impl.campaign.econ.impl.FuelProduction
import com.fs.starfarer.api.impl.campaign.econ.impl.ItemEffectsRepo
import com.fs.starfarer.api.impl.campaign.ids.Commodities
import com.fs.starfarer.api.impl.campaign.ids.Items
import com.fs.starfarer.api.impl.campaign.ids.Stats
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.helpers.ExternalStrings
import limitingConditions.helpers.Helper

class Modded_FuelProduction : FuelProduction() {
    companion object {
        const val MASSIVE_PRODUCTION = 5
        val ADVANCED_ICON = Pair("industry", "advanced_fuel_prod")
    }

    override fun apply() {
        super.apply(true)
        supplyBonus.modifyFlat(
            getModId(2),
            market.admin?.stats?.dynamic?.getValue(Stats.FUEL_SUPPLY_BONUS_MOD, 0f) ?: 0f,
            ExternalStrings.INDUSTRY_ADMINISTRATOR
        )

        val size = market.size

        if (market.hasCondition(PCConditions.FUEL_PLANT)) {
            supply(Commodities.FUEL, size - 1)
            demand(Commodities.VOLATILES, size + 1)
            demand(Commodities.HEAVY_MACHINERY, size - 1)
        } else {
            supply(Commodities.FUEL, 1, ExternalStrings.FUEL_PRODUCTION_BASE_VALUE_NO_DOMAIN_TECH)
            demand(Commodities.VOLATILES, 3)
            demand(Commodities.HEAVY_MACHINERY, 1)
        }

        val deficit = getMaxDeficit(Commodities.VOLATILES)
        applyDeficitToProduction(1, deficit, Commodities.FUEL)

        if (!isFunctional) {
            supply.clear()
        }
    }

    private fun isMassiveProduction(): Boolean {
        var production = 1
        production += market.size - 2
        production += market.admin?.stats?.dynamic?.getValue(Stats.FUEL_SUPPLY_BONUS_MOD, 0f)?.toInt() ?: 0
        if (specialItem?.id == Items.SYNCHROTRON) production += ItemEffectsRepo.SYNCHROTRON_FUEL_BONUS
        if (isImproved) production++
        return production >= MASSIVE_PRODUCTION
    }

    override fun getCurrentImage(): String {
        return if (isMassiveProduction()) {
            Helper.settings?.getSpriteName(ADVANCED_ICON.first, ADVANCED_ICON.second) ?: spec.imageName
        } else {
            spec.imageName
        }
    }

    override fun getDescriptionOverride(): String {
        val isDomainTech = market.hasCondition(PCConditions.FUEL_PLANT)
        val isMassive = isMassiveProduction()
        return if (isDomainTech && isMassive) {
            ExternalStrings.FUEL_PRODUCTION_DOMAIN_TECH_MASSIVE
        } else if (isDomainTech) {
            ExternalStrings.FUEL_PRODUCTION_DOMAIN_TECH
        } else if (isMassive) {
            ExternalStrings.FUEL_PRODUCTION_MASSIVE
        } else {
            spec.desc
        }
    }
}