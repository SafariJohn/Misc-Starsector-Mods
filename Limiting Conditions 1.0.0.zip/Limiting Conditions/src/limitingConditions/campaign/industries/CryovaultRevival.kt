package limitingConditions.campaign.industries

import com.fs.starfarer.api.Global
import com.fs.starfarer.api.campaign.econ.Industry.*
import com.fs.starfarer.api.campaign.econ.MarketAPI
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier
import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry
import com.fs.starfarer.api.impl.campaign.econ.impl.Cryorevival
import com.fs.starfarer.api.impl.campaign.ids.Commodities
import com.fs.starfarer.api.impl.campaign.ids.Factions
import com.fs.starfarer.api.impl.campaign.ids.Industries
import com.fs.starfarer.api.impl.campaign.ids.Tags
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition
import com.fs.starfarer.api.ui.TooltipMakerAPI
import com.fs.starfarer.api.util.Misc
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.campaign.ids.PCIndustries
import limitingConditions.helpers.ExternalStrings
import limitingConditions.helpers.ExternalStrings.replaceValueToken
import limitingConditions.helpers.Helper

class CryovaultRevival : BaseIndustry(), MarketImmigrationModifier {
    companion object {
        @JvmField
        val BLOCKING_INDUSTRIES = mutableSetOf(
            Industries.CRYOSANCTUM,
            PCIndustries.CRYOVAULT_SANCTUM
        )

        val UPKEEP_MULT_STRING = ExternalStrings.PERCENT.replaceValueToken(((1f - UPKEEP_MULT) * 100f).toInt().toString())
        val MAX_GROWTH_UNMET_DEMAND = ExternalStrings.PERCENT.replaceValueToken(Math.round(Cryorevival.MAX_BONUS_WHEN_UNMET_DEMAND * 100f).toString())

        const val ORGANICS_DEMAND = 10

        const val SIZE_IMMIGRATION_MULT = 10f

        const val TOKEN_PREFIX = "[PREFIX]"
        const val TOKEN_UPKEEP_DISCOUNT = "[UPKEEP DISCOUNT]"
        const val TOKEN_DEMAND_REDUCTION = "[DEMAND REDUCTION]"
        const val TOKEN_GROWTH = "[GROWTH]"
        const val TOKEN_MAX_GROWTH = "[MAX GROWTH]"
        const val TOKEN_GROWTH_REDUCTION = "[GROWTH REDUCTION]"
        const val TOKEN_IMPROVED_NAME = "[IMPROVED NAME]"
    }

    override fun apply() {
        super.apply(true)
        demand(Commodities.ORGANICS, ORGANICS_DEMAND)
    }

    override fun modifyIncoming(market: MarketAPI?, incoming: PopulationComposition?) {
        if (incoming == null) return
        if (isFunctional) {
            val bonus = getMaxImmigrationMult()
            incoming.add(Factions.SLEEPER, bonus * 2f)
            incoming.weight.modifyFlat(modId, bonus, nameForModifier)

            if (Commodities.ALPHA_CORE == getAICoreId()) {
                incoming.weight.modifyFlat(
                    getModId(1), (bonus * Cryorevival.ALPHA_CORE_BONUS).toInt().toFloat(),
                    ExternalStrings.CRYOREVIVAL_ALPHA_GROWTH_MODIFIER_NAME
                )
            }
            if (isImproved) {
                incoming.weight.modifyFlat(
                    getModId(2), (bonus * Cryorevival.IMPROVE_BONUS).toInt().toFloat(),
                    ExternalStrings.CRYOREVIVAL_IMPROVED_GROWTH_MODIFIER_NAME.replace(TOKEN_IMPROVED_NAME, improvementsDescForModifiers)
                )
            }
        }
    }


    override fun isAvailableToBuild(): Boolean {
        if (market.hasTag(Tags.MARKET_NO_INDUSTRIES_ALLOWED)) return false
        return market.hasCondition(PCConditions.CRYOVAULT)
                && BLOCKING_INDUSTRIES.none { market.hasIndustry(it) }
    }

    override fun showWhenUnavailable(): Boolean {
        return market.hasCondition(PCConditions.CRYOVAULT)
    }

    override fun getUnavailableReason(): String = ExternalStrings.CRYOVAULT_ALREADY_BUILT

    override fun hasPostDemandSection(hasDemand: Boolean, mode: IndustryTooltipMode): Boolean {
        return mode != IndustryTooltipMode.NORMAL || isFunctional
    }

    override fun addPostDemandSection(
        tooltip: TooltipMakerAPI?,
        hasDemand: Boolean,
        mode: IndustryTooltipMode?
    ) {
        if (tooltip == null) return
        if (mode != IndustryTooltipMode.NORMAL || isFunctional) {

            val max = getMaxImmigrationMult()
            val demandMult = getImmigrationDemandMult()
            val bonus = max * demandMult

            if (mode != IndustryTooltipMode.NORMAL) {
                tooltip.addPara(
                    ExternalStrings.CRYOREVIVAL_UNMET_DEMAND_PENALTY_PREVIEW.replace(TOKEN_GROWTH_REDUCTION, Helper.STRING_TOKEN),
                    Helper.SMALL_PAD, Misc.getHighlightColor(),
                    MAX_GROWTH_UNMET_DEMAND
                )
            } else {
                val text = ExternalStrings.CRYOREVIVAL_UNMET_DEMAND_PENALTY_ACTIVE
                    .replace(TOKEN_GROWTH, Helper.STRING_TOKEN)
                    .replace(TOKEN_GROWTH_REDUCTION, Helper.STRING_TOKEN)
                tooltip.addPara(
                    text,
                    Helper.SMALL_PAD, Misc.getHighlightColor(),
                    ExternalStrings.PERCENT.replaceValueToken(Math.round(demandMult * 100f).toString()),
                    MAX_GROWTH_UNMET_DEMAND
                )
            }

            val text = ExternalStrings.CRYOREVIVAL_GROWTH_POST_DEMAND
                .replace(TOKEN_GROWTH, Helper.STRING_TOKEN)
                .replace(TOKEN_MAX_GROWTH, Helper.STRING_TOKEN)
            tooltip.addPara(
                text,
                Helper.SMALL_PAD,
                Misc.getHighlightColor(),
                ExternalStrings.PLUS_FLAT.replaceValueToken(Math.round(bonus).toString()),
                ExternalStrings.PLUS_FLAT.replaceValueToken(Math.round(max).toString())
            )
        }
    }

    override fun applyAlphaCoreModifiers() {}
    override fun applyNoAICoreModifiers() {}

    override fun applyAlphaCoreSupplyAndDemandModifiers() {
        demandReduction.modifyFlat(getModId(0), Cryorevival.DEMAND_REDUCTION.toFloat(), ExternalStrings.INDUSTRY_ALPHA_CORE_MODIFIER_NAME)
    }

    override fun addAlphaCoreDescription(tooltip: TooltipMakerAPI, mode: AICoreDescriptionMode) {
        val highlight = Misc.getHighlightColor()

        val pre = if (mode == AICoreDescriptionMode.MANAGE_CORE_DIALOG_LIST || mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            ExternalStrings.INDUSTRY_ALPHA_CORE_PREVIEW
        } else {
            ExternalStrings.INDUSTRY_ALPHA_CORE_ASSIGNED
        }

        val a: Float = getImmigrationMult() * Cryorevival.ALPHA_CORE_BONUS
        val str = ExternalStrings.PLUS_FLAT.replaceValueToken(Math.round(a).toString())

        if (mode == AICoreDescriptionMode.INDUSTRY_TOOLTIP) {
            val coreSpec = Global.getSettings().getCommoditySpec(aiCoreId)
            val image = tooltip.beginImageWithText(coreSpec.iconName, 48f)
            val text = ExternalStrings.CRYOREVIVAL_ALPHA_EFFECTS_ACTIVE
                .replace(TOKEN_PREFIX, pre)
                .replace(TOKEN_UPKEEP_DISCOUNT, Helper.STRING_TOKEN)
                .replace(TOKEN_DEMAND_REDUCTION, Helper.STRING_TOKEN)
                .replace(TOKEN_GROWTH, Helper.STRING_TOKEN)
            image.addPara(
                text, 0f, highlight,
                UPKEEP_MULT_STRING, Cryorevival.DEMAND_REDUCTION.toString(),
                str
            )
            tooltip.addImageWithText(Helper.PAD)
        } else {
            val text = ExternalStrings.CRYOREVIVAL_ALPHA_EFFECTS_PREVIEW
                .replace(TOKEN_PREFIX, pre)
                .replace(TOKEN_UPKEEP_DISCOUNT, Helper.STRING_TOKEN)
                .replace(TOKEN_DEMAND_REDUCTION, Helper.STRING_TOKEN)
                .replace(TOKEN_GROWTH, Helper.STRING_TOKEN)
            tooltip.addPara(
                text, Helper.PAD, highlight,
                UPKEEP_MULT_STRING, DEMAND_REDUCTION.toString(),
                str
            )
        }
    }

    override fun canImprove(): Boolean = true

    override fun addImproveDesc(info: TooltipMakerAPI?, mode: ImprovementDescriptionMode?) {
        if (info == null) return
        val highlight = Misc.getHighlightColor()

        val a: Float = getImmigrationMult() * Cryorevival.IMPROVE_BONUS
        val str = Math.round(a).toString()

        if (mode == ImprovementDescriptionMode.INDUSTRY_TOOLTIP) {
            info.addPara(ExternalStrings.CRYOREVIVAL_GROWTH_ACTIVE.replace(TOKEN_GROWTH, Helper.STRING_TOKEN), 0f, highlight, str)
        } else {
            info.addPara(ExternalStrings.CRYOREVIVAL_GROWTH_PREVIEW.replace(TOKEN_GROWTH, Helper.STRING_TOKEN), 0f, highlight, str)
        }

        info.addSpacer(Helper.PAD)
        super.addImproveDesc(info, mode)
    }
    
    private fun  getImmigrationMult(): Float = getMaxImmigrationMult() * getImmigrationDemandMult()

    private fun getMaxImmigrationMult(): Float = (market?.size ?: 0) * SIZE_IMMIGRATION_MULT

    private fun getImmigrationDemandMult(): Float {
        val deficit = getMaxDeficit(Commodities.ORGANICS)
        val demand = getDemand(Commodities.ORGANICS)?.quantity?.modifiedValue ?: 0f
        var def = deficit.two.toFloat()
        if (def > demand) def = demand

        var mult = 1f
        if (def > 0 && demand > 0) {
            mult = (demand - def) / demand
            mult *= Cryorevival.MAX_BONUS_WHEN_UNMET_DEMAND
        }
        return mult
    }
}