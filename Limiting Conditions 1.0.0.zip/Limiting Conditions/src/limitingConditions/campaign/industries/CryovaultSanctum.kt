package limitingConditions.campaign.industries

import com.fs.starfarer.api.impl.campaign.econ.impl.Cryosanctum
import com.fs.starfarer.api.impl.campaign.ids.Industries
import com.fs.starfarer.api.impl.campaign.ids.Tags
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.campaign.ids.PCIndustries
import limitingConditions.helpers.ExternalStrings

class CryovaultSanctum : Cryosanctum() {
    companion object {
        @JvmField
        val BLOCKING_INDUSTRIES = mutableSetOf(
            Industries.CRYOSANCTUM,
            PCIndustries.CRYOVAULT_REVIVAL
        )
    }

    override fun isAvailableToBuild(): Boolean {
        if (market.hasTag(Tags.MARKET_NO_INDUSTRIES_ALLOWED)) return false
        return market.hasCondition(PCConditions.CRYOVAULT)
                && BLOCKING_INDUSTRIES.none { market.hasIndustry(it) }
    }

    override fun showWhenUnavailable(): Boolean {
        return market.hasCondition(PCConditions.CRYOVAULT)
    }

    override fun getUnavailableReason(): String = ExternalStrings.CRYOVAULT_ALREADY_BUILT
}