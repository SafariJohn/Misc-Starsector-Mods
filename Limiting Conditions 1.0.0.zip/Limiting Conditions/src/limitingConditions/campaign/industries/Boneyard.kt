package limitingConditions.campaign.industries

import com.fs.starfarer.api.impl.campaign.econ.impl.BaseIndustry
import com.fs.starfarer.api.impl.campaign.ids.Commodities
import com.fs.starfarer.api.impl.campaign.ids.Stats
import com.fs.starfarer.api.util.Pair
import limitingConditions.campaign.ids.PCConditions
import limitingConditions.helpers.ExternalStrings
import kotlin.math.max

/**
 * Author: SafariJohn
 */
class Boneyard : BaseIndustry() {
    companion object {
        const val TOKEN_INDUSTRY = "[INDUSTRY]"
    }

    override fun apply() {
        val size = market.size

        supply(Commodities.SHIPS, size - 1)
        supply(Commodities.METALS, size)

        demand(Commodities.SUPPLIES, size)
        demand(Commodities.HEAVY_MACHINERY, size - 2)

        val deficit: Pair<String, Int> = getMaxDeficit(Commodities.SUPPLIES, Commodities.HEAVY_MACHINERY)
        val maxDeficit = max(0, (size - 3)) // to allow *some* production so economy doesn't get into an unrecoverable state
        if (deficit.two > maxDeficit) deficit.two = maxDeficit

        applyDeficitToProduction(
            2,
            deficit,
            Commodities.METALS,
            Commodities.SHIPS
        )

        val stability: Float = market.prevStability
        if (stability < 5) {
            var stabilityMod = (stability - 5f) / 5f
            stabilityMod *= 0.5f
            market.stats?.dynamic?.getMod(Stats.PRODUCTION_QUALITY_MOD)
                ?.modifyFlat(
                    getModId(0),
                    stabilityMod,
                    ExternalStrings.INDUSTRY_LOW_STABILITY_MODIFIER_DESC.replace(TOKEN_INDUSTRY, nameForModifier)
                )
        }

        if (!isFunctional()) {
            supply.clear()
            unapply()
        }
    }

    override fun unapply() {
        super.unapply()

        market.stats?.dynamic?.getMod(Stats.PRODUCTION_QUALITY_MOD)?.unmodifyFlat(getModId(0))
    }

    override fun isAvailableToBuild(): Boolean {
        return market.hasCondition(PCConditions.BONEYARD)
    }

    override fun showWhenUnavailable(): Boolean {
        return false
    }

    override fun getPatherInterest(): Float {
        return 2f + super.getPatherInterest()
    }
}
