package scripts;

import scripts.campaign.LogisticsNotifications_NotificationScript;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.tutorial.TutorialMissionIntel;
import com.fs.starfarer.api.ui.HintPanelAPI;

/**
 * Author: SafariJohn
 */
public class LogisticsNotifications_ModPlugin extends BaseModPlugin {

    @Override
    public void onGameLoad(boolean newGame) {
        Global.getSector().addTransientScript(new LogisticsNotifications_NotificationScript());
    }

    @Override
    public void beforeGameSave() {
        HintPanelAPI hints = Global.getSector().getCampaignUI().getHintPanel();

        if (TutorialMissionIntel.isTutorialInProgress()) {
                hints.fadeOutHint(3);
        } else {
            hints.fadeOutHint(0);
        }
    }

}
