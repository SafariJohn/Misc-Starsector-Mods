package scripts;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel;
import com.fs.starfarer.api.campaign.ai.FleetAIFlags;
import com.fs.starfarer.api.loading.CampaignPingSpec;
import static ids.HostileIntercept_Settings.*;
import java.awt.Color;
import java.util.List;
import static scripts.HostileIntercept_ModPlugin.BOOLEAN_CHECK_INTERVAL;

/**
 * Author: SafariJohn
 */
public class HostileIntercept_InterceptPings implements EveryFrameScript {

    public static final String IGNORE_KEY = "$hostileIntercept_alarmTimeout";
    public static final float EXPIRATION = 30f; // seconds

    public static final Color INTERCEPT_COLOR = new Color(150,150,150,255);
	public static final float INTERVAL = 0.6f;

    private boolean withSound;
    private String soundId;

    private float interval = 0;
    private float booleansInterval = 0;

    public HostileIntercept_InterceptPings() {
        withSound = isFeatureEnabled(INTERCEPT_ALARM_KEY);
        soundId = Global.getSettings().getString(INTERCEPT_SOUND_KEY);
    }

    @Override
    public void advance(float amount) {
        if (Global.getSector().isPaused()) return;

        interval += amount;
        booleansInterval += amount;

        if (booleansInterval >= BOOLEAN_CHECK_INTERVAL) {
            booleansInterval -= BOOLEAN_CHECK_INTERVAL;
            withSound = isFeatureEnabled(INTERCEPT_ALARM_KEY);
        }

        if (interval < INTERVAL) return;

        interval -= INTERVAL;

        List<CampaignFleetAPI> fleets = Global.getSector().getPlayerFleet().getContainingLocation().getFleets();

        for (CampaignFleetAPI fleet : fleets) {
            if (fleet == Global.getSector().getPlayerFleet()) continue;

            VisibilityLevel vis = fleet.getVisibilityLevelToPlayerFleet();
            if (vis == VisibilityLevel.NONE || vis == VisibilityLevel.SENSOR_CONTACT) continue;

            SectorEntityToken target = (SectorEntityToken) fleet
                        .getMemoryWithoutUpdate().get(FleetAIFlags.PURSUIT_TARGET);

            if (target != Global.getSector().getPlayerFleet()) continue;

            Color color = INTERCEPT_COLOR;
            float range = fleet.getRadius();

			CampaignPingSpec custom = new CampaignPingSpec();
            custom.setColor(color);
			custom.setUseFactionColor(false);
			custom.setWidth(Math.max(range / 5, 10));
			custom.setMinRange(range);
			custom.setRange(range * 2);
			custom.setDuration(.8f);
			custom.setAlphaMult(1f);
			custom.setInFraction(0.2f);
			custom.setNum(1);
//            custom.setInvert(true);

			Global.getSector().addPing(fleet, custom);

            if (withSound) {
                if (fleet.getMemoryWithoutUpdate().contains(IGNORE_KEY)) {
                    if (fleet.getMemoryWithoutUpdate().getExpire(IGNORE_KEY) <= EXPIRATION) {
                        fleet.getMemoryWithoutUpdate().set(IGNORE_KEY, true, EXPIRATION);
                    }
                } else {
                    fleet.getMemoryWithoutUpdate().set(IGNORE_KEY, true, EXPIRATION);

//                    String soundId = Global.getSettings().getString(INTERCEPT_SOUND_KEY);
                    try { // Play nothing if the soundId is invalid
                        Global.getSoundPlayer().playUISound(soundId, 1f, 1f);
                    } catch (RuntimeException ex) {}
                }
            }
        }
    }

    public boolean isDone() {
        return false;
    }
    public boolean runWhilePaused() {
        return false;
    }
}