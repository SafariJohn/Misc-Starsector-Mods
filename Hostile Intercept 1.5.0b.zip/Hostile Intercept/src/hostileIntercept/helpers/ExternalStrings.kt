package hostileIntercept.helpers

object ExternalStrings {
    private const val ID = "hostileIntercept"
    private fun get(id: String): String {
        return Helper.settings?.getString(ID, id) ?: "N/A $id"
    }

    val LAZY_LIB_REQ = get("lazyLibReq")
    val AUTOPAUSE_ENABLED = get("autopauseEnabled")
    val AUTOPAUSE_DISABLED = get("autopauseDisabled")
    val INTERCEPT_ENABLED = get("interceptEnabled")
    val AUTOPAUSE_ALARM_ENABLED = get("autopauseAlarmEnabled")
    val AUTOPAUSE_ALARM_DISABLED = get("autopauseAlarmDisabled")
    val INTERCEPT_ALARM_ENABLED = get("interceptAlarmEnabled")
    val INTERCEPT_ALARM_DISABLED = get("interceptAlarmDisabled")
    val JUMP_PAUSE_ENABLED = get("jumpPauseEnabled")
    val JUMP_PAUSE_DISABLED = get("jumpPauseDisabled")
    val THREATENED_ENABLED = get("threatenedEnabled")
    val JUMP_PAUSE_ALARM_ENABLED = get("jumpPauseAlarmEnabled")
    val JUMP_PAUSE_ALARM_DISABLED = get("jumpPauseAlarmDisabled")
    val POTENTIAL_THREAT = get("potentialThreat")
    val POTENTIAL_THREATS = get("potentialThreats")
}