package hostileIntercept.helpers

object Ids {
    const val LAZY_LIB = "lw_lazylib"
    const val DEV_MOD_ID = "hostileInterceptDev"
    const val MOD_ID = "hostileIntercept"
    const val STATION_MARKET_KEY = "\$stationMarket"
}