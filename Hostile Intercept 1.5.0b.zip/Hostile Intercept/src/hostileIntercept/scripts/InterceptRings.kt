package hostileIntercept.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.campaign.SectorEntityToken
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel
import com.fs.starfarer.api.campaign.ai.FleetAIFlags
import com.fs.starfarer.api.loading.CampaignPingSpec
import hostileIntercept.helpers.Helper
import hostileIntercept.helpers.Memory
import hostileIntercept.ModPlugin
import hostileIntercept.helpers.Settings
import java.awt.Color

class InterceptRings : EveryFrameScript {
    companion object {
        const val IGNORE_KEY = "\$hostileIntercept_alarmTimeout"
        const val EXPIRATION = 30f // seconds


        val INTERCEPT_COLOR = Color(150, 150, 150, 255)
        const val INTERVAL = 0.6f
    }
    private var withSound = false
    private var soundId: String? = null

    private var interval = 0f
    private var booleansInterval = 0f

    init {
        withSound = Settings.isFeatureEnabled(Settings.INTERCEPT_ALARM_KEY)
        soundId = Helper.settings?.getString(Settings.INTERCEPT_SOUND_KEY)
    }

    override fun advance(amount: Float) {
        if (Helper.isSectorPaused) return
        interval += amount
        booleansInterval += amount
        if (booleansInterval >= ModPlugin.BOOLEAN_CHECK_INTERVAL) {
            booleansInterval -= ModPlugin.BOOLEAN_CHECK_INTERVAL
            withSound = Settings.isFeatureEnabled(Settings.INTERCEPT_ALARM_KEY)
        }
        if (interval < INTERVAL) return
        interval -= INTERVAL
        val fleets = Helper.sector?.playerFleet?.containingLocation?.fleets ?: return
        for (fleet in fleets) {
            if (fleet === Helper.sector?.playerFleet) continue
            val vis = fleet.visibilityLevelToPlayerFleet
            if (vis == VisibilityLevel.NONE || vis == VisibilityLevel.SENSOR_CONTACT) continue
            val target = Memory.getNullable(
                FleetAIFlags.PURSUIT_TARGET,
                fleet,
                { it is SectorEntityToken },
                { null }
            ) as? SectorEntityToken ?: continue
            if (target !== Helper.sector?.playerFleet) continue
            val color = INTERCEPT_COLOR
            val range = fleet.radius
            val custom = CampaignPingSpec().apply {
                this.color = color
                this.isUseFactionColor = false
                this.width = (range / 5).coerceAtLeast(10f)
                this.minRange = range
                this.range = range * 2
                this.duration = .8f
                this.alphaMult = 1f
                this.inFraction = 0.2f
                this.num = 1
            }
            Helper.sector?.addPing(fleet, custom)
            if (withSound) {
                if (fleet.memoryWithoutUpdate.contains(IGNORE_KEY)) {
                    if (fleet.memoryWithoutUpdate.getExpire(IGNORE_KEY) <= EXPIRATION) {
                        fleet.memoryWithoutUpdate[IGNORE_KEY, true] = EXPIRATION
                    }
                } else {
                    fleet.memoryWithoutUpdate[IGNORE_KEY, true] = EXPIRATION
                    try {
                        Helper.soundPlayer?.playUISound(soundId, 1f, 1f)
                    } catch (_: RuntimeException) {}
                }
            }
        }
    }

    override fun isDone(): Boolean = false
    override fun runWhilePaused(): Boolean = false
}