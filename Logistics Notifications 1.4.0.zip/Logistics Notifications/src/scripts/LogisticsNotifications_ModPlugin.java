package scripts;

import scripts.campaign.LogisticsNotifications_NotificationScript;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import scripts.campaign.LogisticsNotifications_Draw;

/**
 * Author: SafariJohn
 */
public class LogisticsNotifications_ModPlugin extends BaseModPlugin {

    @Override
    public void onGameLoad(boolean newGame) {
        Global.getSector().addTransientScript(new LogisticsNotifications_NotificationScript());
        Global.getSector().addTransientScript(new LogisticsNotifications_Draw());
    }

}
