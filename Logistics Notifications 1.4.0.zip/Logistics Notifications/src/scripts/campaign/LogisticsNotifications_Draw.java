package scripts.campaign;

import com.fs.starfarer.api.EveryFrameScriptWithCleanup;
import java.awt.Color;
import org.lazywizard.lazylib.ui.FontException;
import org.lazywizard.lazylib.ui.LazyFont;
import org.lazywizard.lazylib.ui.LazyFont.DrawableString;

/**
 * Author: SafariJohn
 */
public class LogisticsNotifications_Draw implements EveryFrameScriptWithCleanup {
    LazyFont font;
    private static DrawableString draw = null;

    public LogisticsNotifications_Draw() {
        try {
            font = LazyFont.loadFont("graphics/fonts/insignia21LTaa.fnt");
            draw = font.createText("test");
            draw.setColor(Color.yellow);
            draw.setMaxWidth(100);
            draw.setMaxHeight(100);
            draw.setRenderDebugBounds(true);
        } catch (FontException ex) {
        }
    }

    @Override
    public boolean isDone() {
        return false;
    }

    @Override
    public boolean runWhilePaused() {
        return true;
    }

    @Override
    public void advance(float amount) {
        draw.draw(10, 10);
    }

    @Override
    public void cleanup() {
        draw.dispose();
    }
}
