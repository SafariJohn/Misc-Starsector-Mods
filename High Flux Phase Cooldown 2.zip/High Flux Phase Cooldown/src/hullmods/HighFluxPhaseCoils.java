package hullmods;

import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.hullmods.PhaseField;

/**
 * Author: SafariJohn
 */
public class HighFluxPhaseCoils extends PhaseField {
    public static final String ID = "hfpc_coil";
    public static final float MAX_MULT = 4f;
    public static final float BASE = 1.01f;

    private transient boolean firstTime = true;
    private transient float baseCooldown = 1;

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        if (firstTime) {
            firstTime = false;
            baseCooldown = ship.getPhaseCloak().getCooldown();
        }

        if (ship.getPhaseCloak().isCoolingDown()) {
//            ship.getFluxTracker().stopVenting();
            return;
        }

        float fluxPercent = ship.getFluxTracker().getHardFlux()
                    / ship.getFluxTracker().getMaxFlux();
        float exp = (float) (Math.log(MAX_MULT) / Math.log(BASE));

        float mult = (float) Math.pow(BASE, fluxPercent * exp);

        ship.getPhaseCloak().setCooldown(baseCooldown * mult);

    }

}
