package logNot.commands

import logNot.scripts.NotificationScript
import org.lazywizard.console.BaseCommand
import org.lazywizard.console.BaseCommand.CommandContext
import org.lazywizard.console.BaseCommand.CommandResult
import org.lazywizard.console.Console

class DisplaySupplyFuel : BaseCommand {
    override fun runCommand(args: String, context: CommandContext): CommandResult {
        val m = NotificationScript.displayConsole(true, true)
        Console.showMessage(m)
        return CommandResult.SUCCESS
    }
}