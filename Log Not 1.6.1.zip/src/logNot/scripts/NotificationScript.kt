package logNot.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.Global
import com.fs.starfarer.api.fleet.FleetMemberAPI
import com.fs.starfarer.api.util.Misc
import org.json.JSONException
import java.awt.Color
import java.io.IOException
import java.util.logging.Level
import java.util.logging.Logger

class NotificationScript : EveryFrameScript {
    companion object {
        fun displayConsole(supply: Boolean, fuel: Boolean): String? {
            var s: String = ""
            if (supply) {
                val suDisplay = (getSupplyDays() * 10f).toInt() / 10f
                s += "You have about $suDisplay days of supply left." // extern
                if (fuel) s += "\n"
            }
            if (fuel) {
                val fuelDisplay = (getFuelLY() * 10f).toInt() / 10f
                s += "You have enough fuel to travel about $fuelDisplay lightyears."
            }
            return s
        }

        /**
         * Calculates how many days of supply the player has left, accounting for repairs and recovery.
         * @return days of supply
         */
        private fun getSupplyDays(): Float {
            // Calculate days of supply remaining
            val playerFleet = Global.getSector().playerFleet
            val supplies = playerFleet.cargo.supplies
            val logistics = playerFleet.logistics
            val recoveryCost = logistics.totalRepairAndRecoverySupplyCost
            val totalPerDay = logistics.totalSuppliesPerDay
            val suDays: Float
            // Running out
            if (recoveryCost >= supplies) {
                suDays = supplies / totalPerDay
            } else {

                // Total up maintenance costs per day for fleet
                var maintPerDay = 0f
                for (mem: FleetMemberAPI in playerFleet.membersWithFightersCopy) {
                    val maint = mem.stats.suppliesPerMonth.modifiedValue / 30
                    maintPerDay += maint
                }
                // Account for extra cost from over-capacity
                // Not going to try to do cargo because it's reductive as it consumes supplies
                maintPerDay += logistics.excessPersonnelCapacitySupplyCost
                maintPerDay += logistics.excessFuelCapacitySupplyCost

                // And finally: compute!
                suDays = (recoveryCost / totalPerDay) + ((supplies - recoveryCost.toInt()) / maintPerDay)
            }
            return suDays
        }


        /**
         * Calculates how far the player's fleet can travel, minus amount needed to jump to hyper if in-system.
         * @return distance in lightyears
         */
        private fun getFuelLY(): Float {
            // Calculate lightyears of fuel remaining
            val playerFleet = Global.getSector().playerFleet
            val fuel = playerFleet.cargo.fuel
            val fuelPerDay = playerFleet.logistics.baseFuelCostPerLightYear
            var ly: Float
            if (playerFleet.isInHyperspace) {
                ly = fuel / fuelPerDay
            } else {
                ly = (fuel - fuelPerDay) / fuelPerDay
            }
            if (ly < 0) ly = 0f
            return ly
        }
    }

    // These are specified in data/config/Logistics Notifications/config.json
    // Whether to use this display method
    private var DISPLAY_NOTIFICATIONS = false

    // How often supply/fuel status is displayed
    private var INCREMENT = 0

    // Warning (orange text) and alarm times in days of supply
    private var LOW_SUPPLIES = 0
    private var ALARM_SUPPLIES = 0

    // Warning (orange text) and alarm distances in ly
    private var LOW_FUEL = 0
    private var ALARM_FUEL = 0

    // Whether sound alarm should play
    private var SOUND_ALARM = false

    // Sound ids
    private var ALARM_ID: String? = null
    private var FOLLOWUP_ID: String? = null
    private var SUPPLY_ALARM_ID: String? = null
    private var SUPPLY_FOLLOWUP_ID: String? = null
    private var FUEL_ALARM_ID: String? = null
    private var FUEL_FOLLOWUP_ID: String? = null

    private var lastDay = 0
    private var counter = 0
    private var alarmed = false

    private var interval = 0f
    private val INTERVAL = 1f


    init {
        lastDay = -1
        counter = 0
        alarmed = false
        interval = INTERVAL

        // Load settings from config.json
        // Defaults
        var notifications = false
        var increment = 3
        var lowSupplies = 30
        var alarmSupplies = 10
        var lowFuel = 20
        var alarmFuel = 10
        var soundAlarm = true
        var alarmId: String = "cr_playership_critical"
        var followupId: String = "cr_playership_critical"
        var suAlarmId: String = "cr_playership_critical"
        var suFollowupId: String = "cr_playership_critical"
        var fuelAlarmId: String = "cr_playership_critical"
        var fuelFollowupId: String = "cr_playership_critical"
        try {
            val obj = Global.getSettings().loadJSON("data/config/Logistics Notifications/config.json")
            notifications = obj.getBoolean("useNotifications")
            increment = obj.getInt("notificationIncrement")
            lowSupplies = obj.getInt("lowSupplies")
            alarmSupplies = obj.getInt("alarmSupplies")
            lowFuel = obj.getInt("lowFuel")
            alarmFuel = obj.getInt("alarmFuel")
            soundAlarm = obj.getBoolean("soundAlarm")
            alarmId = obj.getString("alarmSoundId")
            followupId = obj.getString("followupSoundId")
            suAlarmId = obj.getString("suAlarmSoundId")
            suFollowupId = obj.getString("suFollowupSoundId")
            fuelAlarmId = obj.getString("fuelAlarmSoundId")
            fuelFollowupId = obj.getString("fuelFollowupSoundId")
        } catch (ex: IOException) {
            Logger.getLogger(NotificationScript::class.java.name)
                .log(Level.SEVERE, null, ex)
        } catch (ex: JSONException) {
            Logger.getLogger(NotificationScript::class.java.name)
                .log(Level.SEVERE, null, ex)
        }

        // Safety checks
        if (increment < 1) increment = 1
        if (alarmSupplies < 0) alarmSupplies = -1
        if (lowSupplies < alarmSupplies) lowSupplies = alarmSupplies
        if (alarmFuel < 0) alarmFuel = -1
        if (lowFuel < alarmFuel) lowFuel = alarmFuel
        DISPLAY_NOTIFICATIONS = notifications
        INCREMENT = increment
        LOW_SUPPLIES = lowSupplies
        ALARM_SUPPLIES = alarmSupplies
        LOW_FUEL = lowFuel
        ALARM_FUEL = alarmFuel
        SOUND_ALARM = soundAlarm
        ALARM_ID = alarmId
        FOLLOWUP_ID = followupId
        SUPPLY_ALARM_ID = suAlarmId
        SUPPLY_FOLLOWUP_ID = suFollowupId
        FUEL_ALARM_ID = fuelAlarmId
        FUEL_FOLLOWUP_ID = fuelFollowupId
    }

    private var delay = 1f // Ensures text appears

    private var first = true // To trigger immediate update on load

    override fun advance(amount: Float) {
        if (Global.getSector().campaignUI.isShowingDialog
            || Global.getSector().isInNewGameAdvance
        ) {
            return
        }


        // First update
        if (DISPLAY_NOTIFICATIONS) {
            if (first && delay <= 0f) {
                first = false
                firstUpdate()
                return
            } else if (first) {
                delay -= amount
                return
            }
        }

        // if paused, return
        if (Global.getSector().isPaused) return

        // Check if should be alarmed every INTERVAL
        if (!alarmed && interval <= 0) {
            interval = INTERVAL

            // If alarm needed, play sound and show relevant metric
            val suAlarm = isSupplyAlarm()
            val fuelAlarm = isFuelAlarm()
            soundAlarm(suAlarm, fuelAlarm)
            alarmed = suAlarm || fuelAlarm
            if (suAlarm) showSupplyDays()
            if (fuelAlarm) showFuelLY()
            if (alarmed) return
        } else {
            interval -= amount
        }

        // Check if new day
        val day = Global.getSector().clock.day
        if (day == lastDay) return
        lastDay = day // New day

        // There are INCREMENT days between notifications
        if (++counter < INCREMENT) return
        counter = 0

        // Display messages
        if (DISPLAY_NOTIFICATIONS) {
            showSupplyDays()
            showFuelLY()
        }

        // Play alarm if danger
        alarmed = checkForDanger()
    }

    /**
     * Shows initial messages
     */
    private fun firstUpdate() {
        // Display messages
        showSupplyDays()
        showFuelLY()
        alarmed = checkForDanger()
    }

    /**
     * Checks if there is danger and (if not disabled) plays an alarm.
     * @return true if there is danger
     */
    private fun checkForDanger(): Boolean {
        if (!SOUND_ALARM) return isSupplyAlarm() || isFuelAlarm()
        val suAlarm = isSupplyAlarm()
        val fuelAlarm = isFuelAlarm()
        soundAlarm(suAlarm, fuelAlarm)
        if (suAlarm) showSupplyDays()
        if (fuelAlarm) showFuelLY()
        return suAlarm || fuelAlarm
    }

    private fun soundAlarm(supplyAlarm: Boolean, fuelAlarm: Boolean) {
        if (!SOUND_ALARM) return
        var soundId: String? = ""
        var volume = 1f
        if (!alarmed) { // Initial alarm
            if (supplyAlarm && fuelAlarm) soundId = ALARM_ID else if (supplyAlarm) soundId =
                SUPPLY_ALARM_ID else if (fuelAlarm) soundId = FUEL_ALARM_ID
        } else { // Followup alarms
            volume = 0.2f
            if (supplyAlarm && fuelAlarm) soundId = FOLLOWUP_ID else if (supplyAlarm) soundId =
                SUPPLY_FOLLOWUP_ID else if (fuelAlarm) soundId = FUEL_FOLLOWUP_ID
        }
        try { // Play nothing if the soundId is invalid
            Global.getSoundPlayer().playUISound(soundId, 1f, volume)
        } catch (ex: RuntimeException) {
        }
    }

    /**
     * Displays message to player showing days of supply remaining.
     */
    private fun showSupplyDays() {
        val suDays = getSupplyDays()
        val supplies = Global.getSector().playerFleet.cargo.supplies
        val recoveryCost = Global.getSector().playerFleet
            .logistics.totalRepairAndRecoverySupplyCost
        val suColor: Color
        if (recoveryCost >= supplies) { // Running out
            suColor = Color.RED
        } else {
            if (suDays > LOW_SUPPLIES) {
                suColor = Color.GREEN
            } else if (suDays > ALARM_SUPPLIES) {
                suColor = Color.ORANGE
            } else {
                suColor = Color.RED
            }
        }

        // Cut off past tenths place
        val suDisplay = (suDays * 10f).toInt() / 10f
        Global.getSector().campaignUI.addMessage(
            "You have about "
                    + suDisplay + " days of supply left.", // extern
            Misc.getTextColor(), "" + suDisplay, "",
            suColor, Misc.getTextColor()
        )
    }

    /**
     * @return true if supplies are dangerously low
     */
    private fun isSupplyAlarm(): Boolean {
        val supplies = Global.getSector().playerFleet.cargo.supplies
        val recoveryCost = Global.getSector().playerFleet
            .logistics.totalRepairAndRecoverySupplyCost
        return recoveryCost >= supplies || getSupplyDays() <= ALARM_SUPPLIES
    }

    /**
     * Displays message to player showing lightyears of fuel remaining.
     */
    private fun showFuelLY() {
        val ly = getFuelLY()
        val lyColor: Color
        if (ly > LOW_FUEL) {
            lyColor = Color.GREEN
        } else if (ly > ALARM_FUEL) {
            lyColor = Color.ORANGE
        } else {
            lyColor = Color.RED
        }

        // Cut off past tenths place
        val lyDisplay = (ly * 10f).toInt() / 10f
        Global.getSector().campaignUI.addMessage(
            ("You have enough fuel to travel about "
                    + lyDisplay + " lightyears."), // extern
            Misc.getTextColor(), "" + lyDisplay, "",
            lyColor, Misc.getTextColor()
        )
    }

    /**
     * @return true if fuel is dangerously low
     */
    private fun isFuelAlarm(): Boolean = getFuelLY() <= ALARM_FUEL

    override fun isDone(): Boolean = false

    override fun runWhilePaused(): Boolean = false

}