package logNot.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.Global
import com.fs.starfarer.api.impl.campaign.tutorial.TutorialMissionIntel
import logNot.helpers.Helper
import org.json.JSONException
import java.awt.Color
import java.io.IOException
import java.util.logging.Level
import java.util.logging.Logger

class HintScript : EveryFrameScript {
    // These are specified in data/config/Logistics Notifications/config.json
    // Whether to use this display method
    private var DISPLAY_HINTS = false

    // Warning (orange text) and alarm times in days of supply
    private var LOW_SUPPLIES = 0
    private var ALARM_SUPPLIES = 0

    private var hintRefresh = 0f
    private val HINT_REFRESH_INTERVAL = 0.1f

    private var update = 0f
    private val UPDATE_INTERVAL = 1f

    val TUTORIAL_HINT_INDEX = 3

    private var suUsage: MutableMap<String, Float>? = null
    private val EXCESS_FUEL = "fuel"
    private val EXCESS_CREW = "crew"
    private var iter = 0

    private var lastRecoveryCost = 0f
    private var lastTotalPerDay = 0f

    init {
        hintRefresh = HINT_REFRESH_INTERVAL
        update = 0f
        suUsage = HashMap()
        var hintsDisplay = true
        var lowSupplies = 30
        var alarmSupplies = 10
        try {
            val obj = Helper.settings?.loadJSON("data/config/Logistics Notifications/config.json") ?: throw IOException()
            hintsDisplay = obj.getBoolean("useHintsDisplay")
            lowSupplies = obj.getInt("lowSupplies")
            alarmSupplies = obj.getInt("alarmSupplies")
        } catch (ex: IOException) {
            Logger.getLogger(HintScript::class.java.name).log(Level.SEVERE, null, ex)
        } catch (ex: JSONException) {
            Logger.getLogger(HintScript::class.java.name).log(Level.SEVERE, null, ex)
        }
        DISPLAY_HINTS = hintsDisplay
        LOW_SUPPLIES = lowSupplies
        ALARM_SUPPLIES = alarmSupplies
        lastRecoveryCost = 0f
        lastTotalPerDay = 0f
    }


    override fun isDone(): Boolean = false

    override fun runWhilePaused(): Boolean = false

    override fun advance(amount: Float) {
        // Use HintPanel to display days of supply
        if (DISPLAY_HINTS) {
            hintRefresh -= amount
            update -= amount
            if (update <= 0) {
                updateHintDataFull()
                update = UPDATE_INTERVAL
                iter = 0
            } else {
                updateHintDataIterative()
            }
            if (hintRefresh <= 0) {
                showHintSupplyDays()
                hintRefresh = HINT_REFRESH_INTERVAL
            }
        }
    }

    private var tutorial = true // To trigger immediate update on load

    private fun showHintSupplyDays() {
        val suDays = getHintSupplyDays()
        val supplies = Global.getSector().playerFleet.cargo.supplies
        val suColor: Color
        suColor = if (lastRecoveryCost >= supplies) { // Running out
            Color.RED
        } else {
            if (suDays > LOW_SUPPLIES) {
                Color.GREEN
            } else if (suDays > ALARM_SUPPLIES) {
                Color.ORANGE
            } else {
                Color.RED
            }
        }

        // Cut off past tenths place
        val suDisplay = Math.round(suDays)
        val hints = Global.getSector().campaignUI.hintPanel ?: return
        var index = 0
        if (TutorialMissionIntel.isTutorialInProgress()) {
            if (tutorial) {
                hints.fadeOutHint(index)
                tutorial = false
            }
            index = TUTORIAL_HINT_INDEX
        } else if (hints.hasHint(TUTORIAL_HINT_INDEX)) {
            hints.fadeOutHint(TUTORIAL_HINT_INDEX)
            tutorial = true
        }
        val format = "~$suDisplay days of supply" // extern
        hints.setHint(index, format, false, suColor, "~$suDisplay")
    }

    private fun getHintSupplyDays(): Float {
        val playerFleet = Global.getSector().playerFleet
        val supplies = playerFleet.cargo.supplies
        val suDays: Float

        // Running out
        if (lastRecoveryCost >= supplies) {
            suDays = supplies / lastTotalPerDay
        } else {
            // Total up maintenance costs per day for fleet
            var maintPerDay = 0f
            for (maint in suUsage!!.values) {
                maintPerDay += maint
            }
            // Compute!
            suDays = lastRecoveryCost / lastTotalPerDay + (supplies - lastRecoveryCost.toInt()) / maintPerDay
        }
        return suDays
    }


    /**
     * Prepares data for how many days of supply the player has
     * left in full, accounting for repairs and recovery.
     */
    private fun updateHintDataFull() {
        suUsage!!.clear()

        // Calculate days of supply remaining
        val playerFleet = Global.getSector().playerFleet
        //        float supplies = playerFleet.getCargo().getSupplies();
        val logistics = playerFleet.logistics
        lastRecoveryCost = logistics.totalRepairAndRecoverySupplyCost
        lastTotalPerDay = logistics.totalSuppliesPerDay

        // Running out
//        if (recoveryCost >= supplies) {
//            suDays = supplies / totalPerDay;
//        }
        // Account for drop back to maintenance after repairs/recovery.
//        else {

        // Total up maintenance costs per day for fleet
//            float maintPerDay = 0;
        for (mem in playerFleet.membersWithFightersCopy) {
            val maint = mem.stats.suppliesPerMonth.modifiedValue / 30
            suUsage!![mem.id] = maint
        }
        // Account for extra cost from over-capacity
        // Not going to try to do cargo because it's reductive as it consumes supplies
        suUsage!![EXCESS_CREW] = logistics.excessPersonnelCapacitySupplyCost
        suUsage!![EXCESS_FUEL] = logistics.excessFuelCapacitySupplyCost

        // And finally: compute!
//            suDays = (recoveryCost / totalPerDay) + ((supplies - (int) recoveryCost) / maintPerDay);
//        }
    }

    /**
     * Updates 1 ship's supply data per frame
     */
    private fun updateHintDataIterative() {
        val playerFleet = Global.getSector().playerFleet
        if (iter >= playerFleet.numMembersFast) iter = 0
        try {
            val mem = playerFleet.membersWithFightersCopy[iter]
            val maint = mem.stats.suppliesPerMonth.modifiedValue / 30
            suUsage!![mem.id] = maint
            iter++
        } catch (ex: IndexOutOfBoundsException) {
            iter = 0
        }
    }
}