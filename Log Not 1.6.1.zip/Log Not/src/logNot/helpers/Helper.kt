package logNot.helpers

import com.fs.starfarer.api.Global
import com.fs.starfarer.api.SettingsAPI
import com.fs.starfarer.api.SoundPlayerAPI
import com.fs.starfarer.api.campaign.*
import com.fs.starfarer.api.util.Misc
import java.util.*

object Helper {
    val modId: String
        get() {
            return if (isModEnabled(Ids.DEV_MOD_ID)) Ids.DEV_MOD_ID
            else if (isModEnabled(Ids.MOD_ID)) Ids.MOD_ID
            else {
                settings?.modManager?.enabledModsCopy?.firstOrNull { it.id.startsWith(Ids.MOD_ID) }?.id
                    ?: Ids.MOD_ID
            }
    }

    fun isModEnabled(id: String): Boolean {
        return settings?.modManager?.isModEnabled(id) == true
    }

    val random
        get() = Misc.random ?: Random()

    val isSectorPaused: Boolean
        get() = sector?.isPaused ?: true

    val sector: SectorAPI?
        get() = Global.getSector()

    val settings: SettingsAPI?
        get() = Global.getSettings()

    val soundPlayer: SoundPlayerAPI?
        get() = Global.getSoundPlayer()

    fun anyNull(vararg objects: Any?): Boolean {
        for (o in objects) {
            if (o == null) return true
        }

        return false
    }
}
