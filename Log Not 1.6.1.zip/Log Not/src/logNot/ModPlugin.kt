package logNot

import com.fs.starfarer.api.BaseModPlugin
import com.fs.starfarer.api.impl.campaign.tutorial.TutorialMissionIntel
import logNot.helpers.Helper
import logNot.helpers.Ids
import logNot.scripts.HintScript
import logNot.scripts.NotificationScript

class ModPlugin : BaseModPlugin() {
    override fun onApplicationLoad() {
        if (!Helper.isModEnabled(Ids.LAZY_LIB)) throw RuntimeException("Logistics Notifications requires LazyLib!")
    }

    override fun onGameLoad(newGame: Boolean) {
        Helper.sector?.addTransientScript(NotificationScript())
        Helper.sector?.addTransientScript(HintScript())
    }

    override fun beforeGameSave() {
        val hints = Helper.sector?.campaignUI?.hintPanel ?: return
        if (TutorialMissionIntel.isTutorialInProgress() && hints.hasHint(3)) {
            hints.fadeOutHint(3)
        } else if (hints.hasHint(0)) {
            hints.fadeOutHint(0)
        }
    }

}