package logNot.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.util.IntervalUtil
import com.fs.starfarer.api.util.Misc
import logNot.helpers.Helper

class SupplyDataTracking : EveryFrameScript {
    companion object {
        private val EXCESS_FUEL = "fuel"
        private val EXCESS_CREW = "crew"

        fun getFuelLY(): Float {
            val playerFleet = Helper.sector?.playerFleet ?: return 0f
            val fuel = playerFleet.cargo?.fuel ?: return 0f
            val fuelPerDay = playerFleet.logistics?.baseFuelCostPerLightYear ?: return 0f
            val ly = if (playerFleet.isInHyperspace) fuel / fuelPerDay else (fuel - fuelPerDay) / fuelPerDay
            // TODO multiple by overburn? Actual speed is a setting!
            return ly.coerceAtLeast(0f)
        }
    }

    val daysOfSupplyRemaining: Float
        get() = _daysOfSupplyRemaining

    val isRunningOutOfSupplies: Boolean
        get() = _isRunningOutOfSupplies

    val fuelLYRemaining: Float
        get() = _fuelLYRemaining

    private var _fuelLYRemaining = 0f

    private var lastRecoveryCost = 0f
    private var lastTotalPerDay = 0f

    private var _daysOfSupplyRemaining = 0f
    private var _isRunningOutOfSupplies = false

    private var suUsage = mutableMapOf<String, Float>()
    private var iter = 0

    init {
        updateAllFleetMemberSupplyData()
        updateSupplyDataFull()
        refreshData()
    }

    private val dataRefreshInterval = IntervalUtil(0.01f,0.01f) // TODO test refresh rate
    private val fullUpdateInterval = IntervalUtil(0.9f,1.1f) // TODO setting for full update interval?

    override fun advance(amount: Float) {
        val days = Misc.getDays(amount)
        fullUpdateInterval.advance(days)
        if (fullUpdateInterval.intervalElapsed()) {
            updateSupplyDataFull()
        } else {
            updateSupplyDataIterative()
        }

        dataRefreshInterval.advance(days)
        if (dataRefreshInterval.intervalElapsed()) {
            updateFuelLY()
            refreshData()
        }
    }

    private fun refreshData() {
        _isRunningOutOfSupplies = checkRunningOutOfSupplies()
        _daysOfSupplyRemaining = calculateDaysOfSupplyRemaining()
    }

    private fun checkRunningOutOfSupplies(): Boolean {
        val supplies = Helper.sector?.playerFleet?.cargo?.supplies ?: return true
        return lastRecoveryCost >= supplies
    }

    /**
     * Updates 1 ship's supply data per frame
     */
    private fun updateSupplyDataIterative() {
        val members = Helper.sector?.playerFleet?.membersWithFightersCopy ?: return
        if (members.isEmpty()) return
        if (iter >= members.size) iter = 0
        val mem = members[iter++] ?: return
        if (mem.isFighterWing) return
        suUsage[mem.id] = (mem.stats?.suppliesPerMonth?.modifiedValue ?: 0f) / 30
    }

    private fun calculateDaysOfSupplyRemaining(): Float {
        val supplies = Helper.sector?.playerFleet?.cargo?.supplies ?: return 0f
        val suDays = if (_isRunningOutOfSupplies) {
            supplies / lastTotalPerDay
        } else {
            lastRecoveryCost / lastTotalPerDay + (supplies - lastRecoveryCost.toInt()) / suUsage.values.sum()
        }
        return suDays
    }

    private fun updateSupplyDataFull() {
        suUsage.clear()

        val logistics = Helper.sector?.playerFleet?.logistics ?: return
        lastRecoveryCost = logistics.totalRepairAndRecoverySupplyCost
        lastTotalPerDay = logistics.totalSuppliesPerDay

        //updateAllFleetMemberSupplyData()

        // Account for extra cost from over-capacity
        // Not going to try to do cargo because it's reductive as it consumes supplies
        suUsage[EXCESS_CREW] = logistics.excessPersonnelCapacitySupplyCost
        suUsage[EXCESS_FUEL] = logistics.excessFuelCapacitySupplyCost
    }

    private fun updateAllFleetMemberSupplyData() {
        Helper.sector?.playerFleet?.membersWithFightersCopy?.forEach { _ ->
            updateSupplyDataIterative()
        }
    }

    private fun updateFuelLY() {
        _fuelLYRemaining = getFuelLY()
    }

    override fun isDone(): Boolean = false
    override fun runWhilePaused(): Boolean = false
}