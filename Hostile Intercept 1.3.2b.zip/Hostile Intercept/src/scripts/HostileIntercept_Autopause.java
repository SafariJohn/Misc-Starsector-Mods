package scripts;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel;
import com.fs.starfarer.api.campaign.ai.FleetAIFlags;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.loading.CampaignPingSpec;
import com.fs.starfarer.api.util.Misc;
import static ids.HostileIntercept_Settings.*;
import java.awt.Color;
import java.util.List;
import static scripts.HostileIntercept_ModPlugin.BOOLEAN_CHECK_INTERVAL;

/**
 * Author: SafariJohn
 */
public class HostileIntercept_Autopause implements EveryFrameScript {

    public static final String IGNORE_KEY = "$hostileIntercept_autopauseTimeout";
    public static final float EXPIRATION = 30f; // seconds

	public static final float INTERVAL = 0.1f;
	public static final float PAUSE_DELAY = 0.3f;

    private boolean autopause;
    private boolean interceptOnly;
    private boolean withSound;

    private float interval = 0;
    private float booleansInterval = 0;
    private boolean pausing = false;

    private boolean snoozed = false;
    private float snoozeDelay = 0;
    private float snoozeInterval = 0;

    public HostileIntercept_Autopause(boolean autopause, boolean withSound) {
        this.autopause = autopause;
        this.withSound = withSound;

        if (autopause) interceptOnly = isFeatureEnabled(AUTOPAUSE_INTERCEPT_KEY);
        else interceptOnly = false;
        snoozeDelay = Global.getSettings().getFloat(SNOOZED_TIME_KEY);
    }

    @Override
    public void advance(float amount) {
        if (Global.getSector().isPaused()) {
            pausing = false;
            return;
        }

        interval += amount;
        booleansInterval += amount;

        if (booleansInterval >= BOOLEAN_CHECK_INTERVAL) {
            booleansInterval -= BOOLEAN_CHECK_INTERVAL;
            autopause = isFeatureEnabled(AUTOPAUSE_KEY);
            if (autopause) interceptOnly = isFeatureEnabled(AUTOPAUSE_INTERCEPT_KEY);
            else interceptOnly = false;
            withSound = isFeatureEnabled(ALARM_KEY);
        }

        if (pausing) {
            if (interval > PAUSE_DELAY) {
                interval -= PAUSE_DELAY;

                Global.getSector().setPaused(true);

                pausing = false;
            }

            return;
        }


        if (interval < INTERVAL) return;

        snoozeInterval += interval;

        interval -= INTERVAL;


        if (snoozed && snoozeInterval > snoozeDelay) {
            snoozeInterval = 0;
            snoozed = false;
        }

        // Autopause only works while following a course
        SectorEntityToken courseTarget = Global.getSector().getUIData().getCourseTarget();
        SectorEntityToken interactionTarget = Global.getSector()
                    .getPlayerFleet().getInteractionTarget();
        boolean onCourse = courseTarget != null && courseTarget == interactionTarget;

        onCourse |= courseTarget != null && (interactionTarget instanceof JumpPointAPI);

        if (!onCourse) return;

        // Check all entities
        List<SectorEntityToken> entities = Global.getSector()
                    .getPlayerFleet().getContainingLocation().getAllEntities();

        for (SectorEntityToken entity : entities) {
            // Ignore planets and stuff
            if (entity instanceof PlanetAPI) continue;

            // Ignore it if has ignore key
            if (entity.getMemoryWithoutUpdate().contains(IGNORE_KEY)) {
                if (entity.getMemoryWithoutUpdate().getExpire(IGNORE_KEY) <= EXPIRATION) {
                    entity.getMemoryWithoutUpdate().set(IGNORE_KEY, true, EXPIRATION);
                }
                continue;
            }

            // Must be visible
            if (entity.getVisibilityLevelToPlayerFleet() == VisibilityLevel.NONE) continue;

            // Ignore transient objects (cargo pods and battlefield debris)
            if (entity.getFaction().isNeutralFaction() && !entity.isDiscoverable()) continue;

            // Pause for sensor contacts and unknown fleets
            VisibilityLevel vis = entity.getVisibilityLevelToPlayerFleet();
            if (vis == VisibilityLevel.COMPOSITION_DETAILS
                        || vis == VisibilityLevel.SENSOR_CONTACT) {
                pause(entity);
                return;
            }

            // Pause for intercepting fleets
            // Must be a fleet
            if (!(entity instanceof CampaignFleetAPI)) continue;
            // Must be visible
            if (vis == VisibilityLevel.SENSOR_CONTACT
                        || vis == VisibilityLevel.NONE) continue;

            // Must be hostile or targeting the player
            boolean isHostile = entity.getFaction().isHostileTo(Factions.PLAYER)
                        || entity.getMemoryWithoutUpdate().getBoolean(MemFlags.MEMORY_KEY_MAKE_HOSTILE);
            SectorEntityToken target = (SectorEntityToken) entity
                        .getMemoryWithoutUpdate().get(FleetAIFlags.PURSUIT_TARGET);
            if (isHostile || target == Global.getSector().getPlayerFleet()) {
                pause(entity);
                return;
            }
        }
    }

    private void pause(SectorEntityToken cause) {
        boolean isIntercept = true;
        // Check if intercept in progress
        if (cause instanceof CampaignFleetAPI) {
            CampaignFleetAPI fleet = (CampaignFleetAPI) cause;

            // Fleet intent is visible
            VisibilityLevel vis = fleet.getVisibilityLevelToPlayerFleet();
            isIntercept &= vis == VisibilityLevel.COMPOSITION_DETAILS
                        || vis == VisibilityLevel.COMPOSITION_AND_FACTION_DETAILS;

            // Fleet is targeting the player's fleet
            SectorEntityToken target = (SectorEntityToken) fleet
                        .getMemoryWithoutUpdate().get(FleetAIFlags.PURSUIT_TARGET);
            isIntercept &= target == Global.getSector().getPlayerFleet();
        } else {
            isIntercept = false;
        }

        if (interceptOnly && !isIntercept) return;

        Global.getSector().getCampaignUI().getMessageDisplay().addMessage("Potential threat detected");
        cause.getMemoryWithoutUpdate().set(IGNORE_KEY, true, EXPIRATION);

        if (snoozed) return;

        if (autopause) {
//            if (interceptOnly) {
//                pausing = isIntercept;
//            } else {
                pausing = true;
//            }
        }

        snoozed = true;
//        snoozeDelay = Global.getSettings().getFloat(SNOOZED_TIME_KEY);
        snoozeInterval = 0;

        if (withSound) {
            String soundId = Global.getSettings().getString(ALARM_SOUND_KEY);
            try { // Play nothing if the soundId is invalid
                Global.getSoundPlayer().playUISound(soundId, 1f, 1f);
            } catch (RuntimeException ex) {}
        }

        Color color = Misc.getHighlightColor();
        float range = cause.getRadius();

        CampaignPingSpec custom = new CampaignPingSpec();
        custom.setColor(color);
        custom.setUseFactionColor(false);
        custom.setWidth(Math.max(range / 5, 10));
        custom.setMinRange(range / 2);
        custom.setRange(range * 10);
        custom.setDuration(PAUSE_DELAY * 3);
        custom.setAlphaMult(1f);
        custom.setInFraction(0.5f);
        custom.setNum(2);
        custom.setInvert(true);

        Global.getSector().addPing(cause, custom);
    }

    public boolean isDone() {
        return false;
    }
    public boolean runWhilePaused() {
        return false;
    }
}
