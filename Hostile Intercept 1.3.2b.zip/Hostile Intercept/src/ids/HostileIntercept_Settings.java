package ids;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;

/**
 * Author: SafariJohn
 */
public class HostileIntercept_Settings {
    public static final String INTERCEPT_ALARM_KEY = "hostileIntercept_interceptAlarm";
    public static final String INTERCEPT_SOUND_KEY = "hostileIntercept_interceptSoundId";

    public static final String AUTOPAUSE_KEY = "hostileIntercept_autopause";
    public static final String AUTOPAUSE_INTERCEPT_KEY = "hostileIntercept_InterceptOnly";
    public static final String SNOOZED_TIME_KEY = "hostileIntercept_autopauseSnoozedTime";
    public static final String ALARM_KEY = "hostileIntercept_autopauseAlarm";
    public static final String ALARM_SOUND_KEY = "hostileIntercept_alarmSoundId";

    public static final String JUMP_PAUSE_KEY = "hostileIntercept_jumpPointPause";
    public static final String JUMP_PAUSE_ALARM_KEY = "hostileIntercept_jumpPointAlarm";
    public static final String JUMP_PAUSE_THREATS_KEY = "hostileIntercept_jumpPointPauseOnlyIfThreats";

    public static boolean isFeatureEnabled(String hostileInterceptKey) {
        MemoryAPI memory = Global.getSector().getMemoryWithoutUpdate();
        if (memory.contains("$" + hostileInterceptKey)) {
            return memory.getBoolean("$" + hostileInterceptKey);
        } else {
            return Global.getSettings().getBoolean(hostileInterceptKey);
        }
    }
}
