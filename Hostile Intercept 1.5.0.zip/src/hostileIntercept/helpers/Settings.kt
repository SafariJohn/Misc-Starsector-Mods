package hostileIntercept.helpers

object Settings {
    val INTERCEPT_ALARM_KEY = "hostileIntercept_interceptAlarm"
    val INTERCEPT_SOUND_KEY = "hostileIntercept_interceptSoundId"

    val AUTOPAUSE_KEY = "hostileIntercept_autopause"
    val AUTOPAUSE_INTERCEPT_KEY = "hostileIntercept_InterceptOnly"
    val SNOOZED_TIME_KEY = "hostileIntercept_autopauseSnoozedTime"
    val ALARM_KEY = "hostileIntercept_autopauseAlarm"
    val ALARM_SOUND_KEY = "hostileIntercept_alarmSoundId"

    val JUMP_PAUSE_KEY = "hostileIntercept_jumpPointPause"
    val JUMP_PAUSE_ALARM_KEY = "hostileIntercept_jumpPointAlarm"
    val JUMP_PAUSE_THREATS_KEY = "hostileIntercept_jumpPointPauseOnlyIfThreats"

    fun isFeatureEnabled(key: String): Boolean {
        return if (Memory.contains(key.toKey())) Memory.get(key.toKey(), { it is Boolean }, { false }) as Boolean
        else Helper.settings?.getBoolean(key) == true
    }

    fun String.toKey(): String = "$$this"
}