package hostileIntercept.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.campaign.CampaignFleetAPI
import com.fs.starfarer.api.campaign.JumpPointAPI
import com.fs.starfarer.api.campaign.PlanetAPI
import com.fs.starfarer.api.campaign.SectorEntityToken
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel
import com.fs.starfarer.api.campaign.ai.FleetAIFlags
import com.fs.starfarer.api.impl.campaign.ids.Factions
import com.fs.starfarer.api.impl.campaign.ids.MemFlags
import com.fs.starfarer.api.loading.CampaignPingSpec
import com.fs.starfarer.api.util.Misc
import hostileIntercept.helpers.Helper
import hostileIntercept.ModPlugin
import hostileIntercept.helpers.ExternalStrings
import hostileIntercept.helpers.Memory
import hostileIntercept.helpers.Settings

class Autopause(autopause: Boolean, withSound: Boolean) : EveryFrameScript {

    val IGNORE_KEY = "\$hostileIntercept_autopauseTimeout"
    val EXPIRATION = 30f // seconds


    val INTERVAL = 0.1f
    val PAUSE_DELAY = 0.3f

    private var autopause = false
    private var interceptOnly = false
    private var withSound = false

    private var interval = 0f
    private var booleansInterval = 0f
    private var pausing = false

    private var snoozed = false
    private var snoozeDelay = 0f
    private var snoozeInterval = 0f

    init {
        this.autopause = autopause
        this.withSound = withSound
        interceptOnly = if (autopause) Settings.isFeatureEnabled(Settings.AUTOPAUSE_INTERCEPT_KEY) else false
        snoozeDelay = Helper.settings?.getFloat(Settings.SNOOZED_TIME_KEY) ?: 0f
    }

    override fun advance(amount: Float) {
        if (Helper.isSectorPaused) {
            pausing = false
            return
        }
        interval += amount
        booleansInterval += amount
        if (booleansInterval >= ModPlugin.BOOLEAN_CHECK_INTERVAL) {
            booleansInterval -= ModPlugin.BOOLEAN_CHECK_INTERVAL
            autopause = Settings.isFeatureEnabled(Settings.AUTOPAUSE_KEY)
            if (autopause) interceptOnly = Settings.isFeatureEnabled(Settings.AUTOPAUSE_INTERCEPT_KEY) else interceptOnly = false
            withSound = Settings.isFeatureEnabled(Settings.ALARM_KEY)
        }
        if (pausing) {
            if (interval > PAUSE_DELAY) {
                interval -= PAUSE_DELAY
                Helper.sector?.isPaused = true
                pausing = false
            }
            return
        }
        if (interval < INTERVAL) return
        snoozeInterval += interval
        interval -= INTERVAL
        if (snoozed && snoozeInterval > snoozeDelay) {
            snoozeInterval = 0f
            snoozed = false
        }

        // Autopause only works while following a course
        val courseTarget = Helper.sector?.uiData?.courseTarget
        val interactionTarget = Helper.sector?.playerFleet?.interactionTarget
        var onCourse = courseTarget != null && courseTarget === interactionTarget
        onCourse = onCourse or (courseTarget != null && interactionTarget is JumpPointAPI)
        if (!onCourse) return

        // Check all entities
        val entities = Helper.sector?.playerFleet?.containingLocation?.allEntities ?: emptyList()
        for (entity in entities) {
            // Ignore planets and stuff
            if (entity is PlanetAPI) continue

            // Ignore it if has ignore key
            if (entity.memoryWithoutUpdate.contains(IGNORE_KEY)) {
                if (entity.memoryWithoutUpdate.getExpire(IGNORE_KEY) <= EXPIRATION) {
                    entity.memoryWithoutUpdate[IGNORE_KEY, true] = EXPIRATION
                }
                continue
            }

            // Must be visible
            if (entity.visibilityLevelToPlayerFleet == VisibilityLevel.NONE) continue

            // Ignore transient objects (cargo pods and battlefield debris)
            if (entity.faction.isNeutralFaction && !entity.isDiscoverable) continue

            // Pause for sensor contacts and unknown fleets
            val vis = entity.visibilityLevelToPlayerFleet
            if (vis == VisibilityLevel.COMPOSITION_DETAILS
                || vis == VisibilityLevel.SENSOR_CONTACT
            ) {
                pause(entity)
                return
            }

            // Pause for intercepting fleets
            // Must be a fleet
            if (entity !is CampaignFleetAPI) continue
            // Must be visible
            if (vis == VisibilityLevel.SENSOR_CONTACT
                || vis == VisibilityLevel.NONE
            ) continue

            // Must be hostile or targeting the player
            val isHostile = (entity.getFaction().isHostileTo(Factions.PLAYER)
                    || entity.getMemoryWithoutUpdate().getBoolean(MemFlags.MEMORY_KEY_MAKE_HOSTILE))
            val target = Memory.getNullable(
                FleetAIFlags.PURSUIT_TARGET,
                entity,
                { it is SectorEntityToken },
                { null }
            ) as? SectorEntityToken
            if (isHostile || target === Helper.sector?.playerFleet) {
                pause(entity)
                return
            }
        }
    }

    private fun pause(cause: SectorEntityToken) {
        var isIntercept: Boolean
        // Check if intercept in progress
        if (cause is CampaignFleetAPI) {
            // Fleet intent is visible
            val vis = cause.visibilityLevelToPlayerFleet
            isIntercept = (vis == VisibilityLevel.COMPOSITION_DETAILS
                    || vis == VisibilityLevel.COMPOSITION_AND_FACTION_DETAILS)

            // Fleet is targeting the player's fleet
            val target = Memory.getNullable(
                FleetAIFlags.PURSUIT_TARGET,
                cause,
                { it is SectorEntityToken },
                { null }
            ) as? SectorEntityToken
            isIntercept = isIntercept and (target === Helper.sector?.playerFleet)
        } else {
            isIntercept = false
        }
        if (interceptOnly && !isIntercept) return
        Helper.sector?.campaignUI?.messageDisplay?.addMessage(ExternalStrings.POTENTIAL_THREAT)
        cause.memoryWithoutUpdate[IGNORE_KEY, true] = EXPIRATION
        if (snoozed) return
        if (autopause) {
            pausing = true
        }
        snoozed = true
        snoozeInterval = 0f
        if (withSound) {
            val soundId = Helper.settings?.getString(Settings.ALARM_SOUND_KEY)
            try { // Play nothing if the soundId is invalid
                Helper.soundPlayer?.playUISound(soundId, 1f, 1f)
            } catch (_: RuntimeException) {}
        }
        val color = Misc.getHighlightColor()
        val range = cause.radius
        val custom = CampaignPingSpec().apply {
            this.color = color
            this.isUseFactionColor = false
            this.width = Math.max(range / 5, 10f)
            this.minRange = range / 2
            this.range = range * 10
            this.duration = PAUSE_DELAY * 3
            this.alphaMult = 1f
            this.inFraction = 0.5f
            this.num = 2
            this.isInvert = true 
        }
        Helper.sector?.addPing(cause, custom)
    }

    override fun isDone(): Boolean = false
    override fun runWhilePaused(): Boolean = false
}