package hostileIntercept.scripts

import com.fs.starfarer.api.EveryFrameScript
import com.fs.starfarer.api.campaign.CampaignFleetAPI
import com.fs.starfarer.api.campaign.JumpPointAPI
import com.fs.starfarer.api.campaign.PlanetAPI
import com.fs.starfarer.api.campaign.SectorEntityToken
import com.fs.starfarer.api.campaign.SectorEntityToken.VisibilityLevel
import com.fs.starfarer.api.campaign.ai.FleetAIFlags
import com.fs.starfarer.api.impl.campaign.ids.Factions
import com.fs.starfarer.api.impl.campaign.ids.MemFlags
import com.fs.starfarer.api.loading.CampaignPingSpec
import com.fs.starfarer.api.util.Misc
import hostileIntercept.helpers.Helper
import hostileIntercept.helpers.Memory
import hostileIntercept.ModPlugin
import hostileIntercept.helpers.ExternalStrings
import hostileIntercept.helpers.Settings

class JumpPointPause : EveryFrameScript {
    companion object {
        const val INTERVAL = 0.1f
        const val PAUSE_DELAY = 0.3f
    }
    private var autopause = false
    private var threatenedOnly = false
    private var withSound = false
    private var wasInHyper = false
    private var soundId: String? = null
    private var threatsSoundId: String? = null

    private var interval = 0f
    private var booleansInterval = 0f
    private var pausing = false

    init {
        autopause = Settings.isFeatureEnabled(Settings.JUMP_PAUSE_KEY)
        threatenedOnly = Settings.isFeatureEnabled(Settings.JUMP_PAUSE_THREATS_KEY)
        withSound = Settings.isFeatureEnabled(Settings.JUMP_PAUSE_ALARM_KEY)
        wasInHyper = Helper.sector?.playerFleet?.isInHyperspace == true
        soundId = Helper.settings?.getString(Settings.ALARM_SOUND_KEY)
        threatsSoundId = Helper.settings?.getString(Settings.INTERCEPT_SOUND_KEY)
    }


    override fun advance(amount: Float) {
        if (Helper.isSectorPaused) {
            pausing = false
            return
        }
        interval += amount
        booleansInterval += amount
        if (booleansInterval >= ModPlugin.BOOLEAN_CHECK_INTERVAL) {
            booleansInterval -= ModPlugin.BOOLEAN_CHECK_INTERVAL
            autopause = Settings.isFeatureEnabled(Settings.JUMP_PAUSE_KEY)
            threatenedOnly =
                Settings.isFeatureEnabled(Settings.JUMP_PAUSE_THREATS_KEY)
            withSound = Settings.isFeatureEnabled(Settings.JUMP_PAUSE_ALARM_KEY)
        }
        if (!autopause) return
        val target = Helper.sector?.uiData?.courseTarget
        val reachingTarget = target === Helper.sector?.playerFleet?.interactionTarget
        val jumpingNow = reachingTarget && target is JumpPointAPI
        if (target != null && !jumpingNow) return
        if (pausing) {
            if (interval > PAUSE_DELAY) {
                interval -= PAUSE_DELAY
                if (autopause) Helper.sector?.isPaused = true
                pausing = false
            }
            return
        }
        if (interval < INTERVAL) return
        interval -= INTERVAL
        val inTransition = Helper.sector?.playerFleet?.isInHyperspaceTransition == true
        val isInHyper = Helper.sector?.playerFleet?.isInHyperspace == true
        if (inTransition && wasInHyper != isInHyper) {
            wasInHyper = isInHyper
            val threats = getThreats()
            if (threatenedOnly && threats.isEmpty()) return
            if (!threats.isEmpty()) {
                val msg = if (threats.size == 1) ExternalStrings.POTENTIAL_THREAT
                else ExternalStrings.POTENTIAL_THREATS
                Helper.sector?.campaignUI?.messageDisplay?.addMessage(msg)
            }
            pause(threats)
        }
    }

    private fun getThreats(): Set<SectorEntityToken> {
        val result = mutableSetOf<SectorEntityToken>()

        // Check all entities
        val entities = Helper.sector?.playerFleet?.containingLocation?.allEntities ?: return result
        for (entity in entities) {
            // Ignore planets and stuff
            if (entity is PlanetAPI) continue

            // Must be visible
            if (entity.visibilityLevelToPlayerFleet == VisibilityLevel.NONE) continue

            // Ignore transient objects (cargo pods and battlefield debris)
            if (entity.faction.isNeutralFaction && !entity.isDiscoverable) continue

            // Pause for sensor contacts and unknown fleets
            val vis = entity.visibilityLevelToPlayerFleet
            if (vis == VisibilityLevel.COMPOSITION_DETAILS
                || vis == VisibilityLevel.SENSOR_CONTACT
            ) {
                result.add(entity)
                continue
            }

            // Pause for intercepting fleets
            // Must be a fleet
            if (entity !is CampaignFleetAPI) continue
            // Must be visible
            if (vis == VisibilityLevel.SENSOR_CONTACT
                || vis == VisibilityLevel.NONE
            ) continue

            // Must be hostile or targeting the player
            val isHostile = (entity.getFaction().isHostileTo(Factions.PLAYER)
                    || entity.getMemoryWithoutUpdate().getBoolean(MemFlags.MEMORY_KEY_MAKE_HOSTILE))
            val target = Memory.getNullable(
                FleetAIFlags.PURSUIT_TARGET,
                entity as SectorEntityToken,
                { it is SectorEntityToken },
                { null }
            ) as? SectorEntityToken ?: continue
            if (isHostile || target === Helper.sector?.playerFleet) {
                result.add(entity)
                continue
            }
        }
        return result
    }

    private fun pause(threats: Set<SectorEntityToken>) {
        pausing = true
        if (withSound) {
            var sound = soundId
            if (threats.isEmpty()) sound = threatsSoundId
            try {
                Helper.soundPlayer?.playUISound(sound, 1f, 1f)
            } catch (_: RuntimeException) {}
        }
        for (threat in threats) {
            ping(threat)
        }
    }

    private fun ping(entity: SectorEntityToken) {
        val color = Misc.getHighlightColor()
        val range = entity.radius
        val custom = CampaignPingSpec()
        custom.color = color
        custom.isUseFactionColor = false
        custom.width = (range / 5).coerceAtLeast(10f)
        custom.minRange = range / 2
        custom.range = range * 10
        custom.duration = PAUSE_DELAY * 3
        custom.alphaMult = 1f
        custom.inFraction = 0.5f
        custom.num = 2
        custom.isInvert = true
        Helper.sector?.addPing(entity, custom)
    }


    override fun isDone(): Boolean = false

    override fun runWhilePaused(): Boolean = false
}